<?php


require_once (REALPATH.'/config/Init.inc.php');
require_once(REALPATH.'/include/Class/httpsqs_client.php');



class EshowCommon {
	
    
    
	/**
	 * 
	 */
	function __construct() {
		
	//TODO - Insert your code here
	}
	
	
	
	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $cmp_id
	 * @param unknown_type $sendtitle
	 * @param unknown_type $sendcontent
	 */
	static function user_alert_email($cmp_id , $sendtitle  , $message_n){
		
		$dao = new CommonDao4sSelf('','','','');
		$sql = " select sellmail,cmp_name from company where id = $cmp_id";
		$company = $dao->getRowByPkOne($sql,'');
		
		$sendmail = $company['sellmail'];
		
		$mail_end =" <br/> <p>赢立方</p> <p>http://www.eshowpro.com</p> ";
		
		
		if( !empty($sendmail) ){   //可以发送邮件
			
				$sendmail_arr = explode(';',$sendmail);
				
				foreach ( $sendmail_arr as $item ){
					
					$parm = array('ToList'=>$item,'CCList'=>'','Subject'=>$sendtitle,'Message'=>$message_n.$mail_end);
			
					EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedmail');
			
					
				}
				
				
				
				
			
			
		}
		
		$parm = array('ToList'=>'xunpan@eshowpro.com,fengxiang@eshowpro.com,laurence@eshowpro.com','CCList'=>'','Subject'=>"【    ".$company['cmp_name']."   】".'ESHOWPRO提示:有用户给您留言','Message'=>"提示：".$company['cmp_name']."  $message_n $mail_end");
		EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedmail');
		
		
	}
	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $cmp_id
	 * @param unknown_type $sendtitle
	 * @param unknown_type $sendcontent
	 */
	static function user_email($email , $sendtitle  , $message_n){
		
		$parm = array('ToList'=>$email,'CCList'=>'','Subject'=>$sendtitle,'Message'=>$message_n.$mail_end);
			
		EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedcusmail');
		
		
	}
	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $cmp_id
	 * @param unknown_type $sendtitle
	 * @param unknown_type $sendcontent
	 */
	static function user_alert_email4ip($cmp_id , $sendtitle  , $message_n,$ip){
		
		
		if( checkruneve() ){
			
			$dao = new CommonDao4sSelf('','','','');
			$sql = " select sellmail,cmp_name from company where id = $cmp_id";
			$company = $dao->getRowByPkOne($sql,'');
			
			$sendmail = $company['sellmail'];
			
			$mail_end =" <br/> <p>赢立方</p> <p>http://www.eshowpro.com</p> ";
			
			
			if( !empty($sendmail) ){   //可以发送邮件
				
					$sendmail_arr = explode(';',$sendmail);
					
					foreach ( $sendmail_arr as $item ){
						
						$parm = array('ToList'=>$item,'CCList'=>'','Subject'=>$sendtitle,'Message'=>$message_n.$mail_end,'visitip'=>$ip);
						EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedmail4ip');
						
					}
				
			}
			
			$parm = array('ToList'=>'xunpan@eshowpro.com,fengxiang@eshowpro.com,laurence@eshowpro.com','CCList'=>'','Subject'=>"【    ".$company['cmp_name']."   】".$sendtitle,'Message'=>"提示：".$company['cmp_name']."  $message_n $mail_end",'visitip'=>$ip);
			EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedmail4ip');
			
		
			
		}
		
	}
	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $cmp_id
	 * @param unknown_type $sendtitle
	 * @param unknown_type $sendcontent
	 */
	static function user_yw_email($cmp_id , $sendtitle  , $message_n , $ip ){
		
		
		if( checkruneve() ){
			
			$dao = new CommonDao4sSelf('','','','');
			$sql = " select sellmail,cmp_name from company where id = $cmp_id";
			$company = $dao->getRowByPkOne($sql,'');
			
			$sendmail = $company['sellmail'];
			
			$mail_end =" <br/> <p>赢立方</p> <p>http://www.eshowpro.com</p> ";
			
			
			if( !empty($sendmail) ){   //可以发送邮件
				
					$sendmail_arr = explode(';',$sendmail);
					
					foreach ( $sendmail_arr as $item ){
						
						$parm = array('ToList'=>$item,'CCList'=>'','Subject'=>$sendtitle,'Message'=>$message_n.$mail_end);
						EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedmail4ip');
						
					}
				
			}
			
			$parm = array('ToList'=>'xunpan@eshowpro.com,fengxiang@eshowpro.com,laurence@eshowpro.com','CCList'=>'','Subject'=>"【    ".$company['cmp_name']."   】".$sendtitle,'Message'=>"提示：".$company['cmp_name']."  $message_n $mail_end",'visitip'=>$ip);
			EshowCommon::sendcountqurl($parm,'http://10.160.15.151/eshow/snedmail');
			
		
			
		}
		
	}
	
	/**
	 * 发送队列到通用后台机器人
	 *
	 * @param unknown_type $parm
	 * @param unknown_type $url
	 */
	static function sendcountqurl($parm,$url){
		
		
		if( checkruneve() ){
			
			$ip = '10.161.145.188';
			$port = '22148';
			
			
			global $_CFG;
			$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
			$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));
			
			
			
			if( $_CFG["ProjectName"] == $project_path_split )
				return;
			
			
			$queue_name = 'eshowgulecmd';
			$httpsqs = new httpsqs( $ip , $port , '' , "utf-8" );
			
			//$parm = array( 'id'=>$id,'ip'=>$ips);
			$parm_str = base64_encode( json_encode( $parm ));
			
			$push_arr = array(
									//'url'=>'http://10.160.15.151/eshow/countare',
									'url'=>$url,
									'parm'=>$parm_str                 
			
								);
			
			$push_arr_str = json_encode( $push_arr ) ;
			
			
			if(!empty($httpsqs))
			{
				log_message( 'info' , '准备写入队列------'.$ip .'  ---------- '.$port );
				$httpsqs->put($queue_name,urlencode($push_arr_str));
				
			}else{
				log_message('info','httpsqs服务器无法连接!请检查问题！');
			}
			
		}
		
		
		
		
		
	}
	
	
	static function sendcountqurl111111111111($parm,$url){
		
		$ip = '10.161.145.188';
		$port = '22148';
		
		
		global $_CFG;
		$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
		$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));
		
		
		
		if( $_CFG["ProjectName"] == $project_path_split )
			return;
		
		
		$queue_name = 'eshowgulecmd';
		$httpsqs = new httpsqs( $ip , $port , '' , "utf-8" );
		
		//$parm = array( 'id'=>$id,'ip'=>$ips);
		$parm_str = base64_encode( json_encode( $parm ));
		
		$push_arr = array(
								//'url'=>'http://10.160.15.151/eshow/countare',
								'url'=>$url,
								'parm'=>$parm_str                 
		
							);
		
		$push_arr_str = json_encode( $push_arr ) ;
		
		
		if(!empty($httpsqs))
		{
			
			$httpsqs->put($queue_name,urlencode($push_arr_str));
			
		}else{
			
		}
		
		
	}
	
	
	static function sendcountq($id,$ips){
		
		$ip = '10.161.145.188';
		$port = '22148';
		
		
		global $_CFG;
		$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
		$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));
		
		
		
		if( $_CFG["ProjectName"] == $project_path_split )
			return;
		
		
		$queue_name = 'eshowgulecmd';
		$httpsqs = new httpsqs( $ip , $port , '' , "utf-8" );
		
		$parm = array( 'id'=>$id,'ip'=>$ips);
		$parm_str = base64_encode( json_encode( $parm ));
		
		$push_arr = array(
								'url'=>'http://10.160.15.151/eshow/countare',
								'parm'=>$parm_str                 
		
							);
		
		$push_arr_str = json_encode( $push_arr ) ;
		
		
		if(!empty($httpsqs))
		{
			log_message( 'info' , '准备写入队列------'.$ip .'  ---------- '.$port );
			$httpsqs->put($queue_name,urlencode($push_arr_str));
			
		}else{
			log_message('info','httpsqs服务器无法连接!请检查问题！');
		}
		
		
	}
	
	
	
	
	static function set_visit_info($method,$fetchclass){
		
		$no_rport = array('localhost','demo.eshowpro.com','192.168.10.103','www.efacebookpro.com');
		
		global $_CFG;
		$cmp_id = $_CFG['cmp_id'];
		$website  = $_SERVER['HTTP_HOST'];
		
		if( !in_array($website,$no_rport) && $method != 'visitinfo' ){
			
			
			$v = array('chl'=>11,'cm'=>$cmp_id,'h'=>$website,'f'=>$fetchclass,'m'=>$method,'ip'=>$_SERVER['REMOTE_ADDR'],'l'=>$_SERVER['HTTP_ACCEPT_LANGUAGE'],'d'=>date("YmdHis"),'iid'=>$_REQUEST['itemid']);
			$redis = Nosqlhelp::getredis4parmT('127.0.0.1',6379,2);
			
			$id = rand(10000,1000000);
			$viinfo = json_encode($v);
			$redis->hSet('visitcache',$id,$viinfo);
			
			
			$redis->close();
		}
		
		
	}
	
	/**
	 * wap URL 转化为
	 *
	 * @param unknown_type $websiteurl
	 */
	static function mobileUrl2WebUrl($cmpid,$method){
		
		
		//$jump_url = $websiteurl;
		$dao = new CommonDao4sSelf('','','','');
		
		$cmp = $dao->getRowByPk('company','share_webutl','id',$cmpid,'');
		$jump_url = $cmp['share_webutl'];
		$websiteurl = $cmp['share_webutl'];
		
		
		if( empty($jump_url) ){
			
			return '';
		
		}else{
			
			if( $method =='index'  ){
				$jump_url = $websiteurl;
			}elseif($method == 'product_type'){
					$jump_url = "$websiteurl/products";	
			}elseif($method == 'pt'){
					
					$id = $_GET['id'];
					$urlparm = getLangColumnFalg('urlparm');
					$pro = $dao->getRowByPk('cmp_product',"$urlparm",'id',$id,'');
					$urlp = $pro['urlparm_en'];
					$jump_url = "$websiteurl/prodetail/$id-$urlp";
						
			}elseif($method == 'newsdetail'){
					
					$id = $_GET['id'];
					$urlparm = getLangColumnFalg('urlparm');
					$pro = $dao->getRowByPk('cmp_news',"$urlparm",'id',$id,'');
					$urlp = $pro['urlparm_en'];
					$jump_url = "$websiteurl/news_detail/$id-$urlp";
						
			}
			
			//保存，并发送到队列
			$cmp_wap_visit = array(   
									'cmp_id' =>$cmpid, 
									'agent'=>$_SERVER['HTTP_USER_AGENT'],
									'visitdt'=>date('Y-m-d H:i:s'),
									'visitdtstr'=>date('Ymd'),
									'years'=>date('Y'),
									'months'=>date('m'),
									'days'=>date('d'),
									'hours'=>date('H'),
									'visitip'=>$_SERVER['REMOTE_ADDR'],
									'types'=>$_GET['type']
								   );	
								   								
			$dao = new CommonDao4sSelf('','','','');			
			$id = $dao->saveRow('cmp_wap_visit',$cmp_wap_visit,'');
			
			EshowCommon::sendcountq($id,$_SERVER['REMOTE_ADDR']);
			
			
			
			return $jump_url;
		}
		
		
		
	}
	
	
	/**
	 * 2015年5月21日 
	 * 
	 * 发送eshow推送，新版改进，主要解决，新版app，普通发送和应用插件发送的融合问题。
	 *
	 * @param unknown_type $userid       用户编号
	 * @param unknown_type $pushtypeid   业务编号
	 * @param unknown_type $pushcontent  推送内容
	 * @param unknown_type $pushtitle    推送标题
	 * @param unknown_type $url          $url
	 * @param unknown_type $plugname     插件名称
	 */
	static function sendPushNew( $userid  , $pushtypeid , $pushcontent , $pushtitle , $event ,$cmp_id,$pushtype){
			
		
	
		
		$dao = new CommonDao4sSelf('','','','');
		
		$cmp_manager = $dao->getRowByPk('cmp_manager','','id',$userid,'');
		$lastlogintype = $cmp_manager['lastlogintype'];
		
		
		
		$cmp_pushlist = array(
												
								'content'=>$pushcontent,
								'title'=>$pushtitle,
								'event'=>$event			
						      );
					
					
	    $cmp_pushlist['cmp_id'] = $cmp_id;
	    $cmp_pushlist['pushtype']  = $pushtype;
	    $cmp_pushlist['pushtypeid']  = $pushtypeid;
	    $cmp_pushlist['regdatetime']  = 'now()';

	    $dao->saveRow('cmp_pushlist' , $cmp_pushlist,'');
	
		//echo "新版工作台推送";
		$company = $dao->getRowByPkOne('select * from company where id = '.$cmp_id,'');		
		
		$dao = new CommonDao4sSelf('','','','');
		$imi = $cmp_manager['imi'];
		
		
		if( !empty($imi) ){
			
			
			$sql = " select * from cmp_member where member_id = '$imi' and cmp_id = $cmp_id ";
			$cmp_mem = $dao->getRowsBySQlCase($sql,'');
			//echo $sql;
			
			$memid = $cmp_mem[0]['id'];
			
			$opterlog = array(
								   'userid'=>$cmp_id , 
				                   'serid'=>$company['iphoneser'],
								   'serid_ios'=>$company['iphoneser_ios'],
				                   'sendContant'=>base64_encode($pushtitle),
								   'sendContant_en'=>base64_encode($pushtitle),
				                   'sendContant_x'=>base64_encode($pushtitle),
								   'sendContant_x1'=>base64_encode($pushtitle),
								   'sendContant_x2'=>base64_encode($pushtitle),
								   'lang'=>$_SESSION['select_lan'],
								   'pushtype'=>0,
								   'pushtypeid'=>$pushid,
								   'sendtypeExt'=>$memid,
								   'sendtype'=>'1'
							  );
							  
			$opterlog_str = json_encode($opterlog);
			
			global $_CFG;
			$httpsqs = new httpsqs( $_CFG['httpsqs']['ip'] , $_CFG['httpsqs']['port'] , '' , "utf-8" );
			if(!empty($httpsqs))
			{
				$httpsqs->put($_CFG['httpsqs']['queue'],urlencode($opterlog_str));
			}else{
				log_message('info','httpsqs服务器无法连接!请检查问题！');
			}
			
			
			
			
		}
		
		
		
		
	}
	
	
	/**
	 * 发送eshow推送
	 *
	 * @param unknown_type $userid
	 * @param unknown_type $plugid
	 * @param unknown_type $pushcontent
	 * @param unknown_type $pushtitle
	 * @param unknown_type $url
	 * @param unknown_type $plugname
	 */
	static function sendPush( $userid  , $plugid , $pushcontent , $pushtitle , $url , $plugname ,$cmp_id){
			
		
		//$cmp_id =  $_SESSION['usermember']['cmp_id'];
		//$login_id = $_SESSION['login_manager']['id'];
		
		//$userid = 61;
		//$plugid = 7;
		
		$dao = new CommonDao4sSelf('','','','');
		
		$cmp_manager = $dao->getRowByPk('cmp_manager','','id',$userid,'');
		$lastlogintype = $cmp_manager['lastlogintype'];
		
		
		
		if( $lastlogintype == '0' ){   //老版本工作登录用户
			
				global $_CFG;
				$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
				$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));
				
				
				
				if( $_CFG["ProjectName"] == $project_path_split ){
					$ip = '10.160.15.151';
					$port = '22142';
				}else{
					$ip = '10.161.145.188';
					$port = '22143';
				}
				
				$plug_push = array(							
										'cmp_id'=>$cmp_id,
										'userid'=>$userid,
										'plugid'=>$plugid,
										'loginname'=>'ser2091',
										'createdt'=>'now()',
										'lastopendt'=>'',
										'pushcontent'=>$pushcontent,
										'pushtitle' =>$pushtitle,
										'ifurl'=>'didf',
										'url'=>$url
									);
				
				
				$pushid = $dao->saveRow('plug_push',$plug_push,'');
				
				$event_arr = array('plugid'=>$plugid,'plugname'=>$plugname);
				$event_arr_str = json_encode($event_arr);
				
				
				$push_arr = array(
										'cmp_id'=>$cmp_id,
										'plugid'=>$plugid,
										'pushid'=>$pushid,
										'pushtype'=>'1', //0-公共推送 1-单点推送 3-小组推送
										'userid'=>$userid,    //用户编号
										'pushcontent'=>base64_encode($plug_push['pushtitle']), //推送内容
										'pushextd'=>'', //发送类型的扩展数据
										'ifappstore'=>'0', //是否为IOS  0-非appstore   1-appstore
										'pushEvent'=>base64_encode($event_arr_str), //推送事件
										'pushTitle'=>$plugname."提示您有新消息" //发送标题                       
				
									);
				
				$push_arr_str = json_encode( $push_arr );
				
				
				
				
				$queue_name = 'link16pushcmd';
				$httpsqs = new httpsqs( $ip , $port , '' , "utf-8" );
				
				if(!empty($httpsqs))
				{
					log_message( 'info' , '准备写入队列------'.$ip .'  ---------- '.$port );
					$httpsqs->put($queue_name,urlencode($push_arr_str));
					
				}else{
					log_message('info','httpsqs服务器无法连接!请检查问题！');
				}
				
			
		}else{  //新版本移动工作台的推送
				
				
				$cmp_pushlist = array(
																
												'content'=>$pushcontent,
												'title'=>$pushtitle
												
									   );
					
					
			    $cmp_pushlist['cmp_id'] = $cmp_id;
			    //$cmp_pushlist['remark']  = $_POST['remark'];	
			    $cmp_pushlist['pushtype']  = $plugid;
			    $cmp_pushlist['pushtypeid']  = $_POST['pushtypeid'];
			    $cmp_pushlist['regdatetime']  = 'now()';

			    $dao->saveRow('cmp_pushlist' , $cmp_pushlist,'');
			
				//echo "新版工作台推送";
				$company = $dao->getRowByPkOne('select * from company where id = '.$cmp_id,'');		
				/*$opterlog = array(
								   'userid'=>$cmp_id , 
				                   'serid'=>$company['iphoneser'],
								   'serid_ios'=>$company['iphoneser_ios'],
				                   'sendContant'=>base64_encode($pushtitle),
								   'sendContant_en'=>base64_encode($pushtitle),
				                   'sendContant_x'=>base64_encode($pushtitle),
								   'lang'=>$_SESSION['select_lan'],
								   'pushtype'=>0,
								   'pushtypeid'=>$cmp_push['pushtypeid'],
								   'sendtype'=>'0'
								  );*/

				/**
				 * $opterlog = array(
									   'userid'=>$cmp_id , 
					                   'serid'=>$company['iphoneser'],
									   'serid_ios'=>$company['iphoneser_ios'],
					                   'sendContant'=>base64_encode($cmp_push['title']),
									   'sendContant_en'=>base64_encode($cmp_push['title_en']),
					                   'sendContant_x'=>base64_encode($cmp_push['title_x']),
									   'sendContant_x1'=>base64_encode($cmp_push['title_x1']),
									   'sendContant_x2'=>base64_encode($cmp_push['title_x2']),
									   'lang'=>$_SESSION['select_lan'],
									   'pushtype'=>$cmp_push['pushtype'],
									   'pushtypeid'=>$cmp_push['pushtypeid'],
									   'sendtypeExt'=>$cmp_push['memberid'],
									   'sendtype'=>'1'
								  );
				 */
				$dao = new CommonDao4sSelf('','','','');
				$imi = $cmp_manager['imi'];
				
				
				if( !empty($imi) ){
					
					
					$sql = " select * from cmp_member where member_id = '$imi' and cmp_id = $cmp_id ";
					$cmp_mem = $dao->getRowsBySQlCase($sql,'');
					//echo $sql;
					
					$memid = $cmp_mem[0]['id'];
					
					$opterlog = array(
										   'userid'=>$cmp_id , 
						                   'serid'=>$company['iphoneser'],
										   'serid_ios'=>$company['iphoneser_ios'],
						                   'sendContant'=>base64_encode($pushtitle),
										   'sendContant_en'=>base64_encode($pushtitle),
						                   'sendContant_x'=>base64_encode($pushtitle),
										   'sendContant_x1'=>base64_encode($pushtitle),
										   'sendContant_x2'=>base64_encode($pushtitle),
										   'lang'=>$_SESSION['select_lan'],
										   'pushtype'=>0,
										   'pushtypeid'=>$pushid,
										   'sendtypeExt'=>$memid,
										   'sendtype'=>'1'
									  );
									  
					$opterlog_str = json_encode($opterlog);
					
					global $_CFG;
					$httpsqs = new httpsqs( $_CFG['httpsqs']['ip'] , $_CFG['httpsqs']['port'] , '' , "utf-8" );
					if(!empty($httpsqs))
					{
						$httpsqs->put($_CFG['httpsqs']['queue'],urlencode($opterlog_str));
					}else{
						log_message('info','httpsqs服务器无法连接!请检查问题！');
					}
					
					
					
					
				}
					
				
				
				
			
		}
		
		
		
		
		
	}
	
	
	
	/**
	 * 获取ESHOW后台的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function getcumupurl ($method){
		
		$url = "http://link16wap.eshowpro.com/crmup/".$method;
		
		return $url;
		
	}
	
	
	/**
	 * 获取ESHOW后台的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function geteshowurl ($method){
		
		$url = "http://link16wap.eshowpro.com/clientstat/".$method;
		
		return $url;
		
	}
	
	/**
	 * 获取小秘书的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function getsecreurl ($method){
		
		$url = "http://link16wap.eshowpro.com/secretary/".$method;
		
		return $url;
		
	}
	
	
	/**
	 * 获取小秘书的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function getworkorderurl_yw ($method){
		
		$url = "http://link16wap.eshowpro.com/yw_order/".$method;
		
		return $url;
		
	}
	
	
	/**
	 * 获取小秘书的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function getworkorderurlnew ($method,$fecht){
		
		$url = "http://link16wap.eshowpro.com/$fecht/".$method;
		
		return $url;
		
	}
	
	
	/**
	 * 获取小秘书的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function getworkorderurl ($method){
		
		$url = "http://link16wap.eshowpro.com/workorderking/".$method;
		
		return $url;
		
	}
	
	
	/**
	 * 获取无线订单的URL
	 *
	 * @param unknown_type $method
	 * @return unknown
	 */
	static  function getorderurl ($method){
		
		$url = "http://link16wap.eshowpro.com/work/".$method;
		
		return $url;
		
	}
	
	
	static function getEshowImServer(){
		
		return "112.124.99.107:18000";
	}
	
	
	
	
    static function uploadfiles($tempFile,$filename,$targetPath){
		
		
    		//$MODLEARRAY = array('1'=>'leader','2'=>'protype','3'=>'pro','4'=>'glory','5'=>'ckedit','6'=>'jxs','7'=>'cmp');
    		 $screenw=480;
			$screenh=10800;
	
	
	 		$screenw1=360;
			$screenh1=600;
    		
			$secd = $_GET['secd'];
			$cmpid = $secd;
			$mod = $_GET['mod'];
			$id = $_GET['id'];
			
			if( empty($id) ){
				$id='0';	
			}
			
			$fileporpery = 'Filedata';
			
			if( $mod == '5' )
			   	$fileporpery = 'imgFile';
			
			$targetFolderf1 = 	'/uploads/';
			//$targetFolder = $targetFolderf1.$MODLEARRAY[$mod].'/'; // Relative to the root
		
			$verifyToken = md5('unique_salt' . $_POST['timestamp']);
			
		
			log_message('info','###############################');
			
			if( $mod == '5' ){
				
			
				//$tempFile = $_FILES[$fileporpery]['tmp_name'];
				//$targetPath = REALPATH. $targetFolder;
				
				//$filename =  $_FILES[$fileporpery]['name'];
				$filetype  = substr ( $filename, strrpos ( $filename, '.' ), strlen ( $filename ) );
				$filetype1  = substr ( $filename, strrpos ( $filename, '.' )+1, strlen ( $filename ) );
				$uuid = uniqid('',true);
				$uuid = str_replace('.','a',$uuid);
				$filename = $cmpid.'_'.$mod.'_'.$id.'_'.$uuid.$filetype;
				
				$targetFile = rtrim($targetPath,'/') . '/' . $filename;
				
				// Validate the file type
				$fileTypes = array('jpg','jpeg','gif','png'); // File extensions
				$fileParts = pathinfo($filename);
				
				if (in_array(strtolower($fileParts['extension']),$fileTypes)) {
										
					$fdfs = new FastDFS();		
		 			$tracker = $fdfs->tracker_get_connection();	
					$server = $fdfs->connect_server($tracker['ip_addr'], $tracker['port']);
					//$file_info = $fdfs->storage_upload_by_filename(//$tempFile);
					
					
					//压缩图片
					
				$size = getimagesize($tempFile);
				log_message('info','上传文件类型  '.$filetype.'  高度  '.$size[1].'  宽度  '.$size[0]);
				
				
				$heigth = $size[1];
				$width = $size[0];
				
				
				if(  $heigth > $screenh1 && $width > $screenw1 ){
						
						log_message('info',' ******************** mod 5  准备对上传图片进行压缩处理    '.$filetype.'  高度  '.$size[1].'  宽度  '.$size[0]);
						
						if( strtolower($filetype) == '.jpg' ){
							$filetype_2 = 'image/pjpeg';
						}elseif(strtolower($filetype) == '.png'){
							$filetype_2 = 'image/x-png';
						}elseif(strtolower($filetype) == '.gif'){
							$filetype_2 = 'image/gif';
						}else{
							$filetype_2 = 'image/pjpeg';
						}
						
						$minname_temp = 'temp_'.$filename;
						$targetFile_temp = rtrim($targetPath,'/') . '/' . $minname_temp;
						
						$imgegav = EshowCommon::imageGap($width,$heigth);
						$rz_w_t = $width*$imgegav;
						$rz_h_t = $heigth * $imgegav;
						
						changeimagesize($filetype_2,$tempFile,$targetFile_temp,$rz_w_t,$rz_h_t);
						$file_id  = $fdfs->storage_upload_by_filename1($targetFile_temp,$filetype1,array());
						
						
					}else{
						$file_id  = $fdfs->storage_upload_by_filename1($tempFile,$filetype1,array());
					}
					
					
					
					$fdfs->disconnect_server($server);
					
					//$group_name = $file_info['group_name'];
					$remote_filename = $file_id;
					$remote_filename_s = substr($remote_filename,6,strlen($remote_filename));
					
					log_message('info','##################### 集成存文件  group_name:'.$remote_filename_s.' remote_filename : '.$remote_filename);
					
					//根据FASTDFS服务器返回用文件，生成上传文件名，作为备用，该功能将在后台取消，所有资源均存入FASTDFS集中式服务器中
					$remote_filename_s_urlen = base64_encode($remote_filename_s);
					$targetFile = rtrim($targetPath,'/') . '/' . $remote_filename_s_urlen.$filetype;
					
					move_uploaded_file($tempFile,$targetFile);
					
					//move_uploaded_file($tempFile,$targetFile);
					
					/*$dao = new CommonDao4sSelf('','','','');
					$sql = "update cmp_leader set pic = '$filename' where id = $id";
					$dao->updateBySql($sql,'');*/
					global $_CFG;
					
					if( $_CFG['SOURCE_TYPE'] == 0 ){
						if( $_CFG['DEPLOY'] == '0' )
							$df = array("error"=>0,"message"=>".....","url"=>"/".$_CFG["ProjectName"]."/uploads/ckedit/$filename");
						else
							$df = array("error"=>0,"message"=>".....","url"=>"/uploads/ckedit/$filename");
					}else{
							$df = array("error"=>0,"message"=>".....","url"=>$_CFG['SOURCE_ROOT'].$remote_filename_s);
					}
					
					//$d = HTTP_DOCMENT_ROOT;
					//$sqld = "<script type=\"text/javascript\">window.parent.CKEDITOR.tools.callFunction(2, '/uploads/ckedit/$filename', '');</script>";
					//echo $filename;
					return  $df;
				} else {
					return array("error"=>1);
				}
		
				
				
			}else{
				
			if ( $_POST['token'] == $verifyToken) {
				
				
				$max_file_size = 0;
				
				$pic_min_h=0;
				$pic_min_w=0;
				
				
				//$tempFile = $_FILES[$fileporpery]['tmp_name'];
				//$targetPath = REALPATH. $targetFolder;
				
				//$filename =  $filename;
				$filetype  = substr ( $filename, strrpos ( $filename, '.' ), strlen ( $filename ) );
				$filetype1  = substr ( $filename, strrpos ( $filename, '.' )+1, strlen ( $filename ) );
				
				//以下代码基本无用，暂时保留
				$uuid = uniqid('',true);
				$uuid = str_replace('.','a',$uuid);
				$filename = $cmpid.'_'.$mod.'_'.$id.'_'.$uuid.$filetype;
				$targetFile = rtrim($targetPath,'/') . '/' . $filename;
				
				// Validate the file type
				$fileTypes = array('jpg','jpeg','gif','png',); // File extensions
				$fileParts = pathinfo($filename);
				
				
				// ===============   对图片进行压缩操作  ================
					
					$size = getimagesize($tempFile);
					log_message('info','上传文件类型  '.$filetype.'  高度  '.$size[1].'  宽度  '.$size[0]);
					
					
					$heigth = $size[1];
					$width = $size[0];
				
				if (in_array(strtolower($fileParts['extension']),$fileTypes)) {
					
					
			
					
					//首先把图存储到FASTDFS存储服务器中
					$fdfs = new FastDFS();		
		 			$tracker = $fdfs->tracker_get_connection();	
					$server = $fdfs->connect_server($tracker['ip_addr'], $tracker['port']);
					//$file_info = $fdfs->storage_upload_by_filename($tempFile);
					
					
					//判断图片是否需要压缩
					
					
					
					//如果图片大于规定图片，则系统需要对图片进行压缩处理
					if(  $heigth > $screenh && $width > $screenw ){
						
						
						log_message('info','###############  准备对上传图片进行压缩处理    '.$filetype.'  高度  '.$size[1].'  宽度  '.$size[0]);
						
						if( strtolower($filetype) == '.jpg' ){
							$filetype_2 = 'image/pjpeg';
						}elseif(strtolower($filetype) == '.png'){
							$filetype_2 = 'image/x-png';
						}elseif(strtolower($filetype) == '.gif'){
							$filetype_2 = 'image/gif';
						}else{
							$filetype_2 = 'image/pjpeg';
						}
						
						$minname_temp = 'temp_'.$filename;
						$targetFile_temp = rtrim($targetPath,'/') . '/' . $minname_temp;
						
						$imgegav = EshowCommon::imageGap($width,$heigth);
						$rz_w_t = $width*$imgegav;
						$rz_h_t = $heigth * $imgegav;
						
						log_message('info','##################### 文件压缩比率 :'.$imgegav.'  --    : '.$rz_w_t .'  ---   '.$rz_h_t);
						
						
						changeimagesize($filetype_2,$tempFile,$targetFile_temp,$rz_w_t,$rz_h_t);
						
						//$tempFile = $targetFile_temp;
						$file_id  = $fdfs->storage_upload_by_filename1($targetFile_temp,$filetype1,array());
					
						$max_file_size = filesize($targetFile_temp);	
						
					}else{ 				
					
						$file_id  = $fdfs->storage_upload_by_filename1($tempFile,$filetype1,array());
						$max_file_size = filesize($tempFile);	
						
						
					}
					//$group_name = $file_info['group_name'];
					$remote_filename = $file_id;
					$remote_filename_s = substr($remote_filename,6,strlen($remote_filename));
					
					log_message('info','##################### 集中存文件  group_name:'.$remote_filename_s.' remote_filename : '.$remote_filename);
					
					//根据FASTDFS服务器返回用文件，生成上传文件名，作为备用，该功能将在后台取消，所有资源均存入FASTDFS集中式服务器中
					$remote_filename_s_urlen = base64_encode($remote_filename_s);
					//$targetFile = rtrim($targetPath,'/') . '/' . $remote_filename_s_urlen.$filetype;
					$targetFile = $tempFile;
					//echo " ----- $targetFile";
					//move_uploaded_file($tempFile,$targetFile);				
					
					
					$minname = 'm_'.$filename;
					$targetFile_m = rtrim($targetPath,'/') . '/' . $minname;
					//120 200
					
					if( strtolower($filetype) == '.jpg' ){
						$filetype1 = 'image/pjpeg';
					}elseif(strtolower($filetype) == '.png'){
						$filetype1 = 'image/x-png';
					}elseif(strtolower($filetype) == '.gif'){
						$filetype1 = 'image/gif';
					}else{
						$filetype1 = 'image/pjpeg';
					}
					
					if( $heigth == $width  ){
						$rz_h = 200;
						$rz_w = 200;
					}elseif( $heigth > $width ){
						$rz_h = 200;
						$rz_w = 120;
					}elseif( $heigth < $width ){
						$rz_h = 120;
						$rz_w = 200;
					}
					
					$generated_file_id = $fdfs->gen_slave_filename($file_id, $filetype.'_m'.$filetype, '');
					$generated_file_id_s_1 = substr($generated_file_id,6,strlen($generated_file_id));
					$generated_file_id_s = base64_encode($generated_file_id_s_1);
					$targetFile_m = rtrim($targetPath,'/') . '/' . $generated_file_id_s.$filetype;
					
					if( $heigth > 200 && $width > 200 ){
						
						
						$imgegav = EshowCommon::imageGap($width,$heigth);
						$rz_w = floor($width*$imgegav);
						$rz_h = floor($heigth * $imgegav);
						
						log_message('info','##################### 文件压缩比率 :'.$imgegav.'  --    : '.$rz_w_t .'  ---   '.$rz_h_t);
						
						changeimagesize($filetype1,$targetFile,$targetFile_m,$rz_w,$rz_h);
					    $slave_file_id = $fdfs->storage_upload_slave_by_filename1($targetFile_m, $file_id, $filetype.'_m'.$filetype, '');
					    
	    				$pic_min_h=$rz_h;
						$pic_min_w=$rz_w;
					    
					}else{
						$slave_file_id = $fdfs->storage_upload_slave_by_filename1($targetFile, $file_id, $filetype.'_m'.$filetype, '');
						$pic_min_h=$heigth;
						$pic_min_w=$width;
					}
					/*$fdfs->disconnect_server($server);
					$tracker = $fdfs->tracker_get_connection();	
					$server = $fdfs->connect_server($tracker['ip_addr'], $tracker['port']);*/
					
					//$slave_file_id = $fdfs->storage_upload_slave_by_filename1($targetFile_m, $file_id, $filetype.'_m'.$filetype, '');
					$slave_file_id = $fdfs->storage_upload_slave_by_filename1($targetFile_m, $file_id, $filetype.'_m'.$filetype, '');
					
					log_message('info','##################### 集成存文件  压缩文件名:'.$slave_file_id );
					
					$fdfs->disconnect_server($server);
					
					global $_CFG;
					$imagrog = $_CFG['SOURCE_ROOT'];
					$df = array("error"=>0,"message"=>".....",'filename'=>$remote_filename_s_urlen.$filetype.',,'.$pic_min_h.'*'.$pic_min_w.',,'.$max_file_size,'url'=>$imagrog.$generated_file_id_s_1);
					//$df_str = json_encode($df);
					return $df;
					
				} else {
					echo array("error"=>1);
				}
			}else{
				echo array("error"=>1);
			}
				
			}
		}

		/**
		 * hi
		 *
		 * @param unknown_type $bitmapWidth
		 * @param unknown_type $bitmapHeight
		 * @return unknown
		 */
		static function imageGap($bitmapWidth , $bitmapHeight){

				/*$screenW=$this->screenw;
				$screenH=$this->screenh;
				
				$inedx = $bitmapWidth > $bitmapHeight ? $bitmapWidth : $bitmapHeight;
				$index_f = $bitmapWidth > $bitmapHeight ? $screenW : $screenH;
				$scale = $index_f / $inedx;
				return $scale;*/
			
			//$screenW=$this->screenw;
			$screenW=200;
			if( $bitmapWidth <= $screenW )
				return 1;
			else 
				return $screenW/$bitmapWidth;
				
		}
		
		
		static function imageGap1($bitmapWidth , $bitmapHeight){
			
			$screenW=200;
			if( $bitmapWidth <= $screenW )
				return 1;
			else 
				return $screenW/$bitmapWidth;
			
	
		}
		
		
		/////////////////////////////// 获取树状结构的系统模块名单 ////////////////////////////////
		
		
		
	//////// 选择人员组织结构数状结构   //////////////////////////////////////////////
	static function getSysModuleTreeHtml($json_tree,$id,$selectvalue){
		
		$json_tree_arr = json_decode($json_tree,true);
		
		array_unshift($json_tree_arr,array('id'=>'-1','name'=>"======无类型======"));
		
		$ddd = array();
		
		foreach ( $json_tree_arr as $item ){
			
		
			$child = $item['children'];
			array_push($ddd,	array('id'=>$item['id'],'name'=>$item['name']));
			
			if( !empty($child)  ){
					
					foreach ( $child as $item1  ){
						
						array_push($ddd,	array('id'=>$item1['id'],'name'=>"&nbsp;&nbsp;|--".$item1['name']));
						
							$child1 = $item1['children'];
							if( !empty($child1)  ){
								
								foreach ( $child1 as $item2  ){
										array_push($ddd,array('id'=>$item2['id'],'name'=>"&nbsp;&nbsp;|----".$item2['name']));

										$child2 = $item2['children'];
										if( !empty($child2)  ){
											
												foreach ( $child2 as $item3  ){
													array_push($ddd,array('id'=>$item3['id'],'name'=>"&nbsp;&nbsp;|------".$item3['name']));
													
													    $child3 = $item3['children'];
													    if( !empty($child3)  ){

													    	foreach ( $child3 as $item4  ){
													    		array_push($ddd,array('id'=>$item4['id'],'name'=>"&nbsp;&nbsp;|--------".$item4['name']));
													    	}
													    	
													    }
														
												}
										}
								}
								
							}
						
					}
				
				
			}else{
				
				
			}
			
			
		}
		
		$manaer_select = htmlSelect($ddd, $id, '', $selectvalue, '', "id,name");
		
		return $manaer_select;
	}
	
	static function getSysModuleTreeList($json_tree,$id,$selectvalue){
		
		$json_tree_arr = json_decode($json_tree,true);
		
		//array_unshift($json_tree_arr,array('id'=>'-1','name'=>"======无类型======"));
		
		$ddd = array();
		
		foreach ( $json_tree_arr as $item ){
			
		
			$child = $item['children'];
			array_push($ddd,	array('id'=>$item['id'],'name'=>$item['name']));
			
			if( !empty($child)  ){
					
					foreach ( $child as $item1  ){
						
						array_push($ddd,	array('id'=>$item1['id'],'name'=>"&nbsp;&nbsp;|--".$item1['name']));
						
							$child1 = $item1['children'];
							if( !empty($child1)  ){
								
								foreach ( $child1 as $item2  ){
										array_push($ddd,array('id'=>$item2['id'],'name'=>"&nbsp;&nbsp;|----".$item2['name']));

										$child2 = $item2['children'];
										if( !empty($child2)  ){
											
												foreach ( $child2 as $item3  ){
													array_push($ddd,array('id'=>$item3['id'],'name'=>"&nbsp;&nbsp;|------".$item3['name']));
													
													    $child3 = $item3['children'];
													    if( !empty($child3)  ){

													    	foreach ( $child3 as $item4  ){
													    		array_push($ddd,array('id'=>$item4['id'],'name'=>"&nbsp;&nbsp;|--------".$item4['name']));
													    	}
													    	
													    }
														
												}
										}
								}
								
							}
						
					}
				
				
			}else{
				
				
			}
			
			
		}
		
	
		
		return $ddd;
	}
	
	
		/**
	 * 获取用户产品类型的json树
	 *
	 * @param unknown_type $pro_types
	 * @return unknown
	 */
	static function getSysModuleTreeJson($pro_types){
		
		
		
		$pro_type_idmap = array();
		$pro_type_tree = array();
		$pro_type_treemap = array();
		
		$pro_type_treeitem1 =  array('checked'=>true,'id'=>'0','pId'=>'-1','name'=>'所有类型','open'=>true);
		
		$lan =  $_SESSION['select_lan'];
		$name = 'name'.$lan;
		
		//对数组进行相关排序
		$count = count($pro_types); 
		if ($count > 0) {		    
			    for($i=0; $i<$count; $i++){ 
			        for($j=$count-1; $j>$i; $j--){ 
			            if ($pro_types[$j]['parentid'] < $pro_types[$j-1]['parentid']){ 
			                $tmp = $pro_types[$j]; 
			                $pro_types[$j] = $pro_types[$j-1]; 
			                $pro_types[$j-1] = $tmp; 
			            } 
			        } 
			    } 
		  }
		  
		 //$result = array();
		 //定义索引数组，用于记录节点在目标数组的位置  
		// $I = array();	 

	  
		//		for( $ind=count($pro_types)-1 ; $ind>0;$ind-- ){
		//
		//			$pro_type = 	$pro_types[$ind];
		//			$pro_type_treeitem =  array('checked'=>true,'id'=>$pro_type['id'],'pId'=>$pro_type['parentid'],'name'=>$pro_type['name'],'open'=>true);
		//			$pro_type_idmap[$pro_type['id']] = $pro_type;
		//			//$pro_type_treemap[$pro_type['id']] = $pro_type_treeitem;
		//			array_push($pro_type_treemap,$pro_type_treeitem);	
		//			
		//		}
		    
	  	foreach ($pro_types as $pro_type){
			
			$pro_type_treeitem =  array('ispar'=>0,'checked'=>true,'id'=>$pro_type['id'],'pId'=>$pro_type['parentid'],'name'=>$pro_type[$name],'open'=>true);
			$pro_type_idmap[$pro_type['id']] = $pro_type;
			//$pro_type_treemap[$pro_type['id']] = $pro_type_treeitem;
			array_push($pro_type_treemap,$pro_type_treeitem);	
			
		}
	    
		//print_r($pro_type_treemap)
			
		foreach($pro_type_treemap as $val) {
			
			  if($val['pId'] == 0) {
			  	    $children = EshowCommon::getTreeChild($pro_type_treemap,$val['id']);
			  	    //echo count($children);
			  	    if(  count($children)>0){ 
				  		$val['children'] = $children;
				  		$val['ispar'] = 1;
			  	    }
			  	    
			  	    array_push($pro_type_tree,$val);
			  }
			  
			  
		}
	    
/*		foreach($pro_type_treemap as $val) {
		    if($val['pId'] == 0) {
		      $i = count($pro_type_tree);
		      $pro_type_tree[$i] = $val;
		      $I[$val['id']] = & $pro_type_tree[$i];
		    } else {
		      $i = count($I[$val['pId']]['children']);
		      $I[$val['pId']]['children'][$i] = $val;
		      $I[$val['id']] = & $I[$val['pId']]['children'][$i];
		    }
		 }*/
			
		$pro_type_treeitem1['children']   = $pro_type_tree;
		
		$json_tree = json_encode($pro_type_tree);
		
		return $json_tree;
	}
	
	
 	static function getTreeChild(&$treearray , $parentid){
		
		$treeChild = array();
		
		foreach ( $treearray as $treeitem ){
			
			if( $treeitem['pId'] == $parentid  ) {
				
					$c_child = EshowCommon::getTreeChild($treearray,$treeitem['id']);
					  if(  count($c_child)>0){ 
						$treeitem['children'] = $c_child;
						$treeitem['ispar'] = 1;
					  }
					array_push($treeChild,$treeitem);
				
			}
			
		}
		
		return $treeChild;
		
	}
		
		
	static function getSysModuleTree($sql_modules){	
		
	
		$dao = new CommonDao4sSelf('','','','');
		$pro_types = $dao->getRowsBySQl($sql_modules,'','','');
		$json_tree = EshowCommon::getSysModuleTreeJson($pro_types);
		return  EshowCommon::getSysModuleTreeList( $json_tree , '','');
		
		
	}
	
	
	/**
	 * 
	 * 数据检索任务的结果发送到的爬虫队列，让爬虫准备爬取数据
	 *
	 * @param unknown_type $taskid
	 * @param unknown_type $pageid
	 * 
	 */
	static function sendSearchQueue($pageid){
		
		$ip = '10.161.145.188';
		$port = '22190';
		
		
		
		log_message( 'info' , " (  sendSearchQueue  ) 准备写入队列： $pageid  ");	
			
			
		$dao = new CommonDao4sSelf('','','','');
		$marketing_edm_keys_search = $dao->getRowByPk('marketing_edm_keys_search','taskid','id',$pageid,'');
		$taskid = $marketing_edm_keys_search['taskid'];
		
		$queue_name = 'search_task_'.$taskid;
		$httpsqs = new httpsqs( $ip , $port , '' , "utf-8" );
		
		$parm = array( 'pageid'=>$pageid );
		$parm_str = base64_encode( json_encode( $parm ));
		
		log_message( 'info' , " (  sendSearchQueue  ) 准备写入队列： ".$queue_name);
		
		/*$push_arr = array(
								'url'=>'http://10.160.15.151/eshow/countare',
								'parm'=>$parm_str                 
		
							);
		
		$push_arr_str = json_encode( $push_arr ) ;*/
		
		
		if(!empty($httpsqs))
		{
			log_message( 'info' , '准备写入队列------'.$ip .'  ---------- '.$port );
			$httpsqs->put($queue_name,urlencode($parm_str));
			
		}else{
			log_message('info','httpsqs服务器无法连接!请检查问题！');
		}
		
		
	}
	
	
	/**
	 * 
	 * 从队列中获取检索到的数据
	 * 
	 * HTTPSQS_GET_END  这个表示队列中的数据已经被处理完毕
	 * 
	 */
	static function getSearchData4Httpsqs($taskid){
		
		$ip = '10.161.145.188';
		$port = '22190';
		
		$queue_name = 'search_task_'.$taskid;
		$httpsqs = new httpsqs( $ip , $port , '' , "utf-8" );
		
		$result = $httpsqs->get($queue_name);
		
		return $result;
	}
		
		
}

?>