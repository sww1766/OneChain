<?php 


require('securimage.php');

session_start();
$img = new securimage();
//* Download:    http://www.codefans.net
$img->show(); // alternate use:  $img->show('/path/to/background.jpg');
$_SESSION['checkcodepoll']= $img->code;

?>
