<?php

require_once ('config/Config.inc.php');
require_once 'include/Class/HttpClient.class.php';
//HttpClient::quickPost
class EshowApi {
	
	
	
	private $appsign;
	private $appapihttp;
	private $inisert_appapihttp;
	
	function __construct() {
		
		global $_CFG;
		
		$this->appsign = $_CFG['appsign'];
		if( empty( $this->appsign  ) )
			$this->appsign = $_REQUEST['req_cmp_asm'];
			 
		$this->appapihttp = $_CFG['appapihttp'];
		$this->inisert_appapihttp = $_CFG['inisert_appapihttp'];
		
	}

	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $tables   数据库表
	 * @param unknown_type $fileds   查询字段
	 * @param unknown_type $where    查询参数
	 * @param unknown_type $pageid   页码
	 * @param unknown_type $recperpage 每页数据
	 */
	function searchorder($tables,$fileds,$where,$pageid,$recperpage,$order){
		
	/*	global $_CFG;
		$appsign = $_CFG['appsign'];
		$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
							
							'appsign' =>$this->appsign, 
						    'fileds'=>$fileds,
							'tablename'=>$tables,
							'where'=>$where,
							'pageid'=>$pageid,
							'recperpage'=>$recperpage,
							'orders'=>$order,'vip'=> $_SERVER['REMOTE_ADDR'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()					
		
							);
				
		
		
		$pageContents = $this->curl_post($this->appapihttp.'/search', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		//$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($pageContents_ar['result'],true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							 'vip'=> $_SERVER['REMOTE_ADDR'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
														
		               	  );
		
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		return $response;
		
	}
	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $tables   数据库表
	 * @param unknown_type $fileds   查询字段
	 * @param unknown_type $where    查询参数
	 * @param unknown_type $pageid   页码
	 * @param unknown_type $recperpage 每页数据
	 */
	function search($tables,$fileds,$where,$pageid,$recperpage){
		
	/*	global $_CFG;
		$appsign = $_CFG['appsign'];
		$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array('appsign' =>$this->appsign, 
						    'fileds'=>$fileds,
							'tablename'=>$tables,
							'where'=>$where,
							'pageid'=>$pageid,
							'recperpage'=>$recperpage,
							'vip'=> $_SERVER['REMOTE_ADDR'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							);
				
		
		$pageContents = $this->curl_post($this->appapihttp.'/search', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		//$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($pageContents_ar['result'],true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							 'vip'=> $_SERVER['REMOTE_ADDR'],
							 'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
														
		               	  );
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		
		return $response;
		
	}
	
	
	
	function getHttpHost(){
	        
	    $str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
	    $project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));
	    global $_CFG;
	    
	    if( $_CFG["ProjectName"] == $project_path_split ){
	        
	        $test_domain = $_CFG['test_domain'];
	        
	        if( empty( $test_domain ) )
	           return '';
	        else 
	           return $test_domain;
	    
	    
	    }else{
	        
	        return $_SERVER['HTTP_HOST'];
	    
	    }
	     
	    
	   
	}
	
	
	function search_mutil( $mutilsql  ){
		
		$searchparm = array(
								'mutilsql'=>$mutilsql,
								'appsign' =>$this->appsign,					
								'vip'=> $_SERVER['REMOTE_ADDR'],
								'extdata'=>$this->getExtdata(),
		                        'host'=> $this->getHttpHost()
							);
		
		
		$pageContents = $this->curl_post($this->appapihttp.'/search_mutil', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));					

							
						
		$pageContents_ar = json_decode($pageContents,true);

		//$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($pageContents_ar['result'],true);
		
		//echo "------------------".$pageContents_ar['language'];
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							 'vip'=> $_SERVER['REMOTE_ADDR'],
							 'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
														
		               	  );
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		return $response;					
							
	}
	
	
	
	function get($tables,$fileds,$where){
		
		
		/*	global $_CFG;
		$appsign = $_CFG['appsign'];
		$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array('appsign' =>$this->appsign, 
						    'fileds'=>$fileds,
							'tablename'=>$tables,
							'where'=>$where,'vip'=> $_SERVER['REMOTE_ADDR'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							
							);
				
		
		
		$pageContents = $this->curl_post($this->appapihttp.'/get', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
														
		               	  );
		
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		return $response;
		
		
	}
	
	
	/**
	 * 根据关键词获取长尾关键词
	 * 
	 * @param unknown $id      编号
	 * @param unknown $types   类型 1-公司首页 $id 为公司编号  2-产品编号 $id 为产品编号  3-产品类型  $id 为产品类型编号  4-新闻 $id为新闻编号
	 * 
	 */
	function get_longtail( $id , $types ){
	
	
	    /*	global $_CFG;
	     $appsign = $_CFG['appsign'];
	     $appapihttp = $_CFG['appapihttp'];
	     */
	
	
	    $searchparm = array('appsign' =>$this->appsign,
	        'objid'=>$id,
	        'types'=>$types,
	        'extdata'=>$this->getExtdata(),
	        'host'=> $this->getHttpHost()
	        	
	    );
	
	
	
	    $pageContents = $this->curl_post($this->appapihttp.'/get_longtail', array(
	        'contents' => base64_encode(json_encode($searchparm)),
	    ));
	
	    //echo $pageContents;
	
	    $pageContents_ar = json_decode($pageContents,true);
	
	    $d = base64_decode($pageContents_ar['result']);
	    $d_arr = json_decode($d,true);
	
	
	    $response = array (
	        'result' => $d_arr,
	        'resultFlag' => $pageContents_ar['resultFlag'],
	        'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
	        'allcounts'=> $pageContents_ar['allcounts']
	    );
	
	
	
	    $this->split_langstr($pageContents_ar['language']);
	    $_SESSION['domainid'] = $pageContents_ar['domainid'];
	    $_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
	    
	    
	    return $response;
	
	
	}
	
	
	function insert($tables,$insertarray,$cmp_id = ''){
		
		
		/*
		global $_CFG;
		$appsign = $_CFG['appsign'];
		$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
							'appsign' =>$this->appsign, 						    
							'tablename'=>$tables,
							'insertarray'=>$insertarray,
							'cmp_id'=>$cmp_id,'vip'=> $_SERVER['REMOTE_ADDR'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							);
				
		
		
		$pageContents = $this->curl_post($this->appapihttp.'/insert', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							 'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
														
		               	  );
		
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		
		return $response;
		
		
	}
	
	
	function insertarp($insertarray){
		
		
		/*
		global $_CFG;
		$appsign = $_CFG['appsign'];
		$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
								'appsign' =>$this->appsign, 						    
								'insertarray'=>$insertarray,
								'cmp_id'=>'cmp_id',
								'vip'=> $_SERVER['REMOTE_ADDR'],
								'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							);
				
		
		
		$pageContents = $this->curl_post($this->inisert_appapihttp.'/replycreate', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							 'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()																				
		               	   );
		
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		
		
		return $response;
		
		
	}
	
	
	function insertarp1($insertarray){
		
		
		/*
		global $_CFG;
		$appsign = $_CFG['appsign'];
		$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
							'appsign' =>$this->appsign, 						    
							'insertarray'=>$insertarray,
							'cmp_id'=>'cmp_id',
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							);
				
		
		
		$pageContents = HttpClient::quickPost($this->appapihttp.'/replycreate1', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts']														
		               	   );
		
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		
		return $response;
		
		
	}
	
	
	function update($insertarray,$where,$tablename){
		
		
		/*
			global $_CFG;
			$appsign = $_CFG['appsign'];
			$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
								'appsign' =>$this->appsign, 						    
								'insertarray'=>$insertarray,
								'cmp_id'=>'cmp_id',
								'where'=>$where,
								'tablename'=>$tablename,
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							);
				
		
		
		$pageContents = HttpClient::quickPost($this->appapihttp.'/update', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts'],
							'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()																				
		               	   );
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		return $response;
		
		
	}
	
	/**
	 * facebook专用
	 *
	 * @param unknown_type $insertarray
	 * @param unknown_type $where
	 * @param unknown_type $tablename
	 * @return unknown
	 */
	function update_facebook($insertarray,$where,$tablename,$shareid){
		
		
		/*
			global $_CFG;
			$appsign = $_CFG['appsign'];
			$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
								'appsign' =>$this->appsign, 						    
								'insertarray'=>$insertarray,
								'cmp_id'=>'cmp_id',
								'where'=>$where,
								'tablename'=>$tablename,
								'shareid'=>$shareid,
								'extdata'=>$this->getExtdata(),'host'=> $this->getHttpHost()						
							);
				
		
		
		$pageContents = HttpClient::quickPost($this->inisert_appapihttp.'/update4facebook', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts']														
		               	   );
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		
		return $response;
		
		
	}
	
	
	/**
	 * facebook专用
	 *
	 * @param unknown_type $insertarray
	 * @param unknown_type $where
	 * @param unknown_type $tablename
	 * @return unknown
	 */
	function update_sendmail($insertarray,$sendmailid,$appsign,$apihttp){
		
		
		/*
			global $_CFG;
			$appsign = $_CFG['appsign'];
			$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
								'appsign' =>$appsign, 						    
								'insertarray'=>$insertarray,
								'cmp_id'=>'cmp_id',							
								
								'sendmailid'=>$sendmailid
							);
				
		
		log_message('info','---------------- httpclient '.$apihttp);
		$pageContents = HttpClient::quickPost($apihttp.'/updatemailcheck', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts']														
		               	   );
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		return $response;
		
		
	}
	
	
	
	/**
	 * facebook专用
	 *
	 * @param unknown_type $insertarray
	 * @param unknown_type $where
	 * @param unknown_type $tablename
	 * @return unknown
	 */
	function update_sendmail1($insertarray,$sendmailid,$appsign,$apihttp){
		
		
		/*
			global $_CFG;
			$appsign = $_CFG['appsign'];
			$appapihttp = $_CFG['appapihttp'];
		*/
		
		
		$searchparm = array(
								'appsign' =>$appsign, 						    
								'insertarray'=>$insertarray,
								'cmp_id'=>'cmp_id',							
								
								'sendmailid'=>$sendmailid
							);
				
		
		log_message('info','---------------- httpclient '.$apihttp);
		$pageContents = HttpClient::quickPost($apihttp.'/updatemailcheck1', array(
						    	'contents' => base64_encode(json_encode($searchparm)),
							));
		
		//echo $pageContents;
						
		$pageContents_ar = json_decode($pageContents,true);

		$d = base64_decode($pageContents_ar['result']);
		$d_arr = json_decode($d,true);
		
		
		$response = array (   
							 'result' => $d_arr, 
							 'resultFlag' => $pageContents_ar['resultFlag'], 
							 'resultExceptionfInfo' =>  $pageContents_ar['resultExceptionfInfo'],
							 'allcounts'=> $pageContents_ar['allcounts']														
		               	   );
		
		
		$this->split_langstr($pageContents_ar['language']);
		$_SESSION['domainid'] = $pageContents_ar['domainid'];
		$_SESSION['page_lang_code'] = $pageContents_ar['page_lang_code'];
		
		return $response;
		
		
	}
	
	
	
	
	function curl_post($url , $postdata){
		
		if(function_exists('curl_init')){
			
			//$url = "http://api.eshowpro.com/";
			$curl = curl_init(); //启动一个CURL会话
		    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址
		   
		    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器
		    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转
		    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer
		    curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求
		    curl_setopt($curl, CURLOPT_POSTFIELDS, $postdata); // Post提交的数据包
		    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环
		    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容
		    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回
		    //curl_setopt($curl, CURLOPT_HEADER, true); //是否显示调试信息
		    curl_setopt($curl, CURLOPT_ENCODING, 'gzip');
		    
		    $tmpInfo = curl_exec($curl); // 执行操作
		    if (curl_errno($curl)) {
		       echo 'Errno '.curl_error($curl);//捕抓异常
		    }
		    
		    curl_close($curl); // 关闭CURL会话
		    $data =  $tmpInfo; // 返回数据
		
		    return  $data;
		
		}else{
			
			return HttpClient::quickPost($url,$postdata);
		}
		
	}
	
	
	/**
	 * 扩展数据，用户特殊的用途
	 *
	 */
	function getExtdata(){	
		
		//$count_type = array(16,5,10,7);
		
		$RTR =& load_class('Router');
		$method = $RTR->fetch_method();
		$fetchclass =  $RTR->fetch_class();
		$fetchclass_method = $fetchclass.$method;
		
		
		if(  empty($_REQUEST['fetchclass_method'] ) ){		
		
			$type = $_GET['type'];
			if( empty($type) )
				$type = $_REQUEST['type'];
			
			$parm = array('host'=>$_SERVER['REMOTE_HOST'],'cmp'=>$this->appsign,'type'=>$type,'mid'=>$_GET['mid'],'vip'=> $_SERVER['REMOTE_ADDR'],'id'=>$_GET['id'],'method'=>$method,'fetchclass'=>$fetchclass);		
			return base64_encode(json_encode($parm));
		
		}else{
			
			$_REQUEST['fetchclass_method'] = $fetchclass_method;
		
		}
		
	
	}
	
	
	/**
	 * 
	 * 分解语言字符串
	 * @param unknown $langstr
	 * 
	 */
	function split_langstr( $langstr ){
	    
	    $lang_arr = explode('##', $langstr);
	    $lang_suffix = $lang_arr[0];
	    $lang_tag = $lang_arr[1];
	    
	    $_SESSION['LANG_SUFFIX'] = $lang_suffix;
	    $_SESSION['LANG_TAG'] = $lang_tag;
	    
	}
	
}

?>