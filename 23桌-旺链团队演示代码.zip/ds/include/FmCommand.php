<?php


class FmCommand {
	
	function __construct() {
		parent::__construct ();
	}
	
	
	
	function getCommand(){
		
		
	}
}


?>