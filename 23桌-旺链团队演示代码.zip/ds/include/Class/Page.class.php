<?php
/**
 * DB record pager class.
 *
 * BugFree is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * BugFree is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with BugFree; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * @link        http://www.bugfree.org.cn
 * @package     BugFree
 * @version     $Id$
 */
class Page
{
    /**
     * MySQL连接操作符
     * @var resource
     */
     var $_MyLink;

    /**
     * 记录总数。
     * @var int
     */
     var $_RecTotal;

    /**
     * 每页显示的记录数。
     * @var int
     */
     var $_RecPerPage;

    /**
     * 分页总数。
     * @var int
     */
     var $_PageTotal;

    /**
     * 当前页面编号。
     * @var int
     */
     var $_PageID;

    /**
     * 链接地址，此地址包含分页信息，比如PageID，PageTotal等。
     * @var string
     */
     var $_URL;

    /**
     * 用于前台跳转用的URL地址，此地址里面不包含分页信息。
     * @var string
     */
     var $_PartURL;

    /**
     * 表名。
     * @var string
     */
     var $_TableName;

    /**
     * 查询条件。
     * @var string
     */
     var $_Where;

    /**
     * 初始化分页类。
     *
     * @param  string   $TableName   要查询的表名，如果是两个表，可以使用逗号隔开。但在where条件里面必须指定连接条件。
     * @param  int      $RecTotal    记录总数。
     * @param  int      $RecPerPage  每页显示的记录数。
     * @param  int      $PageID      当前分页编号。
     * @param  string   $Where       查询条件。
     * @param  string   $URL         链接条件。
     * @param  resource $MyLink      连接操作符。
     */
    function page($TableName, $RecTotal = "", $RecPerPage = 20, $PageID = 0, $Where = "", $URL="", $MyLink = '')
    {
        $TableName = dbGetPrefixTableNames($TableName);

        /* 设定数据库参数。*/
        $this->_MyLink     = $MyLink;
        $this->_TableName  = !empty($TableName) ? $TableName : die("请指定表名");
        $this->_Where      = $Where;

        /* 设定记录总数、每页显示数、分页总数和当前分页ID。*/
        $this->_RecTotal   = ($RecTotal   > 0) ? $RecTotal   : $this->getRecTotal();
        $RecPerPage = $RecPerPage > 0 ? $RecPerPage : $_GET['RecPerPage'];
        $this->_RecPerPage = ($RecPerPage > 0) ? $RecPerPage : ($_COOKIE['RecPerPageNum']>0 ? $_COOKIE['RecPerPageNum'] : 20);
        setcookie('RecPerPageNum', $this->_RecPerPage, time()+2592000);
        $this->setPageTotal();
        $this->setPageID($PageID);

        /* 设定url参数：_URL 和_PartURL。*/
        $this->setURL($URL);

        /* 传递记录总数。*/
        if(!preg_match("/\?/", $this->_URL))
        {
            $this->_URL     .= "?RecTotal=" . $this->_RecTotal . "&RecPerPage=$this->_RecPerPage&";
            $this->_PartURL .= "?RecTotal=" . $this->_RecTotal . "&";
        }
        else
        {
            $this->_URL     .= "&RecTotal=" . $this->_RecTotal . "&RecPerPage=$this->_RecPerPage&";
            $this->_PartURL .= "&RecTotal=" . $this->_RecTotal . "&";
        }
    }

    /* 取得某一条件查询结果的记录总数。*/
    function getRecTotal()
    {
        $SQL      = "SELECT COUNT(*) AS RecTotal FROM $this->_TableName $this->_Where";
        $sqllove = strtolower($SQL);
        
        if( strpos($sqllove,'group by')>0){
        	 
        	$SQL = 'select count(RecTotal) as RecTotal from ( '.$SQL.') aa';
        }
        //echo $SQL;
        $Data = $this->_MyLink->GetRow($SQL);
        $this->_RecTotal = $Data['RecTotal'];
        return $this->_RecTotal;
    }

    /* 设定当前记录编号。*/
    function setPageID($PageID)
    {
        $PageID = $PageID > 0 ? $PageID : $_GET['PageID'];
        if($PageID > 0 and $PageID <= $this->_PageTotal)
        {
            $this->_PageID = $PageID;
        }
        else
        {
            $this->_PageID = 1;
        }
    }

    /* 获得分页总数。*/
    function setPageTotal()
    {
        $this->_PageTotal = ceil($this->_RecTotal / $this->_RecPerPage);
        return $this->_PageTotal;
    }

    /**
     * 设定URL地址。
     *
     * 如果没有指定$URL，则从$_SERVER["QUERY_STRING"]里面将要传递的参数解析出来，去掉PageID和PageTotal项，再拼成完成的URL地址。
     *
     * @bug                 如果传递的参数中含有数组，即var[]=xx&var[2]=xx，会有问题。:)
     * @param  string  $URL 调用此分页类时可以手工指定URL地址。
     * @return int          记录分页总数。
     */
     function setURL($URL = "")
     {
         if(!empty($URL))
         {
             $this->_URL = $URL;
             $this->_PartURL = $this->_URL;
             return;
         }

         /* 取当前程序的地址作为URL的开始部分。*/
         $this->_URL = $_SERVER["PHP_SELF"];

         /* 分析QUERY_STRING，去掉PageID, RecTotal和空值的变量。*/
         parse_str($_SERVER["QUERY_STRING"], $QueryList);
         foreach($QueryList as $QueryName => $QueryValue)
         {
             if(preg_match("/PageID|RecTotal|RecPerPage/", $QueryName) or empty($QueryValue))
             {
                 unset($QueryList[$QueryName]);
             }
         }

         /* 拼凑成完成的URL地址。*/
         if(!empty($QueryList))
         {
             foreach($QueryList as $QueryName => $QueryValue)
             {
                 if(preg_match("/\?/", $this->_URL))
                 {
                     $this->_URL .= "&" . $QueryName . "=" . $QueryValue;
                 }
                 else
                 {
                     $this->_URL .= "?" . $QueryName . "=" . $QueryValue;
                 }
             }
         }

         $this->_PartURL = $this->_URL;
     }

    /**
     * 显示查询结果的分页链接。
     *
     * @param  string $Align  对其方式，默认为居中对齐。left|center|right
     * @return string         返回导航条文字。
     * 
     * 
     *
    $_LANG['Pagination']['FirstPage']   = '首页';
    $_LANG['Pagination']['EndPage']     = '尾页';
    $_LANG['Pagination']['PrePage']     = '上一页';
    $_LANG['Pagination']['NextPage']    = '下一页';
    $_LANG['Pagination']['TotalRecord'] = '记录总数:';
    $_LANG['Pagination']['NumPerPage']  = '项条页';
    $_LANG['Pagination']['PageNum']     = '页码:';
    $_LANG['Pagination']['NoResult']    = '无结果！';
    $_LANG['Pagination']['Result']      = '结果';
     * 
     */
    function show($Align = "left")
    {
        global $_LANG;
        $PageLang = array();
        
        $PageLang['FirstPage']   = '首页';
        $PageLang['EndPage']     = '尾页';
        $PageLang['PrePage']     = '上一页';
        $PageLang['NextPage']    = '下一页';
        $PageLang['TotalRecord'] = '记录总数:';
        $PageLang['NumPerPage']  = '项条页';
        $PageLang['PageNum']     = '页码:';
        $PageLang['NoResult']    = '无结果！';
        $PageLang['Result']      = '结果';
        

        /* 定义链接符号。*/
        $FirstPage = $PageLang['FirstPage'];
        $EndPage   = $PageLang['EndPage'];
        $PrePage   = $PageLang['PrePage'];
        $NextPage  = $PageLang['NextPage'];

        /* 如果页码总数为零，则直接退出。*/
        if($this->_RecTotal == 0)
        {
            $result = $PageLang['NoResult'];
            return " <div class=\"pull-right\">$result</div>";
        }

        /* 跳转页面的js函数。*/
        $PageURL = "'" . $this->_PartURL . "PageID=' + PageID + '&RecPerPage=' + RecPerPage";
        $LinkString = <<<EOT
        <script language='Javascript'>
        
    	function setSelect(obj) {
			
		    var array = document.getElementsByName('_RecPerPage');
			
		    for (var i = 0; i < array.length; i++) {
		    
		        array[i].value = obj.value;
		       
		    }
		}
		
		function setText(obj)
		
		{
		    var array = document.getElementsByName('_PageID');
		    for (var i = 0; i < array.length; i++) {
		        array[i].value = obj.value;
		    }
		}
        
        function submitPage(mode)
        {
            PageTotal     = parseInt(document.getElementById('_PageTotal').value);
            if(mode == 'changePageID')
            {
                PageID        =  document.getElementById('_PageID').value;
                if(PageID > PageTotal)
                {
                    PageID = PageTotal;
                }
                else if(PageID < 1)
                {
                    PageID = 1;
                }
            }
            else if(mode == 'changeRecPerPage')
            {
                PageID = 0;
            }
            RecPerPage    = document.getElementById('_RecPerPage').value;
            //alert(RecPerPage);
            location.href = $PageURL;
        }
        </script>
EOT;

        /* 手工指定每页显示数。*/
        $RecPerPageRange[10] = 10;
        $RecPerPageRange[20] = 20;
        $RecPerPageRange[35] = 35;
        $RecPerPageRange[50] = 50;
        $RecPerPageRange[100] = 100;

        
        $select_att = "class=\"form-control input-xs input-sm input-inline\"";
        
         if( empty( $_REQUEST['PAGE_SLTY']  ) ){
            $RecPerPageList = htmlSelect($RecPerPageRange, "_RecPerPage", "Reverse", $this->_RecPerPage, "onchange='setSelect(this);submitPage(\"changeRecPerPage\");'");
        }else{
            $RecPerPageList = htmlSelect($RecPerPageRange, "_RecPerPage", "Reverse", $this->_RecPerPage, "onchange='setSelect(this);submitPage(\"changeRecPerPage\");' $select_att");
        }
        
        
        /* 显示记录总数。*/
        $LinkString .= "{$PageLang['TotalRecord']}<strong>$this->_RecTotal</strong>&nbsp;";
        $LinkString .= "$RecPerPageList{$PageLang['NumPerPage']}&nbsp;";
        $LinkString .= "{$PageLang['PageNum']}<strong>$this->_PageID</strong>/<strong>$this->_PageTotal</strong>&nbsp;";

         /* 生成第一页的链接。 */
        if($this->_PageID == 1)
        {
            $LinkString .= $this->linktxt($FirstPage);
        }
        else
        {
            $LinkString .= $this->link($FirstPage, $this->_URL . "PageID=1");
        }

        /* 生成前页的链接。*/
        if($this->_PageID == 1)
        {
            $LinkString .= $this->linktxt($PrePage);
        }
        else
        {
            $LinkString .= $this->link($PrePage, $this->_URL . "PageID=" . ($this->_PageID - 1));
        }

        /* 生成后页的链接。*/
        if($this->_PageID == $this->_PageTotal)
        {
             $LinkString .= $this->linktxt($NextPage);
        }
        else
        {
            $LinkString .= $this->link($NextPage, $this->_URL . "PageID=" . ($this->_PageID + 1));
        }

        /* 生成最后一页的链接。*/
        if($this->_PageID == $this->_PageTotal)
        {
            $LinkString .= $this->linktxt($EndPage);
        }
        else
        {
            $LinkString .= $this->link($EndPage, $this->_URL . "PageID=" . $this->_PageTotal);
        }

        /* 生成手工跳转文本框。*/

        if( empty( $_REQUEST['PAGE_SLTY']  ) ){
        
            $LinkString .= "<input type='hidden' id='_PageTotal' value='$this->_PageTotal' />
                            <input type='text'   id='_PageID'    value='$this->_PageID' style='text-align:center;width:30px;height:15px;font-size:11px;' />
                            <input type='button' id='goto'       value='Go' onclick='submitPage(\"changePageID\");' style='font-size:11px;'/>";
            
            $page_str = "<div id='Pagination' style='float:$Align; clear:none'>$LinkString</div>";
            
        }else{
           
             $LinkString .= "<input type='hidden' id='_PageTotal' value='$this->_PageTotal' />
                            <input type='text'   id='_PageID'    value='$this->_PageID' style='text-align:center;width:30px;' class='pagination-panel-input form-control input-sm input-inline input-mini' />
                            <button type=\"button\" class=\"btn green btn-sm\" onclick='submitPage(\"changePageID\");' >跳转</button>";
            
             $page_str = "<div id='Pagination' style='float:$Align; clear:none' class='pull-right pagination-panel'>$LinkString</div>";
             
        }
        
    
        
        return $page_str;
    }

    /**
     * 生成SQL查询语句的Limit部分
     *
     * @return string  Limit语句。
     */
    function Limit()
    {
        return " LIMIT " . $this->LimitNum();
    }

    function LimitNum()
    {
        /* 保证最后一页查出的记录数为RecPerPage。加上不等于1的限制是为了防止出现limit -20,10这样的情况。*/
        if($this->_RecTotal < $this->_RecPerPage)
        {
	        $Limit = "0," . $this->_RecTotal;
        }
        //elseif($this->_PageID == $this->_PageTotal and $this->_PageTotal != 1)
        //{
        //    $Limit =  ($this->_RecTotal - $this->_RecPerPage) . "," . $this->_RecPerPage;
        //}
        else
        {
            $Limit =  $this->_RecPerPage * ($this->_PageID - 1) . "," . $this->_RecPerPage;
        }
        return $Limit;
    }
    
    
    function LimitNum1(){
        
        $Limit_arr = array();
        
        /* 保证最后一页查出的记录数为RecPerPage。加上不等于1的限制是为了防止出现limit -20,10这样的情况。*/
        if($this->_RecTotal < $this->_RecPerPage)
        {
            $Limit = "0," . $this->_RecTotal;
            
            $Limit_arr['from'] = "0";
            $Limit_arr['size'] = $this->_RecTotal;
            
        }
        //elseif($this->_PageID == $this->_PageTotal and $this->_PageTotal != 1)
        //{
        //    $Limit =  ($this->_RecTotal - $this->_RecPerPage) . "," . $this->_RecPerPage;
        //}
        else
        {
            $Limit =  $this->_RecPerPage * ($this->_PageID - 1) . "," . $this->_RecPerPage;
            
            
            $Limit_arr['from'] = $this->_RecPerPage * ($this->_PageID - 1) ;
            $Limit_arr['size'] = $this->_RecPerPage;
            
        }
        return $Limit_arr;
    }
    
    
    /**
     * 生成<a href="">text</a>标记。
     *
     * @param string $Text	    链接文字。
     * @param string $URL	    链接地址。
     */
    function linktxt($Text)
    {
       
        
        if( empty( $_REQUEST['PAGE_SLTY']  ) ){
            return $Text;
        }else{
            return "<a href=\"#\" class=\"btn btn-default disabled btn-sm\" style=\"margin-right: 2px;\">$Text</a>";   
        }
        
       
    }

   /**
    * 生成<a href="">text</a>标记。
    *
    * @param string $Text	    链接文字。
    * @param string $URL	    链接地址。
    */
    function link($Text,$URL)
    {
        
        
        if( empty( $_REQUEST['PAGE_SLTY']  ) ){
             $LinkString = "<a href='".$URL."'>".$Text."</A>";
        }else{
             $LinkString = "<a href='".$URL."'>".$Text."</A>";
             $LinkString = "<a href=\"$URL\" class=\"btn green btn-sm\" style=\"margin-right: 2px;\" >$Text</a>";
        }
        
       
        return $LinkString;
    }

    function getDetailInfo()
    {

        global $_LANG;
        $PageLang = $_LANG['Pagination'];

        /* 定义链接符号。*/
        $NextPage  = $PageLang['NextPage'];

        $DetailInfo = array();

        /* 跳转页面的js函数。*/
        $PageURL = "'" . $this->_PartURL . "PageID=' + PageID + '&RecPerPage=' + RecPerPage";
        $LinkString = <<<EOT
        <script language='Javascript'>
        
		function setSelect(obj) {
		
		    var array = document.getElementsByName('_RecPerPage');
		
		    for (var i = 0; i < array.length; i++) {
		        array[i].value = obj.value;
		    }
		}
		
		function setText(obj)
		
		{
		    var array = document.getElementsByName('_PageID');
		    for (var i = 0; i < array.length; i++) {
		        array[i].value = obj.value;
		    }
		}
        
        function submitPage(mode)
        {
            PageTotal     = parseInt(document.getElementById('_PageTotal').value);
            if(mode == 'changePageID')
            {
                PageID        =  document.getElementById('_PageID').value;
                if(PageID > PageTotal)
                {
                    PageID = PageTotal;
                }
                else if(PageID < 1)
                {
                    PageID = 1;
                }
            }
            else if(mode == 'changeRecPerPage')
            {
                PageID = 0;
            }
            RecPerPage    = document.getElementById('_RecPerPage').value;
            location.href = $PageURL;
        }
        </script>
<input type='hidden' id='_PageTotal' value='$this->_PageTotal' />
EOT;

        /* 手工指定每页显示数。*/
        $RecPerPageRange[10] = 10;
        $RecPerPageRange[20] = 20;
        $RecPerPageRange[35] = 35;
        $RecPerPageRange[50] = 50;
        $RecPerPageRange[100] = 100;

        $RecPerPageList = htmlSelect($RecPerPageRange, "_RecPerPage", "Reverse", $this->_RecPerPage, "onchange='setSelect(this);submitPage(\"changeRecPerPage\");'");

        $DetailInfo['RecPerPageList'] = $LinkString . $RecPerPageList;

        /* 生成前页的链接。*/
        if($this->_PageID == 1)
        {
            $DetailInfo['PrePageSymLink'] = '上一页';
            $DetailInfo['PrePageSymImgLink'] = '<img src="Image/arrow_left_disabled.gif" />';
        }
        else
        {
            $DetailInfo['PrePageSymLink'] = $this->link('上一页', $this->_URL . "PageID=" . ($this->_PageID - 1));
            $DetailInfo['PrePageSymImgLink'] = $this->link('<img src="Image/arrow_left_enabled.gif" />', $this->_URL . "PageID=" . ($this->_PageID - 1));
        }

        /* 生成后页的链接。*/
        if($this->_PageID == $this->_PageTotal || $this->_PageTotal == 0)
        {
             $DetailInfo['NextPageSymLink']  = '下一页';
             $DetailInfo['NextPageSymImgLink']  = '<img src="Image/arrow_right_disabled.gif" />';
             $DetailInfo['NextPageLiteralLink']  = $NextPage;
        }
        else
        {
            $DetailInfo['NextPageSymLink'] = $this->link('下一页', $this->_URL . "PageID=" . ($this->_PageID + 1));
            $DetailInfo['NextPageSymImgLink'] = $this->link('<img src="Image/arrow_right_enabled.gif" />', $this->_URL . "PageID=" . ($this->_PageID + 1));
            $DetailInfo['NextPageLiteralLink'] = $this->link($NextPage, $this->_URL . "PageID=" . ($this->_PageID + 1));
        }

        if($this->_RecTotal < $this->_RecPerPage)
        {
            if($this->_RecTotal == 0)
            {
                $DetailInfo['FromNum'] = 0;
            }
            else
            {
                $DetailInfo['FromNum'] = 1;
            }
            $DetailInfo['ToNum'] = $this->_RecTotal;
        }
        elseif($this->_PageID == $this->_PageTotal and $this->_PageTotal != 1)
        {
            $DetailInfo['FromNum'] = $this->_RecPerPage * ($this->_PageID - 1) + 1;
            $DetailInfo['ToNum'] = $this->_RecTotal;
        }
        else
        {
            $DetailInfo['FromNum'] = $this->_RecPerPage * ($this->_PageID - 1) + 1;
            $DetailInfo['ToNum'] = $DetailInfo['FromNum'] + $this->_RecPerPage - 1;
        }
        $DetailInfo['RecTotal'] = $this->_RecTotal;

        //$DetailInfo['NextLink'] =
        return $DetailInfo;
    }
    
    
    /**
     * 获取查询用的url
     *
     * @return unknown
     */
    function getSearchUrl(){
    	$url = "RecTotal=".$this->_RecTotal."&RecPerPage=".$this->_RecPerPage."&PageID=".$this->_PageID;
    	return $url;
    	
    }
}
?>
