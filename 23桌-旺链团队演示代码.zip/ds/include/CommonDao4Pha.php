<?php

namespace common\db;

class CommonDao4Pha
{


    private $MyDB;


    public function __construct($DbAdapter)
    {
        $this->MyDB = $DbAdapter;
    }

    /*public function __construct($dbkey) {

        $db_config = DB_CONFIG;
        $db_config = json_decode($db_config,true);

        print_r($db_config);

        $dbinfo = $db_config[$dbkey];

        $ip = $dbinfo;
        $host = $dbinfo['host'];
        $username = $dbinfo['username'];
        $password = $dbinfo['password'];
        $dbname = $dbinfo['dbname'];
        $charset = $dbinfo['charset'];

        $dbkey = $ip.'_'.$dbname;

        if(isset( $mydbpools[$dbkey] )){
            $this->MyDB =  $mydbpools[$dbkey];
        }else{

            $connection = new \Phalcon\Db\Adapter\Pdo\Mysql(array(
                "host" => $host,
                "username" => $username,
                "password" => $password,
                "dbname" => $dbname,
                "charset" =>$charset
            ));

            $this->MyDB  =	$connection;

            $mydbpools[$dbkey] = 	$this->MyDB;


        }


    }*/


    /*public function __construct($ip,$dbname,$user,$passwd) {

               //$_CFG['DB']['Host'], $_CFG['DB']['User'], $_CFG['DB']['Password'], $_CFG['DB']['Database']
               global $mydbpools;
               //global $MyDB;
               global $_CFG;

               if( empty($ip) ){

                   $ip = $_CFG['DB']['Host'];
                   $dbname = $_CFG['DB']['Database'];
                   $user = $_CFG['DB']['User'];
                   $passwd = $_CFG['DB']['Password'];
                   $charset = $_CFG['DBCharset'];
               }


               $dbkey = $ip.'_'.$dbname;

               if(isset( $mydbpools[$dbkey] )){
                    $this->MyDB =  $mydbpools[$dbkey];
               }else{

                    $connection = new \Phalcon\Db\Adapter\Pdo\Mysql(array(
                    "host" => 'localhost',
                    "username" => 'root',
                    "password" => '123456',
                    "dbname" => 'eshow',
                    "charset" => 'UTF8'
                     ));

                    $this->MyDB  =	$connection;

                    $mydbpools[$dbkey] = 	$this->MyDB;


               }


        }*/

    function getMyDB()
    {
        return $this->MyDB;

    }

    function closeMyDB()
    {
        return $this->MyDB->Close();

    }


    /* 通用测试程序
      */
    function test($sqlString)
    {
        //echo $sqlString .'<br>';
        //log_message('info','-----------'.$sqlString);
    }


    /**
     * check the data value.
     *
     * @param unknown_type $value
     *
     * @return unknown
     */
    function check_input($value)
    {
        // 去除斜杠
        /*			if (get_magic_quotes_gpc())
               {
                $value = stripslashes($value);
               }*/
        $value = stripslashes($value);
        // 如果不是数字则加引号
        if (!is_numeric($value)) {
            $value = "'" . $value . "'";
        }
        return $value;
    }


    /**
     * Save the value to db.
     *
     * @param String $TableName the table name.
     * @param        String     array $ColumnValues  the table column and value Map.
     *
     * @author robertfeng <fx19800215@163.com>
     *
     */
    function saveRow($TableName, $ColumnValues)
    {


        $sql = "";
        $insertColumn = "";
        $insertValue = "";

        //$TableName = dbGetPrefixTableNames($TableName);

        foreach ($ColumnValues as $key => $value) {

            $insertColumn = $insertColumn . '`'.$key . "`,";

            if ($value == 'now()' || $value == "DATE_FORMAT(now(),'%Y%m%d')") {
                $insertValue = $insertValue . $value . ",";
            } else {

                if ($key == 'phoneqh') {
                    $value = "'$value'";
                } else {
                    $value = $this->check_input($value);
                }

                //$value = $this->check_input($value);
                $insertValue = $insertValue . $value . ",";
            }

        }

        $insertColumn = substr($insertColumn, 0, strlen($insertColumn) - 1);
        $insertValue = substr($insertValue, 0, strlen($insertValue) - 1);

        $sql = "insert into " . $TableName . " (" . $insertColumn . ") values( " . $insertValue . ")";
        //echo $sql;
        //log_message('info',' 测试的sql  ： '.$sql);
        $this->test($sql);
        //$DB->Execute($sql);
        //$this->MyDB->insert($TableName,$ColumnValues);
        $this->MyDB->execute($sql);
        $_REQUEST['SQL_INFO'] = array('table' => "$TableName", 'ddl' => 'insert');

        return $this->MyDB->lastInsertId();
    }


    /**
     * Update table
     *
     * @param String $TableName the table name.
     * @param        String     array  $columnAndValue  the table column and value Map.
     * @param String $pkName    the primary key name.
     * @param String $pkValue   the primary key value.
     *
     * @author robertfeng <fx19800215@163.com>
     *
     *
     */
    function updateRowByPk($TableName, $columnAndValue, $pkName, $pkValue)
    {

        $condtion = array($pkName => $pkValue);
        $this->updateRow($TableName, $columnAndValue, $condtion);

    }


    /**
     * Update table
     *
     * @param String $TableName the table name.
     * @param        String     array  $columnAndValue  the table column and value Map.
     * @param        String     array  $condition   the primary key name.
     * @param        db         ojbect     $DB          the sqllite private database visit object
     *
     * @author robertfeng <fx19800215@163.com>
     *
     *
     */
    function updateRow($TableName, $columnAndValue, $condition = "")
    {


        $sql = 'update ' . $TableName . ' set ';

        $update = '';
        foreach ($columnAndValue as $key => $value) {


            if ($key == 'phoneqh') {
                $value = "'$value'";
            } else {


                if ($value == 'now()' || $value == "DATE_FORMAT(now(),'%Y%m%d')") {

                } else {
                    $value = $this->check_input($value);

                }


            }


            $update = $update .'`'. $key . '`=' . $value . ',';
        }

        $update = substr($update, 0, strlen($update) - 1);
        $sql = $sql . $update;

        if (empty($condition)) {
            $sql = $sql;
        } else {
            $conditionString = " (1=1) ";
            foreach ($condition as $key => $value) {
                $value = $this->check_input($value);
                $conditionString = $conditionString . " and  " . $key . '=' . '' . $value . '' . '';
            }
            //echo $conditionString;
            //$conditionString = substr($conditionString,0,strlen($conditionString)-1);
            $sql = $sql . " where " . $conditionString;

        }

        $this->test($sql);
        //$DB->Execute($sql);
        $this->MyDB->execute($sql);
    }

    /**
     *   直接执行原生的DDL（包括delete update 等）
     *
     * @param $executesql
     */
    function executeBySql($executesql)
    {

        $this->MyDB->execute($executesql);
    }


    /**
     * get row by primary key
     *
     * @param String $TableName the table name.
     * @param String $column    the filed of search result.
     * @param String $pkColumn  the primary key column name.
     * @param String $value     the primary key value.
     *
     *
     */
    function getRowByPk($TableName, $column = "", $pkColumn, $value)
    {

        $value = $this->check_input($value);

        if (empty($column))
            $sql = "select * from " . $TableName . " where " . $pkColumn . "=" . $value . "";
        else
            $sql = "select " . $column . " from  " . $TableName . " where " . $pkColumn . "=" . $value . "";
        $this->test($sql);

        //$Data = $DB->GetRow($sql);
        //$this->MyDB->query('set names UTF8');
        $result = $this->MyDB->query($sql);

        //$result->setFetchMode($DB::FETCH_ASSOC);
        //echo $DB->getSQLStatement(); // sql

        $DataList = $result->fetchAll();

        if (count($DataList) > 0)
            return $DataList[0];
        else
            return array();

    }

    /**
     * 查询一条记录
     *
     * @param unknown_type $sql
     * @param unknown_type $DB
     *
     * @return unknown
     */
    function getRowByPkOne($sql)
    {


        $this->test($sql);
        $result = $this->MyDB->query($sql);

        //$result->setFetchMode($DB::FETCH_ASSOC);
        //echo $DB->getSQLStatement(); // sql

        $DataList = $result->fetchAll();

        if (count($DataList) > 0)
            return $DataList[0];
        else
            return array();

    }

    /**
     * search table
     *
     * @param String $TableName the table name
     * @param String $columns   the field of seach result
     * @param String $ondtion   the search condition,it is sotre by array. exp $condition = array("id"=>"1");
     * @param String $orderBy   the order desc.
     * @param String $limit     the pagedtion.
     *
     */
    function getRowsByCondition($TableName, $columns = "", $ondtion = "", $orderBy = "", $limit = "")
    {


        //$TableName = dbGetPrefixTableNames($TableName);
        $conditionString = '';


        if ($columns == "")
            $sql = "select * from " . $TableName;
        else
            $sql = "select " . $columns . " from " . $TableName;


        if ($ondtion == "") {
            $sql = $sql;
        } else {


            foreach ($ondtion as $key => $value) {
                $value = $this->check_input($value);
                $conditionString = $conditionString . ' and ' . $key . '=' . '' . $value . '';
            }

            //$conditionString = substr($conditionString,0,strlen($conditionString)-1);
            $sql = $sql . " where (1=1) " . $conditionString;
        }

        if (empty($orderBy)) {

            $sql = $sql;

        } else {

            $sql = $sql . " order by " . $orderBy;

        }


        if ($limit != '') {

            $sql = $sql . ' LIMIT  ' . $limit;

        }

        //echo $sql.'<br>';
        $this->test($sql);

        $result = $this->MyDB->query($sql);

        //$result->setFetchMode($DB::FETCH_ASSOC);
        //echo $DB->getSQLStatement(); // sql

        $DataList = $result->fetchAll();
        //$DataList = $DB->GetAll($sql);

        return $DataList;

    }


    /**
     * search table by sql
     *
     * @param datatype $sqlchareter the table name
     * @param datatype $ondtion     the search condition,it is sotre by array. exp $condition = array("id"=>"1");
     * @param datatype $limit       the pagedtion.
     *
     */
    function getRowsBySQl($sqlchareter, $condition, $limit = "")
    {


        if ($limit != '') {
            $sql = $sqlchareter . ' LIMIT  ' . $limit;
        } else {
            $sql = $sqlchareter;
        }


        if ($condition == '') {
            $sql = $sql;
        } else {
            foreach ($condition as $key => $value) {
                $value = $this->check_input($value);
                $sql = str_replace(':' . $key, $value, $sql);
            }
        }

        $this->test($sql);
        $result = $this->MyDB->query($sql);

        //$result->setFetchMode($DB::FETCH_ASSOC);
        //echo $DB->getSQLStatement(); // sql
        $DataList = $result->fetchAll();
        //print_r($data);


        return $DataList;

    }



    /**
     * 根据SQL获取MAP数组
     *
     * @param unknown_type $sql
     * @param unknown_type $key
     *
     * @return unknown
     */
    function getSqlMap($sql, $key)
    {

        $sql_arr = $this->getRowsBySQl($sql, '', '', '');

        $sql_arr_map = array();

        foreach ($sql_arr as $item) {

            $sql_arr_map[$item[$key]] = $item;
        }

        return $sql_arr_map;
    }


    /**
     *
     */
    function isUnique($TableName, $column, $value, $DB = "")
    {

    }
    
    
    
function clearheike( $sql  ){
         
        $sql_un = strtolower($sql);
         
        if( (bool)strpos('dd'.$sql_un,'drop database') 
            || (bool)strpos('dd'.$sql_un,'show databases') 
            || (bool)strpos('dd'.$sql_un,'flush privileges')
            || (bool)strpos('dd'.$sql_un,'drop table')
            || (bool)strpos('dd'.$sql_un,'show tables') ){
            
            return false;
            
        }else{
            
            return true;
            
        }
     
    }


}

?>