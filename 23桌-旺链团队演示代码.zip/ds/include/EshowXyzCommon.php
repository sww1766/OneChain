<?php

require_once 'CommonService.php';



/**
 * 
 * Enter description here...
 *
 * @param unknown_type $url           连接   url如果没有参数就带上标记
 * @param unknown_type $pic           图片
 * @param unknown_type $description   描述
 * @param unknown_type $name          名称
 * @return unknown
 * 
 */
function xyz_share($url ,$pic,$description,$name){            
                             
		$u_facebook = $url.'flag=5';
		$u_twitter = $url.'flag=6';
		$u_google = $url.'flag=8';
		$u_linkide = $url.'flag=10';
		
		$u_facebook_en = urlencode($u_facebook);
		$u_twitter_en = urlencode($u_twitter);
		$u_google_en = urlencode($u_google);
		$u_linkide_en = urlencode($u_linkide);
		
		$pic_url = urlencode($pic);
       	$caption = urlencode($description);
		$name= urlencode($name);
		$description = urlencode($description);
		 	//echo '-------------'.$description;

		$fb_runln = "http://localhost/eshow_yx/index.php/unify/blog_detail/497-19th-Guangzhou-International-Lighting-Exhibition-";
		$fb_runln = urlencode($fb_runln);
		
		$fb_url = "https://www.facebook.com/dialog/feed?app_id=697049713638462&display=popup&caption=$caption&link=$u_facebook_en&redirect_uri=http%3A%2F%2Fshare.eshowpro.com%2Fshare%2Ffblogin&client_secret=56846a2eee3f0b7fb693f7dc2a53ec12&picture=$pic_url&name=$name&description=$description";  
		$tw_url = "https://twitter.com/intent/tweet?text=$name&url=$u_twitter_en";								
		
		$google_plug_url = "https://plus.google.com/share?url=$u_google_en&hl=en-US";
		
		/*$s = "www.sina.com";
		$s_en = urlencode($s);*/
		
		$link_url = "http://www.linkedin.com/shareArticle?mini=true&url=$u_linkide_en&title=$name&summary=$description&source=";
		
		$d = array('fb_url'=>$fb_url,'tw_url'=>$tw_url,'google_push_url'=>$google_plug_url,'link_url'=>$link_url);
		$_REQUEST['social_info'] = $d;
		
		return $d;
                                
	
	
}




function cmp_clm(){
	
		$cmp_name = getLangColumnFalg('cmp_name');
		$web_summary_2 = getLangColumnFalg('web_summary_2');
		$web_summary_1 = getLangColumnFalg('web_summary_1');
		$cmp_summary = getLangColumnFalg('cmp_summary');
		$address = getLangColumnFalg('address');
		$phones = getLangColumnFalg('phones');
		$phones1 = getLangColumnFalg('phones1');
		$mobiles = getLangColumnFalg('mobiles');
		$email = getLangColumnFalg('email');
		$maxcode = getLangColumnFalg('maxcode');
		$seo_title = getLangColumnFalg('seo_title');
		$seo_describle = getLangColumnFalg('seo_describle');
		$keyss = getLangColumnFalg("keyss");
		$website = getLangColumnFalg("website");
		
		
		$column = "$website,web_index_cn,$seo_title,$seo_describle,keyids,id,$keyss,index_pic,$maxcode,id,web_index, $web_summary_2 ,$web_summary_1 ,iphoneewm,rempic,$address,$phones,$phones1,$email,$mobiles,qq,skype,pics,rempic,$cmp_summary,$cmp_name,facebooklogin,twitter,msn,googleplus,linkedin,youtube";
	
		return $column;
	    
	
}


function cmp_clm_list(){
	
	
		$cmp_name = getLangColumnFalg('cmp_name');
		$web_summary_2 = getLangColumnFalg('web_summary_2');
		$web_summary_1 = getLangColumnFalg('web_summary_1');
		$cmp_summary = getLangColumnFalg('cmp_summary');
		$address = getLangColumnFalg('address');
		$phones = getLangColumnFalg('phones');
		$email = getLangColumnFalg('email');
	
		$column = "id,web_index, $web_summary_2 ,$web_summary_1 ,iphoneewm,rempic,$address,$phones,$email,skype,pics,rempic,$cmp_summary,$cmp_name";
	
		return $column;
	
	
}


function cmp_product_clm(){
	
		$title = getLangColumnFalg('title');
		$subjects = getLangColumnFalg('subjects');
		$contants = getLangColumnFalg('contants');
		$urlparm = getLangColumnFalg('urlparm');
		
		
		return "id,$urlparm,$title,$subjects,$contants,pic_group,picrecommend,pro_type_id,picrecommend,url_alibaba,url_madinchina,url_gs,url_ae,url_ebay,url_az,url_taobao,url3";
	
	
}



function cmp_product_clm_list(){
	
		$title = getLangColumnFalg('title');
		$subjects = getLangColumnFalg('subjects');
		//$contants = getLangColumnFalg('contants');
		$urlparm = getLangColumnFalg('urlparm');
		
		return "id,$urlparm,$title,$subjects,pic_group,picrecommend,pro_type_id,picrecommend";
	
}


function cmp_product_type_clm(){
	
		$name = getLangColumnFalg('name');
		//$subjects = getLangColumnFalg('subjects');
		//$contants = getLangColumnFalg('contants');
		//$urlparm = getLangColumnFalg('urlparm');
		
		return "id,$name";
	
}



function cmp_product_type_clm_list(){
	
		$name = getLangColumnFalg('name');
		//$subjects = getLangColumnFalg('subjects');
		//$contants = getLangColumnFalg('contants');
		//$urlparm = getLangColumnFalg('urlparm');
		
		return "id,$name,parentid";
	
}




function cmp_expertise_clm(){
	
	
	$name = getLangColumnFalg('name');
	$content = getLangColumnFalg('content');
	
	return  "id, $name,$content  ";

}


function cmp_expertise_clm_list(){
	
	
	$name = getLangColumnFalg('name');
	$content = getLangColumnFalg('content');
	
	return  "id, $name,$content  ";

}


function cmp_leader_clm(){
	
	$name = getLangColumnFalg('name');
	$phone = getLangColumnFalg('phone');
	//$name = getLangColumnFalg('mobile');
	return "$name,facebook,twitter,skype,pic,email,$phone";
}


function cmp_leader_clm_list(){
	
	$name = getLangColumnFalg('name');
	return "$name,facebook,twitter,skype,pic";
}



function cmp_news_clm(){
	
		$title = getLangColumnFalg('title');
		$subjects = getLangColumnFalg('subjects');
		$urlparm = getLangColumnFalg('urlparm');
		$contents = getLangColumnFalg('contents');
		
		return " id , $urlparm, $title,$subjects,pic,createdt,$contents";
	
	
	
}


function cmp_news_clm_list(){
	
		$title = getLangColumnFalg('title');
		$subjects = getLangColumnFalg('subjects');
		$urlparm = getLangColumnFalg('urlparm');
		
		
		
		return " id , $urlparm, $title,$subjects,pic,createdt";
	
	
	
}


function cmp_crm_faq_cml (){
	
	$question = getLangColumnFalg('question');
	$answers = getLangColumnFalg('answer');
	
	return "$question,$answers";
	
}

function cmp_faq_cml (){
	
	$question = getLangColumnFalg('question');
	$answers = getLangColumnFalg('answers');
	
	return "$question,$answers";
	
}


function cmp_faq_cml_list (){
	
	$question = getLangColumnFalg('question');
	$answers = getLangColumnFalg('answers');
	
	return "$question,$answers";
}


?>