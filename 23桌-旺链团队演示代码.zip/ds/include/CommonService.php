<?php



function getFacebookAccount($facebook){
		
		
			$tempu=parse_url($facebook);
			$message=$tempu['host'];
		
			if( !empty($message) ){
				
				$return = substr($facebook,strpos($facebook,$message)+strlen($message)+1);
			}else{
				$return = "";
			}
			
			return $return;
		
	}

/**
 * 检查运行环境是否为本地
 *
 */
function check_run_env(){

global $_GET;
	
$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));


if( $_CFG["ProjectName"] == $project_path_split ){
	return true;
}else{
	return false;
}
	
}


/**
 * 
 * 在选择框中增加一个包含所有的选项
 *
 * @param unknown_type $arr
 * @param unknown_type $tmpearr
 * @return unknown
 * 
 */
function common_select_html_temps($arr , $tmpearrs){
	
	$d =array();
	
	foreach ( $tmpearrs as $item )
		array_push($d,$item);
	
	foreach ( $arr as $item )
		array_push($d,$item);
		
	return $d;
	
}


/**
 * 
 * 在选择框中增加一个包含所有的选项
 *
 * @param unknown_type $arr
 * @param unknown_type $tmpearr
 * @return unknown
 * 
 */
function common_select_html_temp($arr , $tmpearr){
	
	$d = array($tmpearr);
	
	foreach ( $arr as $item )
		array_push($d,$item);
		
	return $d;
	
}



/**
 * Enter description here...
 *
 * @param unknown_type $array    顺序字符串
 * @param unknown_type $split    字符串分割符号
 * @param unknown_type $arr      数组
 * @param unknown_type $arr_key  数组对象的键值
 */
function change_array_order($str,$split,$arr,$arr_key){
	
	$map = changeArray2Map($arr,$arr_key);
	
	$arr = explode($split,$str);
	
	$array = array();
	
	foreach (  $arr as $item  ){
		
		array_push( $array,$map[$item] );
	}
	
	return 	$array;
	
}




function orderface($array){
	
	$array_order = array();
	
	for( $ind = 0 ; $ind<count($array);$ind++ ){
		
		array_push($array_order,$array[count($array)-1-$ind]);
		
	}
	
	return $array_order;
	
	
}



function changeArray2Map($array,$key){
	
	$map = array();
	
	foreach ( $array as $item ){
		
		$map[$item[$key]] = $item;
		
	}
	
	return $map;
	
}


/**
 * 检查运行环境
 *
 */
function  checkruneve(){
	
	global $_CFG;
	define('PROJECT_NAME',$_CFG["ProjectName"]);
	$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
	$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));
	
	if( $_CFG["ProjectName"] == $project_path_split ){ //本地运行
	
		/*	define('HTTP_DOCMENT_ROOT',$ServerProtocol."://".$_SERVER['HTTP_HOST'].'/'.$_CFG["ProjectName"]);
		define('APP_WEB_INDEX_ROOT',HTTP_DOCMENT_ROOT.'/index.php');*/
		return false;
	}else{
		
		/*define('HTTP_DOCMENT_ROOT',$ServerProtocol."://".$_SERVER['HTTP_HOST'].'');
		define('APP_WEB_INDEX_ROOT',HTTP_DOCMENT_ROOT);*/
		return true;
		
	}
	
}


//获取文件目录列表,该方法返回数组
function getDirSubDirs($dir) {
    $dirArray[]=NULL;
    if (false != ($handle = opendir ( $dir ))) {
        $i=0;
        while ( false !== ($file = readdir ( $handle )) ) {
            //去掉"“.”、“..”以及带“.xxx”后缀的文件
            if ($file != "." && $file != ".."&&!strpos($file,".")) {
                $dirArray[$i]=$file;
                $i++;
            }
        }
        //关闭句柄
        closedir ( $handle );
    }
    return $dirArray;
}
 
//获取文件列表
function getDirSubFiles($dir) {
    $fileArray[]=NULL;
    if (false != ($handle = opendir ( $dir ))) {
        $i=0;
        while ( false !== ($file = readdir ( $handle )) ) {
            //去掉"“.”、“..”以及带“.xxx”后缀的文件
            if ($file != "." && $file != ".."&&strpos($file,".")) {
                $fileArray[$i]="".$file;
                if($i==100){
                    break;
                }
                $i++;
            }
        }
        //关闭句柄
        closedir ( $handle );
    }
    return $fileArray;
}


/**
 * 压缩html : 清除换行符,清除制表符,去掉注释标记  
 * @param   $string  
 * @return  压缩后的$string 
 * */
function compress_html($string) {
	
	$string = str_replace ("\r\n", '', $string ); //清除换行符  
	$string = str_replace ("\n", '', $string ); //清除换行符  
	$string = str_replace ("\t", '', $string ); //清除制表符  
	 
	$pattern = array ("/> *([^ ]*) *</", "/[\\s]+/", "/<!--[^!]*-->/", "/\" /", "/ \"/", "'/\\*[^*]*\\*/'" );//去掉注释标记  
	$replace = array (">\\1<", " ", "", "\"", "\"", "" );
	return preg_replace ( $pattern, $replace, $string );
	
	/*$i = array('/>[^S ]+/s','/[^S ]+</s','/(s)+/s');
       $ii = array('>','<','1');
       return preg_replace($i, $ii, $string);*/

	//$string = str_replace(array('<!--<!---->','<!---->',"\r\n\r\n","\r\n","\n","   ","\t"),'',$string);

	
	
	/* $string = preg_replace("~>\\s+\r~", ">", preg_replace("~>\\s+\n~", ">", $string));
	$string = preg_replace("~>\\s+<~", "><", $string); */
	
	//return $string;
	//return $string;
}

/**
 * 讲某个表的所有值，转化成
 *
 * @param unknown_type $tables
 * @param unknown_type $key_col
 * @param unknown_type $valuecol
 * @param unknown_type $fileds
 */
function getTablesColMap($tables ,$key_col ,$valuecol,$fileds='*',$where=' 1=1 '){
	
	$sql = " select $fileds from $tables where $where ";
	
	
}



function getLangColumnFalg($col){
	
	$langs = array();
	
	array_push($langs,$col);
	array_push($langs,$col.'_en');
	array_push($langs,$col.'_x');
	array_push($langs,$col.'_x1');
	array_push($langs,$col.'_x2');
	array_push($langs,$col.'_x3');
	

/*	array_push($langs,$col);
	array_push($langs,$col);
	array_push($langs,$col);
	array_push($langs,$col);
	array_push($langs,$col);
	array_push($langs,$col);
	array_push($langs,$col);*/

	return implode(',',$langs);
	
	
}

/**
 * 把西方语言的标题修改成相关的字符串，这些字符串出现在url中增加收索引擎收入的机会
 *
 * @param unknown_type $url_titles
 * @return unknown
 */
function url_keyworkd($url_title){
	
		 //$url_title = "Nom d'utilis/ateur";	
		 $url_title=str_replace("+","-",$url_title); 
		 $url_title=str_replace(" ","-",$url_title);
		 $url_title=str_replace("/","-",$url_title);
		 $url_title=str_replace("?","-",$url_title);
		 $url_title=str_replace("%","-",$url_title);
		 $url_title=str_replace("#","-",$url_title);
		 $url_title=str_replace("&","-",$url_title);
		 $url_title=str_replace("~","-",$url_title);
		 $url_title=str_replace("!","-",$url_title);
		 $url_title=str_replace("^","-",$url_title);
		 $url_title=str_replace("*","-",$url_title);
		 $url_title=str_replace("(","-",$url_title);
		 $url_title=str_replace(")","-",$url_title);
		 $url_title=str_replace("'","-",$url_title);
		 $url_title=str_replace("\"","-",$url_title);
		 $url_title=str_replace("<","-",$url_title);
		 $url_title=str_replace(">","-",$url_title);
		 $url_title=str_replace("/","-",$url_title);
		 $url_title=str_replace(".","-",$url_title);
		 $url_title=str_replace("[,","-",$url_title);
		 $url_title=str_replace("]","-",$url_title);
		 $url_title=str_replace("{","-",$url_title);
		 $url_title=str_replace("}","-",$url_title);
		 $url_title=str_replace("\\","-",$url_title);
		 $url_title=str_replace("|","-",$url_title);
		 $url_title=str_replace(",","-",$url_title);
		 
		 return  $url_title;
		 
	
	
}


/**
 * 检验邮箱是否正确
 *
 * @param unknown_type $mail
 * @return unknown
 */
function checkMail($mail){
	if (@ereg("^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\\.[a-zA-Z0-9_-])+",$mail)){
		return   true;
	}else{
	    return false;
	}
	
}



/**
 * Enhanced mail function.
 *
 * @author                            Chunsheng Wang <wwccss@263.net>
 * @param   string      $ToList       To address list.
 * @param   string      $CCList       CC address list.
 * @param   string      $Subject      Subject.
 * @param   string      $Message      Message.
 */
function sysMailext($ToList,$CCList,$Subject,$Message,$host,$smtpauth,$username,$password,$FromAddress,$FromName,$port,$replyto,$replytoname)
{
    global $_CFG, $_LANG;
    if(!$_CFG['Mail']['On'])
    {
        return;
    }
	
	//echo $ToList.'<=>'.$CCList.'<=>'.$Subject.'<=>'.$Message.'<br>';
	require_once("include/Class/PHPMailer/class.phpmailer.php");


    // Create an object of PHPMailer class and set the send method
    $Mail = new PHPMailer();
    
    $Mail->SetLanguage("en",  REAL_ROOT_PATH."/include/Class/PHPMailer/language/"); 
    
    if( !empty($replyto) && !empty($replytoname) )
   		$Mail->AddReplyTo($replyto,$replytoname);
    
   	$Mail->Port = $port;
   	
    switch(strtoupper($_CFG["Mail"]["SendMethod"]))
    {
        case "SMTP":
            $Mail->isSMTP();
            $Mail->Host     = $host;
            $Mail->SMTPAuth = $smtpauth ;
            $Mail->Username = $username;
            $Mail->Password = $password;
            break;
        case "MAIL":
            $Mail->isMail();
            break;
        case "SENDMAIL":
            $Mail->isSendmail();
            break;
        case "QMAIL":
            $Mail->isQmail();
            break;
    }
    //echo $Mail->Host.'<=>'.$Mail->SMTPAuth.'<=>'.$Mail->Username.'<=>'.$Mail->Password.'<br>';
    // Define From Address.
    //$Mail->From     = $_CFG["Mail"]["FromAddress"];
    $Mail->From = $FromAddress;
    //$Mail->FromName = $_CFG["Mail"]["FromName"];
	$Mail->FromName = $FromName;
    
	
	
    if(!is_array($ToList) && $ToList != '')
    {
        $ToList = explode(',', $ToList);
    }
    if(empty($ToList) && is_array($CCList) && !empty($CCList))
    {
        $ToList[] = array_pop($CCList);
    }
    if(empty($ToList))
    {
        return false;
    }
    foreach($ToList as $To)
    {
        $Mail->addAddress($To);
    }
    // Add To Address.
    if(is_array($CCList))
    {
        $CCList = array_diff($CCList, $ToList);
        foreach($CCList as $CC)
        {
            $Mail->addCC($CC);
        }
    }

    // Add Subject.
    $Subject  = ''.$Subject;
    $Mail->Subject  =  stripslashes($Subject);

    // Set Body.
    $Mail->IsHTML(true);
    $Mail->CharSet = $_LANG["Charset"];
    $Mail->Body    = stripslashes($Message);
	
    $sendresult = "success";
    
    if(!$Mail->Send())
    {
      	$sendresult =  $Mail->ErrorInfo;
       //jsAlert($Mail->ErrorInfo);
    }
    
    return $sendresult;
}



/**
 * Enhanced mail function.
 *
 * @author                            Chunsheng Wang <wwccss@263.net>
 * @param   string      $ToList       To address list.
 * @param   string      $CCList       CC address list.
 * @param   string      $Subject      Subject.
 * @param   string      $Message      Message.
 */
function sysMailext1($ToList,$CCList,$Subject,$Message,$host,$smtpauth,$username,$password,$FromAddress,$FromName,$port,$replyto,$replytoname,$smtpsecure)
{
    global $_CFG, $_LANG;
    if(!$_CFG['Mail']['On'])
    {
        return;
    }
	
	//echo $ToList.'<=>'.$CCList.'<=>'.$Subject.'<=>'.$Message.'<br>';
	require_once("include/Class/PHPMailer/class.phpmailer.php");


    // Create an object of PHPMailer class and set the send method
    $Mail = new PHPMailer();
    
    $Mail->SetLanguage("en",  REAL_ROOT_PATH."/include/Class/PHPMailer/language/"); 
    
    if( !empty($replyto) && !empty($replytoname) )
   		$Mail->AddReplyTo($replyto,$replytoname);
    
   	$Mail->Port = $port;
   	
   	if( !empty($smtpsecure) )
   		 $Mail->SMTPSecure = $smtpsecure;
   	
    switch(strtoupper($_CFG["Mail"]["SendMethod"]))
    {
        case "SMTP":
            $Mail->isSMTP();
            $Mail->Host     = $host;
            $Mail->SMTPAuth = $smtpauth ;
            $Mail->Username = $username;
            $Mail->Password = $password;
           
            break;
        case "MAIL":
            $Mail->isMail();
            break;
        case "SENDMAIL":
            $Mail->isSendmail();
            break;
        case "QMAIL":
            $Mail->isQmail();
            break;
    }
    //echo $Mail->Host.'<=>'.$Mail->SMTPAuth.'<=>'.$Mail->Username.'<=>'.$Mail->Password.'<br>';
    // Define From Address.
    //$Mail->From     = $_CFG["Mail"]["FromAddress"];
    $Mail->From = $FromAddress;
    //$Mail->FromName = $_CFG["Mail"]["FromName"];
	$Mail->FromName = $FromName;
    
	
	
    if(!is_array($ToList) && $ToList != '')
    {
        $ToList = explode(',', $ToList);
    }
    if(empty($ToList) && is_array($CCList) && !empty($CCList))
    {
        $ToList[] = array_pop($CCList);
    }
    if(empty($ToList))
    {
        return false;
    }
    foreach($ToList as $To)
    {
        $Mail->addAddress($To);
    }
    // Add To Address.
    if(is_array($CCList))
    {
        $CCList = array_diff($CCList, $ToList);
        foreach($CCList as $CC)
        {
            $Mail->addCC($CC);
        }
    }

    // Add Subject.
    $Subject  = ''.$Subject;
    $Mail->Subject  =  stripslashes($Subject);

    // Set Body.
    $Mail->IsHTML(true);
    $Mail->CharSet = $_LANG["Charset"];
    $Mail->Body    = stripslashes($Message);
    
    $sendresult = "success";
    
    if(!$Mail->Send())
    {
      	$sendresult =  $Mail->ErrorInfo;
       //jsAlert($Mail->ErrorInfo);
    }
    
    return $sendresult;
}




/**
 * Enhanced mail function.
 *
 * @author                            Chunsheng Wang <wwccss@263.net>
 * @param   string      $ToList       To address list.
 * @param   string      $CCList       CC address list.
 * @param   string      $Subject      Subject.
 * @param   string      $Message      Message.
 */
function sysMailext5($ToList,$CCList,$Subject,$Message,$host,$smtpauth,$username,$password,$FromAddress,$FromName,$port,$replyto,$replytoname,$smtpsecure)
{
    global $_CFG, $_LANG;
    if(!$_CFG['Mail']['On'])
    {
        return;
    }
	
	//echo $ToList.'<=>'.$CCList.'<=>'.$Subject.'<=>'.$Message.'<br>';
	require_once("include/Class/PHPMailer5/PHPMailerAutoload.php");


    // Create an object of PHPMailer class and set the send method
    $Mail = new PHPMailer();
    
    //$Mail->SMTPDebug = 1;
    
    $Mail->SetLanguage("zh_cn",  REAL_ROOT_PATH."/include/Class/PHPMailer/language/"); 
    
    if( !empty($replyto) && !empty($replytoname) )
   		$Mail->AddReplyTo($replyto,$replytoname);
    
   	$Mail->Port = $port;
   	
   	if( !empty($smtpsecure) )
   		 $Mail->SMTPSecure = $smtpsecure;
   	
    switch(strtoupper($_CFG["Mail"]["SendMethod"]))
    {
        case "SMTP":
            $Mail->isSMTP();
            $Mail->Host     = $host;
            $Mail->SMTPAuth = $smtpauth ;
            $Mail->Username = $username;
            $Mail->Password = $password;
           
            break;
        case "MAIL":
            $Mail->isMail();
            break;
        case "SENDMAIL":
            $Mail->isSendmail();
            break;
        case "QMAIL":
            $Mail->isQmail();
            break;
    }
    //echo $Mail->Host.'<=>'.$Mail->SMTPAuth.'<=>'.$Mail->Username.'<=>'.$Mail->Password.'<br>';
    // Define From Address.
    //$Mail->From     = $_CFG["Mail"]["FromAddress"];
    $Mail->From = $FromAddress;
    //$Mail->FromName = $_CFG["Mail"]["FromName"];
	$Mail->FromName = $FromName;
    
	
	
    if(!is_array($ToList) && $ToList != '')
    {
        $ToList = explode(',', $ToList);
    }
    if(empty($ToList) && is_array($CCList) && !empty($CCList))
    {
        $ToList[] = array_pop($CCList);
    }
    if(empty($ToList))
    {
        return false;
    }
    foreach($ToList as $To)
    {
        $Mail->addAddress($To);
    }
    // Add To Address.
    if(is_array($CCList))
    {
        $CCList = array_diff($CCList, $ToList);
        foreach($CCList as $CC)
        {
            $Mail->addCC($CC);
        }
    }

    // Add Subject.
    $Subject  = ''.$Subject;
    $Mail->Subject  =  stripslashes($Subject);

    // Set Body.
    $Mail->IsHTML(true);
    $Mail->CharSet = $_LANG["Charset"];
    $Mail->Body    = stripslashes($Message);
    
    $sendresult = "success";
    
    if(!$Mail->Send())
    {
      	$sendresult =  $Mail->ErrorInfo;
       //jsAlert($Mail->ErrorInfo);
    }
    
    return $sendresult;
}


/**
 * Enhanced mail function.
 *
 * @author                            Chunsheng Wang <wwccss@263.net>
 * @param   string      $ToList       To address list.
 * @param   string      $CCList       CC address list.
 * @param   string      $Subject      Subject.
 * @param   string      $Message      Message.
 */
function sysMail($ToList,$CCList,$Subject,$Message)
{
    global $_CFG, $_LANG;
    if(!$_CFG['Mail']['On'])
    {
        return;
    }
	
	//echo $ToList.'<=>'.$CCList.'<=>'.$Subject.'<=>'.$Message.'<br>';
	require_once("include/Class/PHPMailer/class.phpmailer.php");
    

    // Create an object of PHPMailer class and set the send method
    $Mail = new PHPMailer();
    
     $Mail->SetLanguage("en",  REAL_ROOT_PATH."/include/Class/PHPMailer/language/"); 
    
    switch(strtoupper($_CFG["Mail"]["SendMethod"]))
    {
        case "SMTP":
            $Mail->isSMTP();
            $Mail->Host     = $_CFG["Mail"]["SendParam"]["Host"];
            $Mail->SMTPAuth = $_CFG["Mail"]["SendParam"]["SMTPAuth"];
            $Mail->Username = $_CFG["Mail"]["SendParam"]["Username"];
            $Mail->Password = $_CFG["Mail"]["SendParam"]["Password"];
            break;
        case "MAIL":
            $Mail->isMail();
            break;
        case "SENDMAIL":
            $Mail->isSendmail();
            break;
        case "QMAIL":
            $Mail->isQmail();
            break;
    }
    //echo $Mail->Host.'<=>'.$Mail->SMTPAuth.'<=>'.$Mail->Username.'<=>'.$Mail->Password.'<br>';
    // Define From Address.
    $Mail->From     = $_CFG["Mail"]["FromAddress"];
    $Mail->FromName = $_CFG["Mail"]["FromName"];

    if(!is_array($ToList) && $ToList != '')
    {
        $ToList = explode(',', $ToList);
    }
    if(empty($ToList) && is_array($CCList) && !empty($CCList))
    {
        $ToList[] = array_pop($CCList);
    }
    if(empty($ToList))
    {
        return false;
    }
    foreach($ToList as $To)
    {
        $Mail->addAddress($To);
    }
    // Add To Address.
    if(is_array($CCList))
    {
        $CCList = array_diff($CCList, $ToList);
        foreach($CCList as $CC)
        {
            $Mail->addCC($CC);
        }
    }

    // Add Subject.
    $Subject  = '[***ESHOWPRO提示***]'.$Subject;
    $Mail->Subject  =  stripslashes($Subject);

    // Set Body.
    $Mail->IsHTML(true);
    $Mail->CharSet = $_LANG["Charset"];
    $Mail->Body    = stripslashes($Message);
    if(!$Mail->Send())
    {
      	$sendresult =  $Mail->ErrorInfo;
       //jsAlert($Mail->ErrorInfo);
    }
    
    return $sendresult;
}




/**
 * Enhanced mail function.
 *
 * @author                            Chunsheng Wang <wwccss@263.net>
 * @param   string      $ToList       To address list.
 * @param   string      $CCList       CC address list.
 * @param   string      $Subject      Subject.
 * @param   string      $Message      Message.
 */
function sysMailCustomer($ToList,$CCList,$Subject,$Message)
{
    global $_CFG, $_LANG;
    if(!$_CFG['Mail']['On'])
    {
        return;
    }
	
	//echo $ToList.'<=>'.$CCList.'<=>'.$Subject.'<=>'.$Message.'<br>';
	require_once("include/Class/PHPMailer/class.phpmailer.php");
    

    // Create an object of PHPMailer class and set the send method
    $Mail = new PHPMailer();
    
     $Mail->SetLanguage("en",  REAL_ROOT_PATH."/include/Class/PHPMailer/language/"); 
    
    switch(strtoupper($_CFG["Mail"]["SendMethod"]))
    {
        case "SMTP":
            $Mail->isSMTP();
            $Mail->Host     = $_CFG["Mail"]["SendParam"]["Host"];
            $Mail->SMTPAuth = $_CFG["Mail"]["SendParam"]["SMTPAuth"];
            $Mail->Username = $_CFG["Mail"]["SendParam"]["Username"];
            $Mail->Password = $_CFG["Mail"]["SendParam"]["Password"];
            break;
        case "MAIL":
            $Mail->isMail();
            break;
        case "SENDMAIL":
            $Mail->isSendmail();
            break;
        case "QMAIL":
            $Mail->isQmail();
            break;
    }
    //echo $Mail->Host.'<=>'.$Mail->SMTPAuth.'<=>'.$Mail->Username.'<=>'.$Mail->Password.'<br>';
    // Define From Address.
    $Mail->From     = $_CFG["Mail"]["FromAddress"];
    $Mail->FromName = $Subject;

    if(!is_array($ToList) && $ToList != '')
    {
        $ToList = explode(',', $ToList);
    }
    if(empty($ToList) && is_array($CCList) && !empty($CCList))
    {
        $ToList[] = array_pop($CCList);
    }
    if(empty($ToList))
    {
        return false;
    }
    foreach($ToList as $To)
    {
        $Mail->addAddress($To);
    }
    // Add To Address.
    if(is_array($CCList))
    {
        $CCList = array_diff($CCList, $ToList);
        foreach($CCList as $CC)
        {
            $Mail->addCC($CC);
        }
    }

    // Add Subject.
    //$Subject  = '[***ESHOWPRO提示***]'.$Subject;
    $Mail->Subject  =  stripslashes($Subject);

    // Set Body.
    $Mail->IsHTML(true);
    $Mail->CharSet = $_LANG["Charset"];
    $Mail->Body    = stripslashes($Message);
    
    if(!$Mail->Send())
    {
       echo $Mail->ErrorInfo;
       //jsAlert($Mail->ErrorInfo);
    }
}


/**
 * Enhanced mail function.
 *
 * @author                            Chunsheng Wang <wwccss@263.net>
 * @param   string      $ToList       To address list.
 * @param   string      $CCList       CC address list.
 * @param   string      $Subject      Subject.
 * @param   string      $Message      Message.
 */
function sysMail4Port($ToList,$CCList,$Subject,$Message)
{
    global $_CFG;
    
    if(!$_CFG['Mail']['On'])
    {
        return;
    }
	
	//echo $ToList.'<=>'.$CCList.'<=>'.$Subject.'<=>'.$Message.'<br>';
	require_once("include/Class/PHPMailer/class.phpmailer.php");
    

    // Create an object of PHPMailer class and set the send method
    $Mail = new PHPMailer();
    
    $Mail->SetLanguage("en",  REAL_ROOT_PATH."/include/Class/PHPMailer/language/"); 
    
    switch(strtoupper($_CFG["Mail"]["SendMethod"]))
    {
        case "SMTP":
            $Mail->isSMTP();
            $Mail->Host     = $_CFG["Mail"]["SendParam"]["Host"];
            $Mail->SMTPAuth = $_CFG["Mail"]["SendParam"]["SMTPAuth"];
            $Mail->Username = $_CFG["Mail"]["SendParam"]["Username"];
            $Mail->Password = $_CFG["Mail"]["SendParam"]["Password"];
            $Mail->Port = $_CFG["Mail"]["SendParam"]["Port"];
            break;
        case "MAIL":
            $Mail->isMail();
            break;
        case "SENDMAIL":
            $Mail->isSendmail();
            break;
        case "QMAIL":
            $Mail->isQmail();
            break;
    }
    //echo $Mail->Host.'<=>'.$Mail->SMTPAuth.'<=>'.$Mail->Username.'<=>'.$Mail->Password.'<br>';
    // Define From Address.
    $Mail->From     = $_CFG["Mail"]["FromAddress"];
    $Mail->FromName = $_CFG["Mail"]["FromName"];

    if(!is_array($ToList) && $ToList != '')
    {
        $ToList = explode(',', $ToList);
    }
    if(empty($ToList) && is_array($CCList) && !empty($CCList))
    {
        $ToList[] = array_pop($CCList);
    }
    if(empty($ToList))
    {
        return false;
    }
    foreach($ToList as $To)
    {
        $Mail->addAddress($To);
    }
    // Add To Address.
    if(is_array($CCList))
    {
        $CCList = array_diff($CCList, $ToList);
        foreach($CCList as $CC)
        {
            $Mail->addCC($CC);
        }
    }

    // Add Subject.
    $Subject  = '[***ESHOWPRO系统提示***]'.$Subject;
    $Mail->Subject  =  stripslashes($Subject);

    // Set Body.
    $Mail->IsHTML(true);
    $Mail->CharSet = 'utf-8';
    $Mail->Body    = stripslashes($Message);
    if(!$Mail->Send())
    {
       echo $Mail->ErrorInfo;
       //jsAlert($Mail->ErrorInfo);
    }
}





function get_timezone_date($remote_tz){
	/*$d =  time()-get_timezone_offset('America/New_York');
	return    date('Y-m-j H-i-s',$d);*/
	return  time()-get_timezone_offset($remote_tz);
	
}

function get_timezone_datefn($remote_tz,$origin_tz){
	/*$d =  time()-get_timezone_offset('America/New_York');
	return    date('Y-m-j H-i-s',$d);*/
	//   ('Asia/Hong_Kong','America/New_York')
	return  time()-get_timezone_offset($remote_tz,$origin_tz);
	
}

function get_timezone_datefn1($t,$remote_tz,$origin_tz){
	/*$d =  time()-get_timezone_offset('America/New_York');
	return    date('Y-m-j H-i-s',$d);*/
	//   ('Asia/Hong_Kong','America/New_York')
	return  $t-get_timezone_offset($remote_tz,$origin_tz);
	
}

function get_timezone_offset( $remote_tz , $origin_tz=null ){
	
	if( $origin_tz === null ){
		if( !is_string( $origin_tz = date_default_timezone_get() ) ){
			return false;  //如果没有时区配置
		}
	}
	
	$origin_dtz = new DateTimeZone( $origin_tz );
	$remote_dtz = new DateTimeZone( $remote_tz );
	
	$origin_dt = new DateTime('now', $origin_dtz );
	$remote_dt = new DateTime('now', $remote_dtz );
	
	$offset = $origin_dtz->getOffset($origin_dt) - $remote_dtz->getOffset( $remote_dt ) ;
	
	return $offset;
	
}



function getZhCnFristb($name){
	
		global $_CFG;
	
 		$LastRealName = $name;
        $RealNamePrefix = sysSubStr($LastRealName, 1);
        $FirstLetter = $_CFG['PinYin'][$RealNamePrefix];
        if($FirstLetter == '')
        {
	        $FirstLetter = strtoupper(substr($LastRealName, 0, 1));
        }
        /*if(!ereg('[A-Z0-9]',$FirstLetter))
        {
            $FirstLetter = strtoupper(substr($name, 0, 1));
        }*/
    	/*  if(!ereg('[A-Z0-9]',$FirstLetter))
        {
            $FirstLetter = '*';
        }*/
        
        return $FirstLetter ;
        
}



function sysSubStr($String,$Length,$Append = false)
{
    global $_CFG;

    $I = 0;
    $Count = 0;
    if($_CFG["DefaultLang"]  == "ZH_CN_UTF-8")
    {
        while ($Count < $Length)
        {
            $StringTMP = substr($String,$I,1);
            if ( ord($StringTMP) >=224 )
            {
                $StringTMP = substr($String,$I,3);
                $I = $I + 3;
                $Count += 2;
            }
            elseif( ord($StringTMP) >=192 )
            {
                $StringTMP = substr($String,$I,2);
                $I = $I + 2;
                $Count ++;
            }
            else
            {
                $I = $I + 1;
                $Count ++;
            }
            $StringLast[] = $StringTMP;
        }
        if($Count == $Length)
        {
            array_pop($StringLast);
        }
        $StringLast = implode("",$StringLast);
        if($Append && $String != $StringLast)
        {
            $StringLast .= "...";
        }
        return $StringLast;
    }
    else
    {
        while ($Count < $Length)
        {
            $StringTMP = substr($String,$I,1);
            if( ord($StringTMP) >=128 )
            {
                $StringTMP = substr($String,$I,2);
                $I = $I + 2;
                $Count += 2;
            }
            else
            {
                $I = $I + 1;
                $Count ++;
            }
            $StringLast[] = $StringTMP;
        }
        if($Count == $Length)
        {
            array_pop($StringLast);
        }
        $StringLast = implode("",$StringLast);
        if($Append && $String != $StringLast)
        {
            $StringLast .= "...";
        }
        return $StringLast;
    }
}

/**
 * 
 * 获取业务相关的时间
 *
 */
function getbDataString($aimdate){
	
	
	if( empty($aimdate))
		return ''; 
	
	
		
	$curr_date = time();
	
	$diff =round(($curr_date-strtotime($aimdate))/3600/24) ; 
	
	$datesss = date('H:i',strtotime($aimdate));
	
	//echo  date("Y-m-d H:i:s",strtotime($aimdate)).$datesss;

	$datestr = '';
	
	if( $diff == 0  ){

		$datestr = $datesss;
	
	}elseif( $diff == 1 ){
		
		$datestr = "昨天 ". $datesss;
	
	}else{

		$datestr = date("Y-m-d H:i:s",strtotime($aimdate));
		
	}
	
	return $datestr;
	
	//昨天显示 昨天+小时分钟
	
	//以前的显示具体时间
	
		
	
}



/**
 * 获取会话编号
 *
 * @return unknown
 */
function getuuid($perflag) {
	
	$rand =  rand ( 1, 10000 ) . uniqid ( '', true );
	$rand = str_replace(".", "", $rand);
	$rand = $perflag.$rand;
	return $perflag.md5($rand);
	
}


function getMutilFileName($filename){
	
	
	if( (bool)strpos($filename,',,') ){
		$picgrouparray = explode(',,',$filename);
		return $picgrouparray[0];
	}else{
		return $filename;
	}
	 
	
}


/**
 * 判断字符是否为纯汉字
 *
 * @param unknown_type $str   0 '纯英文'  1 '纯汉字' 2 '中英文混排序'
 * @return unknown
 */
function utf8_str($str){
    $mb = mb_strlen($str,'utf-8');
    $st = strlen($str);
    if($st==$mb)
        //return '纯英文';
        return 0;
    if($st%$mb==0 && $st%3==0) //return '纯汉字';
        return 1;
    return 2;
}


/**
 * $date 需要操作的日期
 * $day  相加的天数
 * 
 * @return 返回的日期
 */
function addday($date, $day) {
	//return date('Y-m-d',strtotime($date ." +".$day." day"));
	$t1 = strtotime ( $date );
	$t2 = $t1 + $day * 3600 * 24;
	return date ( "Y-m-d", $t2 );

}

/**
 * $date 需要操作的日期
 * $day  相加的天数
 * 
 * @return 返回的日期
 */
function adddayformat($date, $day, $format) {
	//return date('Y-m-d',strtotime($date ." +".$day." day"));
	

	$t1 = strtotime ( $date );
	$t2 = $t1 + $day * 3600 * 24;
	return date ( $format, $t2 );

}

/**
 * Enhance the function addslashes())
 *
 * @author                  Chunsheng Wang <wwccss@263.net>
 * @param  mix     $Data    the variable to addslashes.
 * @return mix              formated variable.
 */
function sysAddSlash($Data) {
	if (is_array ( $Data )) {
		foreach ( $Data as $Key => $Value ) {
			if (is_array ( $Value )) {
				$Data [$Key] = sysAddSlash ( $Value );
			} else {
				$Data [$Key] = addslashes ( $Value );
			}
		}
	} else {
		$Data = addslashes ( $Data );
	}
	return $Data;
}

/**
 *
 * Get table names with prefix
 *
 * @author                      Yupeng Lee<leeyupeng@gmail.com>
 * @param   string  $TableNames TableNames split by ,
 * @return  string              TableNames whith prefix split by ,
 */
function dbGetPrefixTableNames($TableNames) {
	/* global $_CFG;

    if($_CFG['UserDB']['User'] != '' && $TableNames == $_CFG['UserTable']['TableName'])
    {
        return $TableNames;
    }
    $TableList = explode(',', $TableNames);
    $PrefixTableNameList = array();
    foreach($TableList as $TableName)
    {
        $TableName = trim($TableName);
        $PrefixTableNameList[] = $_CFG['DB']['TablePrefix'] . $TableName;
    }
    $PrefixTableNames = join(',', $PrefixTableNameList);*/
	
	return $TableNames;
}



function htmlSelect4Mysql(){
	
	
	
}


/**
 * create tags like "<select><option></option></select>"
 *
 * @author                     wwccss<wwccss@263.net>
 * @param array  $ArrayData    the array to create select tag from.
 * @param string $SelectName   the name of the select tag.
 * @param string $Mode         Normal|Reverse,if normal, show the key of the array in the select box, else show the value of the array in the select box.
 * @param string $SelectItem   the item(s) to be selected, can like item1,item2.
 * @param string $Attrib       other params such as multiple, size and style.
 * @param booble $Echo         show directly or false. 
 */
function htmlSelect($ArrayData, $SelectName, $Mode = "Reverse", $SelectItem = "", $Attrib = "", $PairIndex = "", $Echo = false, $default = false) {
	
    if (! is_array ( $ArrayData )) {
		$ArrayData = array ();
	}
	
	if( !empty( $_REQUEST['PAGE_SLTY']  ) ){
	    
	    $Attrib = $Attrib . " class=\"form-control input-xs input-sm input-inline\" ";
	    
	}
	
	
	$Mode = $Mode != 'Normal' ? 'Reverse' : 'Normal';
	
	/* The begin. */
	if( (bool)strpos('dd'.$Attrib,'multiple')  ){ //阿里巴巴专用
		$SelectString = "\n  <select name='$SelectName' ";
	}else
		$SelectString = "\n  <select name='$SelectName' ";
	
	/* Set the id. */
	if (preg_match ( "/\[/", $SelectName )) {
		$SelectName = explode ( "[", $SelectName );
		$SelectString .= "id='$SelectName[0]' ";
	} else {
		$SelectString .= "id='$SelectName'";
	}
	
	/* The param. */
	$SelectString .= " $Attrib >\n";
	
	/* Explode the SelectItems. */
	$SelectItem = explode ( ",", $SelectItem );
	
	/* The option. */
	if ($PairIndex != "") {
		$PairIndex = explode ( ',', $PairIndex );
		$KeyIndex = trim ( $PairIndex [0] );
		$ValueIndex = trim ( $PairIndex [1] );
	}
	
	if (count ( $ArrayData ) == 0 && ! @ereg ( 'multiple', strtolower ( $Attrib ) )) {
		$SelectString .= '<option selected label="null" value="" style="color:#AAAAAA;">--------</option>';
	} else {
		foreach ( $ArrayData as $Key => $Value ) {
			if (is_array ( $Value )) {
				$Key = $Value [$KeyIndex];
				$Value = $Value [$ValueIndex];
			}
			if ($Mode == "Normal") {
				if (in_array ( $Value, $SelectItem ) && $SelectItem != '') {
					if ($default)
						$SelectString .= "<option value='$Value'>$Key</option>";
					else
						$SelectString .= "<option value='$Value' selected='selected'>$Key</option>";
				} else {
					$SelectString .= "<option value='$Value'>$Key</option>";
				}
			} elseif ($Mode == "Reverse") {
				if (in_array ( $Key, $SelectItem ) && $SelectItem != '') {
					$SelectString .= "<option value='$Key' selected='selected'>$Value</option>";
				} else {
					$SelectString .= "<option value='$Key'>$Value</option>";
				}
			}
			$SelectString .= "\n";
		}
	}
	if ($default)
		$SelectString .= "<option value='' selected='selected'>===请选择===</option>";
		/* The end. */
	$SelectString .= "</select>\n";
	
	if ($Echo) {
		echo $SelectString;
	}
	return $SelectString;
}

function htmlSelectm($ArrayData, $SelectName, $Mode = "Reverse", $SelectItem = "", $Attrib = "", $PairIndex = "", $Echo = false, $default = false) {
	if (! is_array ( $ArrayData )) {
		$ArrayData = array ();
	}
	
	$Mode = $Mode != 'Normal' ? 'Reverse' : 'Normal';
	
	/* The begin. */
	if( (bool)strpos('dd'.$Attrib,'multiple')  ){ //阿里巴巴专用
		$SelectString = "\n  <select name='$SelectName"."[]' ";
	}else
		$SelectString = "\n  <select name='$SelectName' ";
	
	/* Set the id. */
	if (preg_match ( "/\[/", $SelectName )) {
		$SelectName = explode ( "[", $SelectName );
		$SelectString .= "id='$SelectName[0]' ";
	} else {
		$SelectString .= "id='$SelectName'";
	}
	
	/* The param. */
	$SelectString .= " $Attrib >\n";
	
	/* Explode the SelectItems. */
	$SelectItem = explode ( ",", $SelectItem );
	
	/* The option. */
	if ($PairIndex != "") {
		$PairIndex = explode ( ',', $PairIndex );
		$KeyIndex = trim ( $PairIndex [0] );
		$ValueIndex = trim ( $PairIndex [1] );
	}
	
	if (count ( $ArrayData ) == 0 && ! ereg ( 'multiple', strtolower ( $Attrib ) )) {
		$SelectString .= '<option selected label="null" value="" style="color:#AAAAAA;">--------</option>';
	} else {
		foreach ( $ArrayData as $Key => $Value ) {
			if (is_array ( $Value )) {
				$Key = $Value [$KeyIndex];
				$Value = $Value [$ValueIndex];
			}
			if ($Mode == "Normal") {
				if (in_array ( $Value, $SelectItem ) && $SelectItem != '') {
					if ($default)
						$SelectString .= "<option value='$Value'>$Key</option>";
					else
						$SelectString .= "<option value='$Value' selected='selected'>$Key</option>";
				} else {
					$SelectString .= "<option value='$Value'>$Key</option>";
				}
			} elseif ($Mode == "Reverse") {
				if (in_array ( $Key, $SelectItem ) && $SelectItem != '') {
					$SelectString .= "<option value='$Key' selected='selected'>$Value</option>";
				} else {
					$SelectString .= "<option value='$Key'>$Value</option>";
				}
			}
			$SelectString .= "\n";
		}
	}
	if ($default)
		$SelectString .= "<option value='' selected='selected'>===请选择===</option>";
		/* The end. */
	$SelectString .= "</select>\n";
	
	if ($Echo) {
		echo $SelectString;
	}
	return $SelectString;
}



/**
 * 截取中英文混合的字符串，字符串采用UTF-8编码
 *
 * @param unknown_type $string
 * @param unknown_type $start
 * @param unknown_type $length
 * @return unknown
 */
function substr_utf8($string, $start, $length) { //by aiou   
	$chars = $string;
	//echo $string[0].$string[1].$string[2];   
	$i = 0;
	do {
		if (preg_match ( "/[0-9a-zA-Z]/", $chars [$i] )) { //纯英文   
			$m ++;
		} else {
			$n ++;
		} //非英文字节,   
		$k = $n / 3 + $m / 2;
		$l = $n / 3 + $m; //最终截取长度；$l = $n/3+$m*2？   
		$i ++;
	} while ( $k < $length );
	$str1 = mb_substr ( $string, $start, $l, 'utf-8' ); //保证不会出现乱码   
	return $str1;
}

function strLength($str,$charset='utf-8'){
      if($charset=='utf-8') 
      	$str = iconv('utf-8','gb2312',$str);
      $num = strlen($str);
    $cnNum = 0;
    for($i=0;$i<$num;$i++){
        if(ord(substr($str,$i+1,1))>127){
            $cnNum++;
            $i++;
        }
    }
    $enNum = $num-($cnNum*2);
    $number = ($enNum/2)+$cnNum;
    return ceil($number);
 }
/**
 * 上传图片
 *
 */
function uploadFiles($filefiled, $uploadfilepath, $filenameprfix) {
	
	//print_r($_FILES);
	//global $_CFG;
	if (! empty ( $_FILES )) {
		//print_r($_FILES);
		$tempFile = $_FILES [$filefiled] ['tmp_name'];
		//$targetPath = $_CFG['RealRootPath'] . '/'.$_REQUEST['folder'] . '/';
		//$targetFile =  str_replace('//','/',$targetPath) . $_FILES['upfile']['name'];
		if ($_FILES [$filefiled] ['name'] != '') {
			$file_perfix = rand ( 1000, 10000 ) . date ( 'YmjGis' ) . floor ( microtime () * 1000 );
			$filename = $_FILES [$filefiled] ['name'];
			$filenametype = substr ( $filename, strrpos ( $filename, '.' ), strlen ( $filename ) );
			$upload_file_name = $filenameprfix . $file_perfix . $filenametype;
			move_uploaded_file ( $tempFile, $uploadfilepath . $upload_file_name );
		}
	
	}
	
	$result = array ();
	$result ['filepath'] = $uploadfilepath . $upload_file_name;
	$result ['filename'] = $upload_file_name;
	$result ['type'] = $_FILES [$filefiled] ['type'];
	return $result;

}

/**
 * 上传图片
 *
 */
function uploadFiles4Fullname($filefiled, $uploadfilepath) {
	
	//print_r($_FILES);
	//global $_CFG;
	if (! empty ( $_FILES )) {
		//print_r($_FILES);
		$tempFile = $_FILES [$filefiled] ['tmp_name'];
		move_uploaded_file ( $tempFile, $uploadfilepath );
	}
	
	$result = array ();
	$result ['filepath'] = $uploadfilepath;
	$result ['filename'] = $uploadfilepath;
	$result ['type'] = $_FILES [$filefiled] ['type'];
	return $result;

}

/**
 * Enter description here...
 *
 * @param unknown_type $im
 * @param unknown_type $maxwidth
 * @param unknown_type $maxheight
 * @param unknown_type $name
 */
function ResizeImage($im, $maxwidth, $maxheight, $name) {
	
	$width = imagesx ( $im );
	$height = imagesy ( $im );
	
	if (($maxwidth && $width > $maxwidth) || ($maxheight && $height > $maxheight)) {
		
		if ($maxwidth && $width > $maxwidth) {
			$widthratio = $maxwidth / $width;
			$RESIZEWIDTH = true;
		}
		if ($maxheight && $height > $maxheight) {
			$heightratio = $maxheight / $height;
			$RESIZEHEIGHT = true;
		}
		if ($RESIZEWIDTH && $RESIZEHEIGHT) {
			if ($widthratio < $heightratio) {
				$ratio = $widthratio;
			} else {
				$ratio = $heightratio;
			}
		} elseif ($RESIZEWIDTH) {
			$ratio = $widthratio;
		} elseif ($RESIZEHEIGHT) {
			$ratio = $heightratio;
		}
		$newwidth = $width * $ratio;
		$newheight = $height * $ratio;
		if (function_exists ( "imagecopyresampled" )) {
			$newim = imagecreatetruecolor ( $newwidth, $newheight );
			imagecopyresampled ( $newim, $im, 0, 0, 0, 0, $newwidth, $newheight, $width, $height );
		} else {
			$newim = imagecreate ( $newwidth, $newheight );
			imagecopyresized ( $newim, $im, 0, 0, 0, 0, $newwidth, $newheight, $width, $height );
		}
		ImageJpeg ( $newim, $name, 100 );
		ImageDestroy ( $newim );
	} else {
		ImageJpeg ( $im, $name );
		if( !empty($newim) )
			ImageDestroy ( $newim );
	}
}

function changeimagesize($imagetype, $tempfile, $filename, $resizewidth, $resizeheight) {
	
	// 生成图片的宽度  $_FILES ['image'] ['type']  $_FILES ['image'] ['tmp_name']
	//$resizewidth = 40;
	// 生成图片的高度 
	//$resizeheight = 80;
	if ($imagetype == "image/pjpeg") {
		//echo $imagetype;
		$im = imagecreatefromjpeg ( $tempfile );
	} elseif ($imagetype == "image/x-png") {
		$im = imagecreatefrompng ( $tempfile );
	} elseif ($imagetype == "image/gif") {
		$im = imagecreatefromgif ( $tempfile );
	}
	
	if ($im) {
		if (file_exists ( $filename )) {
			unlink ( $filename );
		}
		ResizeImage ( $im, $resizewidth, $resizeheight, $filename );
		ImageDestroy ( $im );
	}
	
//echo $im;


}

//加密
/*function encrypt($encrypt, $key = "") {
	$iv = mcrypt_create_iv ( mcrypt_get_iv_size ( MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB ), MCRYPT_RAND );
	$passcrypt = mcrypt_encrypt ( MCRYPT_RIJNDAEL_256, $key, $encrypt, MCRYPT_MODE_ECB, $iv );
	$encode = base64_encode ( $passcrypt );
	return $encode;
}*/

//解密函数
/*function decrypt($decrypt, $key = "") {
	$decoded = base64_decode ( $decrypt );
	$iv = mcrypt_create_iv ( mcrypt_get_iv_size ( MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB ), MCRYPT_RAND );
	$decrypted = mcrypt_decrypt ( MCRYPT_RIJNDAEL_256, $key, $decoded, MCRYPT_MODE_ECB, $iv );
	return $decrypted;
}
*/


////////////  http://www.nonb.cn/blog/php-des-jia-mi-suan-fa.html


/**
 * 加密
 *
 * @param unknown_type $input
 * @param unknown_type $key
 * @return unknown
 */
function encrypt($input, $key) {
	$size = mcrypt_get_block_size ( 'des', 'ecb' );
	$input = mb_convert_encoding($input, 'GBK', 'UTF-8');
	$input = pkcs5_pad ( $input, $size );
	//$key = $this->key;    	
	$td = mcrypt_module_open ( 'des', '', 'ecb', '' );
	$iv = @mcrypt_create_iv ( mcrypt_enc_get_iv_size ( $td ), MCRYPT_RAND );
	@mcrypt_generic_init ( $td, $key, $iv );
	$data = mcrypt_generic ( $td, $input );
	mcrypt_generic_deinit ( $td );
	mcrypt_module_close ( $td );
	$data = base64_encode ( $data );
	return $data;
}

/**
 * 解密
 *
 * @param unknown_type $encrypted
 * @param unknown_type $key
 * @return unknown
 */
function decrypt($encrypted, $key) {
	$encrypted = base64_decode ( $encrypted );
	//$key =$this->key;    	
	$td = mcrypt_module_open ( 'des', '', 'ecb', '' );
	//$td = mcrypt_module_open(MCRYPT_RIJNDAEL_128, '', 'ecb', '');
	//$td = mcrypt_module_open(MCRYPT_RIJNDAEL_256, '', MCRYPT_MODE_CBC, '');
	//使用MCRYPT_DES算法,cbc模式          	
	$iv = @mcrypt_create_iv ( mcrypt_enc_get_iv_size ( $td ), MCRYPT_RAND );
	//$ks = mcrypt_enc_get_key_size ( $td );
	@mcrypt_generic_init ( $td, $key, $iv );
	//初始处理           	
	$decrypted = mdecrypt_generic ( $td, $encrypted );
	//解密           	
	mcrypt_generic_deinit ( $td );
	//结束          
	mcrypt_module_close ( $td );
	$y = pkcs5_unpad ( $decrypted );
	$y = mb_convert_encoding($y, 'UTF-8', 'GBK');
	return $y;
}

function pkcs5_pad($text, $blocksize) {
	$pad = $blocksize - (strlen ( $text ) % $blocksize);
	return $text . str_repeat ( chr ( $pad ), $pad );
}


function pkcs5_unpad($text) {
	$pad = ord ( $text {strlen ( $text ) - 1} );
	if ($pad > strlen ( $text ))
		return false;
	if (strspn ( $text, chr ( $pad ), strlen ( $text ) - $pad ) != $pad)
		return false;
	return substr ( $text, 0, - 1 * $pad );
}



function encrypt1($encrypt,$key="") { 
$iv = mcrypt_create_iv ( mcrypt_get_iv_size ( MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB ), MCRYPT_RAND ); 
$passcrypt = mcrypt_encrypt ( MCRYPT_RIJNDAEL_256, $key, $encrypt, MCRYPT_MODE_ECB, $iv ); 
$encode = base64_encode ( $passcrypt ); 
return $encode; 
} 

function decrypt1($decrypt,$key="") { 
$decoded = base64_decode ( $decrypt ); 
$iv = mcrypt_create_iv ( mcrypt_get_iv_size ( MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB ), MCRYPT_RAND ); 
$decrypted = mcrypt_decrypt ( MCRYPT_RIJNDAEL_256, $key, $decoded, MCRYPT_MODE_ECB, $iv );
return $decrypted; 
} 


function den(  $plain_text , $key  ){
	
	 /* Open module, and create IV */
    $td = mcrypt_module_open('des', '', 'ecb', '');
    $key = substr($key, 0, mcrypt_enc_get_key_size($td));
    $iv_size = mcrypt_enc_get_iv_size($td);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);

    /* Initialize encryption handle */
    if (mcrypt_generic_init($td, $key, $iv) != -1) {

        /* Encrypt data */
        $c_t = mcrypt_generic($td, $plain_text);
        mcrypt_generic_deinit($td);

        /* Reinitialize buffers for decryption */
        mcrypt_generic_init($td, $key, $iv);
        $p_t = mdecrypt_generic($td, $c_t);

        /* Clean up */
        mcrypt_generic_deinit($td);
        mcrypt_module_close($td);
        
        return $p_t;
    }else 
    	return '';
	
	
}

function genRandomString($len) 
{ 
    $chars = array( 
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k",  
        "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v",  
        "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G",  
        "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R",  
        "S", "T", "U", "V", "W", "X", "Y", "Z", "0", "1", "2",  
        "3", "4", "5", "6", "7", "8", "9" 
    ); 
    $charsLen = count($chars) - 1; 
 
    shuffle($chars);    // 将数组打乱 
     
    $output = ""; 
    for ($i=0; $i<$len; $i++) 
    { 
        $output .= $chars[mt_rand(0, $charsLen)]; 
    } 
 
    return $output; 
 
} 


/**
 * 
 * 判断当前php运行环境的操作系统
 *
 * @return unknown
 * 
 */
function iswidnows(){
	
	//$os = $_ENV["OS"];
	if(strpos($_ENV["OS"],"Window")) {
	
		return 1;
	
	}else{
	    return 0;
	}
	
	
}




/**
 * 
 * 判断当前php运行环境的操作系统
 *
 * @return unknown
 * 
 */
function isFastCgi(){
	
	$runmodel = php_sapi_name();
	
	if( $runmodel ==  "fpm-fcgi") {
		return 1;
	}else{
	    return 0;
	}
	
	
}


/**
 * 
 * 是否允许fastcgi_finish_request() 函数以提高性能
 *
 */
function runfastcgifinishrequest(){
	
	if( isFastCgi() == 1  )
		fastcgi_finish_request(); /* 响应完成, 关闭连接 */
	
}


/**
 * 
 * 获取回话生命周期
 * 
 */
function getSessionTimeout(){
	
	
	global $_CFG;
	
	$now = time(NULL);
	$timeout = $now + $_CFG['timeout'];
	
	return $timeout;
}

/**
 * 
 * 本地应用程序信息
 * @return unknown
 * 
 */
function getClientinfo(){
	
	global $_CFG;
	
	$clientip = $_CFG['slefip'];
	$appname = $_CFG['appname'];
	$info_arr = array('appname'=>$appname , 'ip'=>$clientip);
	return json_encode($info_arr);
	
}

function is_mobile(){

    // returns true if one of the specified mobile browsers is detected
    // 如果监测到是指定的浏览器之一则返回true
    
    $regex_match="/(nokia|iphone|Android|android|motorola|^mot\\-|softbank|foma|docomo|kddi|up\\.browser|up\\.link|";
    
    $regex_match.="htc|dopod|blazer|netfront|helio|hosin|huawei|novarra|CoolPad|webos|techfaith|palmsource|";
    
    $regex_match.="blackberry|alcatel|amoi|ktouch|nexian|samsung|^sam\\-|s[cg]h|^lge|ericsson|philips|sagem|wellcom|bunjalloo|maui|";
    
    $regex_match.="symbian|smartphone|midp|wap|phone|windows ce|iemobile|^spice|^bird|^zte\\-|longcos|pantech|gionee|^sie\\-|portalmmm|";   
    
    $regex_match.="jig\s browser|hiptop|^ucweb|^benq|haier|^lct|opera\s*mobi|opera\\*mini|320x320|240x320|176x220";
    
    $regex_match.=")/i";
    
    // preg_match()方法功能为匹配字符，既第二个参数所含字符是否包含第一个参数所含字符，包含则返回1既true
    return preg_match($regex_match, strtolower($_SERVER['HTTP_USER_AGENT']));
}

function isMobile1() {
	
  //判断手机发送的客户端标志
  if(isset($_SERVER['HTTP_USER_AGENT'])) {
    $userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
    $clientkeywords = array(
      'nokia', 'sony', 'ericsson', 'mot', 'samsung', 'htc', 'sgh', 'lg', 'sharp', 'sie-'
      ,'philips', 'panasonic', 'alcatel', 'lenovo', 'ipod', 'blackberry', 'meizu', 
      'netfront', 'symbian', 'windowsce', 'palm', 'operamini', 
      'operamobi', 'opera mobi', 'openwave', 'nexusone', 'cldc', 'midp', 'wap', 
      'mobile','Google Wireless Transcoder','Windows CE','WindowsCE','Symbian',
      'Android','armv6l','armv5','Mobile','CentOS','mowser','AvantGo','Opera Mobi','J2ME/MIDP',
      'Smartphone','Go.Web','Palm','iPAQ','160×160',
 	  '176×220','240×240','240×320','320×240',
 	  'UP.Browser','UP.Link',
 	  'SymbianOS','PalmOS',
 	  'PocketPC',
 	  'SonyEricsson',
 	  'Nokia',
 	  'BlackBerry',
 	  'Vodafone',
 	  'BenQ',
 	  'Novarra-Vision',
 	  'Iris',
 	  'NetFront',
 	  'HTC_',
 	  'Xda_',
 	  'SAMSUNG-SGH',
 	  'Wapaka',
 	  'DoCoMo',
 	  'iPhone',
 	  'iPod'
    );
    // 从HTTP_USER_AGENT中查找手机浏览器的关键字
    if(preg_match("/(".implode('|',$clientkeywords).")/i",$userAgent)&&strpos($userAgent,'ipad') === false)
    {
      return true;
    }
  }
  return false;
}
/**
 * 当前用户访问网站是否为手机登录
 * @return boolean
 */
 function isMobile() { 
 	
 	$useragent=isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''; 
 	$useragent_commentsblock=preg_match('|\(.*?\)|',$useragent,$matches)>0?$matches[0]:''; 	 
 	  $mobile_os_list=array('Google Wireless Transcoder','Windows CE','WindowsCE','Symbian','Android','android','armv6l','armv5','Mobile','CentOS','mowser','AvantGo','Opera Mobi','J2ME/MIDP','Smartphone','Go.Web','Palm','iPAQ'); 
 	  $mobile_token_list=array('Profile/MIDP','Configuration/CLDC-','160×160',
 	  '176×220','240×240','240×320','320×240',
 	  'UP.Browser','UP.Link',
 	  'SymbianOS','PalmOS',
 	  'PocketPC',
 	  'SonyEricsson',
 	  'Nokia',
 	  'BlackBerry',
 	  'Vodafone',
 	  'BenQ',
 	  'Novarra-Vision',
 	  'Iris',
 	  'NetFront',
 	  'HTC_',
 	  'Xda_',
 	  'SAMSUNG-SGH',
 	  'Wapaka',
 	  'DoCoMo',
 	  'iPhone',
 	  'iPod'); 
 	  $found_mobile= CheckSubstrs($mobile_os_list,$useragent_commentsblock) || CheckSubstrs($mobile_token_list,$useragent); 
 	  if ($found_mobile) 
 	       { 
 	       	return true; 
 	       } 
 	  else {
 	  	return false; 
 	    }
 	   
  }
  
 function CheckSubstrs($substrs,$text)
  {
  	foreach($substrs as $substr)
  	{
  		if(false!==strpos($text,$substr))
  		{
  			return true;
  		}
  	}
  	return false;
  	 
  }

function getPageSpeedbean($request){
	
	$op = $request['op']==''?"-1":$request['op'];
	$datestr = date('YmdHis');
	$opter = array(
						'appid'=>'1',
						'channelid'=>$request['channel'],
						'sessionid'=>$request['sessionid'],
						'optdt'=>$datestr,
						'openid'=>$request['openid']==''?"":$request['openid'],
						'platform'=>$request['platform'],
						'phonemodel'=>$request['phonemodel'],
						'mplatform'=>$request['mplatform'],
						'modulename'=>$request['modulename'],
						//'ipaddr'=>$this->getIP(),
						'usercode'=>$request['usercode'],
						'version'=>$request['version'],
						'operators'=>$request['operators']==''?"":$request['operators'],
						'nettype'=>$request['nettype']==''?"":$request['nettype'],
						'resolution'=>$request['resolution']==''?"":$request['resolution'],
						'area'=>$request['area']==''?"":$request['area'],
						'fristopen'=>$request['fristopen'],
						'openflag'=>$request['openflag'],
						'extd'=>$request['extd']==''?"":$request['extd'],
						'op'=>$op,
						'nt'=>$request['nt']==''?"":$request['nt'],
						'imi'=>$request['imi']==''?"":$request['imi'],
						'width'=>$request['width'],
						'height'=>$request['height'],
						'cra'=>$request['cra']==''?"-1":$request['cra'],
						'ad'=>$request['ad']==''?"":$request['ad'],
						'userid'=>$request['userid'],
						'us'=>$request['us']==''?"":$request['us'],
						'clientid'=>$request['clientid']
					   );
		 $opterlog = json_encode ( $opter );

		 return $opterlog;
}


/**
 * Enter description here...
 *
 * @param unknown_type $text      需要翻译的文本
 * @param unknown_type $org_lang  源语言
 * @param unknown_type $a_lang    目标语言
 */
function googletrans($text , $org_lang , $a_lang){
	
	require_once 'include/Class/HttpClient.class.php';
	
	
			/*		
		
		$ddd  = "http://translate.google.cn/translate_a/t?client=t&text=$d&hl=zh-CN&sl=zh-CN&tl=en&ie=UTF-8&oe=UTF-8&multires=1&otf=1&pc=1&it=srcd_gms.1378&ssel=4&tsel=6&sc=1";
		echo HttpClient::quickGet($ddd);*/
		//$d = urlencode("MENDEL隐形镀膜液,世界第一,呵呵呵");		
		//$tran_result = "/translate_a/t?client=t&text=$d&hl=zh-CN&sl=zh-CN&tl=en&ie=UTF-8&oe=UTF-8&multires=1&otf=1&pc=1&it=srcd_gms.1378&ssel=4&tsel=6&sc=1";
		$client = new HttpClient("translate.google.cn");
		//$client->setDebug(true);
		$client->setUserAgent('Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36');
		/*if (!$client->get($ddd)) {
		    die('An error occurred: '.$client->getError());
		}*/
		
		
		$ddd1 = "/translate_a/t";
		
		$client->post($ddd1, array(
		    'client'=>'t',
		    'text' => $text,
			//'hl'=>'zh-CN',
			'sl'=>$org_lang,  //源语言
			'tl'=>$a_lang,     //目标语言 
			'ie'=>'UTF-8',  //输入的文字的编码为UTF-8  
			'oe'=>'UTF-8',	//输出，翻译后，的文字的编码为UTF-8
			'multires'=>'1',
			'otf'=>'1',
			'pc'=>'1',
			'it'=>'srcd_gms.1378',
			'ssel'=>'4',
			'tsel'=>'6',
			'sc'=>'1'	
		));
				
		$tran_result =  $client->getContent();
		
		//$start = strpos($ddd,'[[["');
		$end = strpos($tran_result,'","');
		
		//echo " start : $start ,  end : $end ";
		
		return substr($tran_result,4,$end-4);
		//$ddd_json = json_decode($ddd,true);
		
		//print_r($ddd);
		//echo HttpClient::quickGet($ddd);
	
	
}


function baidutrans($text , $org_lang , $a_lang){
	
		$text = urlencode($text);
		$ch = curl_init();
	    $url = "http://apis.baidu.com/apistore/tranlateservice/translate?query=$text&from=$org_lang&to=$a_lang";
	    $header = array(
	        'apikey:7de4f9c38cb72a556e21effd190cec38',
	    );
	    // 添加apikey到header
	    curl_setopt($ch, CURLOPT_HTTPHEADER  , $header);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    // 执行HTTP请求
	    curl_setopt($ch , CURLOPT_URL , $url);
	    $res = curl_exec($ch);
	
	    //var_dump(json_decode($res));
		
		return  $res;
	
	
}


function baidutransval($text , $org_lang , $a_lang){
	
		$text = urlencode($text);
		$ch = curl_init();
	    $url = "http://apis.baidu.com/apistore/tranlateservice/translate?query=$text&from=$org_lang&to=$a_lang";
	    $header = array(
	        'apikey:7de4f9c38cb72a556e21effd190cec38',
	    );
	    // 添加apikey到header
	    curl_setopt($ch, CURLOPT_HTTPHEADER  , $header);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    // 执行HTTP请求
	    curl_setopt($ch , CURLOPT_URL , $url);
	    $res = curl_exec($ch);
		$res_arr = json_decode($res,true);
	    //var_dump(json_decode($res));
		
		return  $res_arr['retData']['trans_result'][0]['dst'];
	
	
}


function baidutransvalnew($text , $org_lang , $a_lang){
		
		$appid = '20151202000007199';
		$sing = "mnLl4xVLugEDxUqe8RO0";
		
		$text = urlencode($text);
		
		$salt = rand(10000,99999);
		
		$str = $appid . $text . $salt . $sing;
   		$ret = md5($str);
		
	
		
		$ch = curl_init();
	    
		//$url = "http://apis.baidu.com/apistore/tranlateservice/translate?query=$text&from=$org_lang&to=$a_lang";
	    
		$url = "http://api.fanyi.baidu.com/api/trans/vip/translate?q=$text&from=$org_lang&to=$a_lang&appid=$appid&salt=$salt&sign=$ret";
	    
	   
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    // 执行HTTP请求
	    curl_setopt($ch , CURLOPT_URL , $url);
	    $res = curl_exec($ch);
		$res_arr = json_decode($res,true);
	    
		print_r( $res_arr );
		
		return  $res_arr['retData']['trans_result'][0]['dst'];
	
	
}





/**
 * 调用googleapi完成验证
 *
 * @param unknown_type $text
 * @param unknown_type $org_lang
 * @param unknown_type $a_lang
 */
function googletransapi($text , $org_lang , $a_lang){
	
	
	
}



define("CURL_TIMEOUT",   10); 
define("URL",            "http://api.fanyi.baidu.com/api/trans/vip/translate"); 
/* define("APP_ID",         "20151202000007199"); //替换为您的APPID
define("SEC_KEY",        "mnLl4xVLugEDxUqe8RO0");//替换为您的密钥 */

/////////////////////////另外一组API省钱用的////////////////////
//APP ID：20160829000027693
//密钥：g8dGVYFdzOKoQLKknOni

define("APP_ID",         "20160829000027693"); //替换为您的APPID
define("SEC_KEY",        "g8dGVYFdzOKoQLKknOni");//替换为您的密钥

/**
 * 直接获取翻译结果
 * @param unknown $query
 * @param unknown $from
 * @param unknown $to
 */
function translatebaidunew1($query, $from, $to){
    
    
    if( empty($query) )
        return "";
    
    
    $args = array(
        'q' => $query,
        'appid' => APP_ID,
        'salt' => rand(10000,99999),
        'from' => $from,
        'to' => $to,

    );
    
    $args['sign'] = buildSign($query, APP_ID, $args['salt'], SEC_KEY);
    $ret = call(URL, $args);
    $ret = json_decode($ret, true);
    
    $result = ""; 
    foreach ( $ret['trans_result'] as $item ){
        
        $dst = $item['dst'];
        //print_r($dst);
        $result = $result." ".$dst;
    }
    
    return $result;
}

//翻译入口
function translatebaidunew($query, $from, $to)
{
    $args = array(
        'q' => $query,
        'appid' => APP_ID,
        'salt' => rand(10000,99999),
        'from' => $from,
        'to' => $to,

    );
    $args['sign'] = buildSign($query, APP_ID, $args['salt'], SEC_KEY);
    $ret = call(URL, $args);
    $ret = json_decode($ret, true);
    //print_r($ret);
    return $ret['trans_result']; 
}

//加密
function buildSign($query, $appID, $salt, $secKey)
{/*{{{*/
    $str = $appID . $query . $salt . $secKey;
    $ret = md5($str);
    return $ret;
}/*}}}*/

//发起网络请求
function call($url, $args=null, $method="post", $testflag = 0, $timeout = CURL_TIMEOUT, $headers=array())
{/*{{{*/
    $ret = false;
    $i = 0; 
    while($ret === false) 
    {
        if($i > 1)
            break;
        if($i > 0) 
        {
            sleep(1);
        }
        $ret = callOnce($url, $args, $method, false, $timeout, $headers);
        $i++;
    }
    return $ret;
}/*}}}*/

function callOnce($url, $args=null, $method="post", $withCookie = false, $timeout = CURL_TIMEOUT, $headers=array())
{/*{{{*/
    $ch = curl_init();
    if($method == "post") 
    {
        $data = convert($args);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_POST, 1);
    }
    else 
    {
        $data = convert($args);
        if($data) 
        {
            if(stripos($url, "?") > 0) 
            {
                $url .= "&$data";
            }
            else 
            {
                $url .= "?$data";
            }
        }
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    if(!empty($headers)) 
    {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    if($withCookie)
    {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $_COOKIE);
    }
    $r = curl_exec($ch);
    curl_close($ch);
    return $r;
}/*}}}*/

function convert(&$args)
{/*{{{*/
    $data = '';
    if (is_array($args))
    {
        foreach ($args as $key=>$val)
        {
            if (is_array($val))
            {
                foreach ($val as $k=>$v)
                {
                    $data .= $key.'['.$k.']='.rawurlencode($v).'&';
                }
            }
            else
            {
                $data .="$key=".rawurlencode($val)."&";
            }
        }
        return trim($data, "&");
    }
    return $args;
}/*}}}*/


?>