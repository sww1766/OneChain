<?php
require_once (REALPATH.'/config/Init.inc.php');

class CheckPermition {
	
	function __construct() {
	
	}
	
	/**
	 * 权限校验
	 *
	 * @return unknown
	 */
	function baseJudgeAdminUserLogin(){
        
		//echo "dddddddddd";
		$RTR =& load_class('Router');
		$method = $RTR->fetch_method();
		$fetchclass =  $RTR->fetch_class();
		//echo $RTR->fetch_method();
		
		$_REQUEST['PAGE_SLTY'] = 'METRONIC';
		$_REQUEST['langeager'] = array('','_en','_x','_x1','_x2','_x3');
		
		$nocheck = array('m','manager','admin','metronic','inspinia','metronic5','main','upload');
		
		if(  in_array($fetchclass,$nocheck) ){
			 return '';
		}else{
			$member = $_SESSION['adminuser'];
			
		    if($member != '')
		    {
		        return true;
		    }
		    else
		    {
		       header("Location:".HTTP_DOCMENT_ROOT."/index.php/manager/relogin");
		       //return '';
		    }
		}
		  
		/**/
	}
	
	
}

?>