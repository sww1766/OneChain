<?php

class Commonhook{
	
	
	
	function initUrlParm(){
		
		 echo "这是一个钩子函数";
	   	 $_GET['testid'] = '1324132';
	}
	
}

?>