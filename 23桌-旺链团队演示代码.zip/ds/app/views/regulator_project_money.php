<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
        <head>
            <meta charset="utf-8" />
            <title><?php echo $cself->getLang('筹资方入口--(指旺科技-区块链众筹平台)');?></title>
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1" name="viewport" />
            <meta content="" name="description" />
            <meta content="" name="author" />
            <!-- BEGIN GLOBAL MANDATORY STYLES -->
            <link	href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/font-awesome/css/font-awesome.min.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/simple-line-icons/simple-line-icons.min.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/css/bootstrap.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/css/uniform.default.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.css"	rel="stylesheet" type="text/css" />
            <!-- END GLOBAL MANDATORY STYLES -->
            <!-- BEGIN THEME GLOBAL STYLES -->
            <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/components.css"	rel="stylesheet" id="style_components" type="text/css" />
            <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/plugins.min.css"	rel="stylesheet" type="text/css" />
            <!-- END THEME GLOBAL STYLES -->
            <!-- BEGIN THEME LAYOUT STYLES -->
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/layout.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/themes/default.css"	rel="stylesheet" type="text/css" id="style_color" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/custom.min.css"	rel="stylesheet" type="text/css" />

            <!-- END THEME LAYOUT STYLES -->
            <link rel="shortcut icon" href="<?php echo SOURCE_ROOT;?>/img/favicon.ico" />
        </head>
<!-- END HEAD -->

<body class="<?php echo PAGE_BODY_CLASS; ?>">
	<!-- BEGIN HEADER -->
      
        <!-- END HEADER -->
	<!-- BEGIN HEADER & CONTENT DIVIDER -->
	<div class="clearfix"></div>
	<!-- END HEADER & CONTENT DIVIDER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container">
		<!-- BEGIN SIDEBAR -->
            
            <!-- END SIDEBAR -->
		<!-- BEGIN CONTENT -->
		<div class="page-content-wrapper">
			<!-- BEGIN CONTENT BODY -->
			<div class="page-content">
			
				<!-- BEGIN PAGE HEAD-->             
				
			        <div class="row">
                        <div class="col-md-6">
                            <div class="portlet light portlet-fit bordered">
                                <div class="portlet-title">
                                    <div class="caption">
                                       <i class="fa fa-list fa-fw font-dark" aria-hidden="true"></i>
                                    <span class="caption-subject bold uppercase"><?php echo $cself->getLang('项目生命周期');?></span>
                                        
                                    </div>
                                    
                                </div>
                                <div class="portlet-body">
                                    <div class="timeline">
                                        <!-- TIMELINE ITEM -->
                                       
                                        <?php  if( !empty($cf_project_funddetails) ) for ( $ind = count($cf_project_funddetails)-1 ; $ind>0;$ind-- ){
                                        
                                            $item = $cf_project_funddetails[$ind];
                                            
                                            ?>
                                        
                                        <div class="timeline-item">
                                            <div class="timeline-badge">
                                                <img class="timeline-badge-userpic" src="<?php echo SOURCE_ROOT;?>/assets/pages/media/users/avatar80_1.jpg"> </div>
                                            <div class="timeline-body">
                                                <div class="timeline-body-arrow"> </div>
                                                <div class="timeline-body-head">
                                                    <div class="timeline-body-head-caption">
                                                        <a href="javascript:;" class="timeline-body-title font-blue-madison"><?php echo  base64_decode( $item['use_pople'] );?></a>
                                                        <span class="timeline-body-time font-grey-cascade"><?php echo $item['createdt'];?></span>
                                                        <!-- 
                                                        <span class="timeline-body-time font-purple-studio"><?php echo $item['use_nums'];?></span>
                                                         -->
                                                        <span class="timeline-body-time font-purple-studio"><?php echo base64_decode( $item['use_action'] );?></span>
                                                        <?php if( !empty( $item['bills'])  && $item['bills'] != 1  ){ ?>
                                                        <?php if( $_SESSION['usertype'] == '3' ){ ?>
                                                        <a class="btn blue-madison btn-xs" style="margin-right: 2px;" href="javascript:checkiamge('<?php echo $item['orgid']; ?>','<?php echo $item['bills_abstract'];?>');"><?php echo $cself->getLang('校验');?></a>
                                                        <?php }} ?>
                                                    </div>
                                                    
                                                </div>
                                                <div class="timeline-body-content">
                                                   
                                                    <span class="font-grey-cascade">
                                                    <p>
                                                    <?php echo  base64_decode( $item['use_desc']);?>
                                                    </p>
                                                    <?php if(  !empty($item['bills']) && $item['bills'] != 1 ){?>
                                                    <p>
                                                       <img class="timeline-body-img pull-left" src="<?php echo HTTP_DOCMENT_ROOT;?>/uploads/cmp/<?php echo $item['bills'];?>" alt="">                                                           
                                                    <p>
                                                    <?php } ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <?php }?>
                                        <!-- END TIMELINE ITEM -->                          
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>




				<!-- END PAGE BASE CONTENT -->
			</div>
			<!-- END CONTENT BODY -->
		</div>
		<!-- END CONTENT -->
		<!-- BEGIN QUICK SIDEBAR -->


		<!-- END QUICK SIDEBAR -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
        
      
        
        <!-- END FOOTER -->
	<!--[if lt IE 9]>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/respond.min.js"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/excanvas.min.js"></script> 
        <![endif]-->
	<!-- BEGIN CORE PLUGINS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/js/bootstrap.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/js.cookie.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.blockui.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/jquery.uniform.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js"	type="text/javascript"></script>
	<!-- END CORE PLUGINS -->
	<!-- BEGIN THEME GLOBAL SCRIPTS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/scripts/app.min.js" type="text/javascript"></script>
	<!-- END THEME GLOBAL SCRIPTS -->
	<!-- BEGIN THEME LAYOUT SCRIPTS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/layout.min.js" type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/demo.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/global/scripts/quick-sidebar.min.js"	type="text/javascript"></script>
	<!-- END THEME LAYOUT SCRIPTS -->
	
</body>

<script type="text/javascript">

function checkiamge( projectid,imagehash_org ){

	$.ajax({
		 
	     url: '<?php echo APP_WEB_INDEX_ROOT;?>/main/ajax_checkimage?itemid=' + projectid ,
	     type: 'GET',
	     dataType: 'html',	    
	     error: function(e){/*获取失败*/
		 		alert('<?php echo $cself->getLang('请求失败');?>');
	     },
	     success: function(data){/*获取成功*/

			 
	    	 var myObject = eval('(' + data + ')');		
	    	 var image = myObject.image;
	    	 var imagehash = myObject.imagehash;

	    	 if( imagehash_org == imagehash ){
	    		 alert("<?php echo $cself->getLang('数据没有被篡改');?>");
		     }else{
		    	 alert("<?php echo $cself->getLang('数据被篡改了！！！！！！！！！！');?>");
			 } 	 
	    	 	    	 
	     }
	 });	
	


	
}

</script>



</html>