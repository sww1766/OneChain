<div class="page-sidebar-wrapper">
                <!-- BEGIN SIDEBAR -->
               
                <div class="page-sidebar navbar-collapse collapse">
                   
                    <ul class="page-sidebar-menu   " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                        
                        <li class="heading">
                            <h3 class="uppercase"></h3>
                        </li>
                        <li class="nav-item <?php echo $nav_base_action_open; ?>">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-diamond"></i>
                                <span class="title"></span>
                              
                            </a>
                            
                        </li>
                        <li class="nav-item  <?php echo $nav_project_action_open; ?>">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-puzzle"></i>
                                <span class="title"></span>
                               
                            </a>
                            
                        </li>
                        
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
            </div>