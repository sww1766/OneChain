<div class="page-sidebar-wrapper">
                <!-- BEGIN SIDEBAR -->
               
                <div class="page-sidebar navbar-collapse collapse">
                   
                    <ul class="page-sidebar-menu   " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
                        
                        <li class="heading">
                            <h3 class="uppercase"><?php echo $cself->getLang('监管人平台');?></h3>
                        </li>
                        
                        <li class="nav-item  <?php echo $nav_project_action_open; ?>">
                            <a href="javascript:;" class="nav-link nav-toggle">
                                <i class="icon-puzzle"></i>
                                <span class="title"><?php echo $cself->getLang('项目管理');?></span>
                                <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item <?php echo $nav_project_base_action_open; ?> ">
                                    <a href="<?php echo APP_WEB_INDEX_ROOT;?>/main/regulator_index" class="nav-link ">
                                        <span class="title"><?php echo $cself->getLang('项目概况');?></span>
                                    </a>
                                </li>                                
                            </ul>
                        </li>               
                        
                    </ul>
                    <!-- END SIDEBAR MENU -->
                </div>
                <!-- END SIDEBAR -->
            </div>