<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
        <head>
            <meta charset="utf-8" />
            <title><?php echo $cself->getLang('筹资方入口--(指旺科技-区块链众筹平台)');?></title>
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1" name="viewport" />
            <meta content="" name="description" />
            <meta content="" name="author" />
            <!-- BEGIN GLOBAL MANDATORY STYLES -->
            <link	href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/font-awesome/css/font-awesome.min.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/simple-line-icons/simple-line-icons.min.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/css/bootstrap.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/css/uniform.default.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.css"	rel="stylesheet" type="text/css" />
            <!-- END GLOBAL MANDATORY STYLES -->
            <!-- BEGIN THEME GLOBAL STYLES -->
            <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/components.css"	rel="stylesheet" id="style_components" type="text/css" />
            <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/plugins.min.css"	rel="stylesheet" type="text/css" />
            <!-- END THEME GLOBAL STYLES -->
            <!-- BEGIN THEME LAYOUT STYLES -->
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/layout.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/themes/default.css"	rel="stylesheet" type="text/css" id="style_color" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/custom.min.css"	rel="stylesheet" type="text/css" />            
            
	        <link href="<?php echo SOURCE_ROOT;?>/jqupload/uploadify.css" rel="stylesheet" type="text/css" >
            
            <link rel="stylesheet" href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-ui/jquery-ui-self.min.css">
            <!-- END THEME LAYOUT STYLES -->
            <link rel="shortcut icon" href="<?php echo SOURCE_ROOT;?>/img/favicon.ico" />
            
                    
        </head>

<!-- END HEAD -->

<body class="<?php echo PAGE_BODY_CLASS; ?>">
	
	<div class="clearfix"></div>
	
	<div class="page-container">
		
		<div class="page-content-wrapper">
			
			<div class="page-content">
			
			
				
                <div class="row">
                    <form id="frmDemo"  name="frmDemo" method="post"  action="<?php echo APP_WEB_INDEX_ROOT;?>/main/financing_project_used_save" class="form-horizontal">
					<input name="id" id="id" value="<?php echo $cf_project_funddetails['id'];?>" type="hidden">  
                    <input name="bills" id="bills" value="<?php echo $cf_project_funddetails['bills'];?>" type="hidden">  
                    <input name="bills_abstract" id="bills_abstract" value="<?php echo $cf_project_funddetails['bills_abstract'];?>" type="hidden">  
                    <input name="project_id" id="project_id" value="<?php echo $_GET['proid'] ;?>" type="hidden">  
					<!-- BEGIN SAMPLE TABLE PORTLET-->
					<div class="portlet light bordered">
						<div class="portlet-title">
							<div class="caption font-dark">
								<i class="icon-settings font-dark"></i> 
								<span class="caption-subject bold uppercase"><?php echo $cself->getLang('新增资金使用情况');?></span>
							</div>
							<div class="actions">
								<div class="btn-group btn-group-devided" >
									<button type="submit" class="btn blue-madison"><?php echo $cself->getLang('保存');?></button>									
									<a href="<?php echo APP_WEB_INDEX_ROOT;?>/main/manager_project_money" class="btn default">
                                                                           <?php echo $cself->getLang('返回');?>
                                    </a>
								</div>
							</div>
						</div>

						<div class="portlet-body form">
							<!-- BEGIN FORM-->
							

								<div class="form-body">

<div class="form-group">
	<label class="col-md-3 control-label"><?php echo $cself->getLang('资金使用人');?></label>
	<div class="col-md-6">
		<input type="text" class="form-control" name="use_pople" id="use_pople" value="<?php echo $cf_project_funddetails['use_pople'];?>"> 
	</div>
</div>
<div class="form-group">
	<label class="col-md-3 control-label"><?php echo $cself->getLang('资金使用金额');?></label>
	<div class="col-md-6">
		<input type="text" class="form-control" name="use_nums" id="use_nums" value="<?php echo $cf_project_funddetails['use_nums'];?>"> 
	</div>
</div>
<div class="form-group">
	<label class="col-md-3 control-label"><?php echo $cself->getLang('资金使用时间');?></label>
	<div class="col-md-6">
		<input type="text" class="form-control" name="use_dt" id="use_dt" value="<?php echo $cf_project_funddetails['use_dt'];?>"> 
	</div>
</div>

<div class="form-group ">
          <label class="control-label col-md-3"><?php echo $cself->getLang('票据');?></label>
          <div class="col-md-9">
            <div class="fileinput fileinput-new" data-provides="fileinput">
                <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 150px;">
                 <img id = "mappic_file_upload_pic" name="mappic_file_upload_pic" width="180" height="240" src="<?php echo HTTP_DOCMENT_ROOT;?>/uploads/cmp/<?php echo $cf_project_funddetails['bills'];?>">
                 </div>
                <div>                
                        <input id="mappic_file_upload" name="mappic_file_upload" type="file" multiple="true">       
                </div>
            </div>
            <div class="clearfix margin-top-10">
                <span class="label label-success"><?php echo $cself->getLang('提示：');?></span><?php echo $cself->getLang('图片大小不要超过2M');?> 
            </div>
           </div>
</div>

<div class="form-group">
	<label class="col-md-3 control-label"><?php echo $cself->getLang('资金使用说明');?></label>
	<div class="col-md-6">
		
		<textarea class="form-control" rows="3"  name="use_desc" id="use_desc" ><?php echo $cf_project_funddetails['use_desc'];?></textarea>
	</div>
</div>

<div class="form-group">
	<label class="col-md-3 control-label"><?php echo $cself->getLang('备注');?></label>
	<div class="col-md-6">
		<input type="text" class="form-control" name="remark" id="remark" value="<?php echo $cf_project_funddetails['remark'];?>"> 
	</div>
</div>
</div>
<div class="form-actions right">
	
	<button type="submit" class="btn blue-madison"><?php echo $cself->getLang('保存');?></button>
	<a href="<?php echo APP_WEB_INDEX_ROOT;?>/main/manager_project_money" class="btn default">
                                           <?php echo $cself->getLang('返回');?>
    </a>
	
</div>
							
							<!-- END FORM-->
						</div>


					</div>
					<!-- END SAMPLE TABLE PORTLET-->
                    </form>
				</div>
			




				<!-- END PAGE BASE CONTENT -->
			</div>
			<!-- END CONTENT BODY -->
		</div>
		<!-- END CONTENT -->
		<!-- BEGIN QUICK SIDEBAR -->


		<!-- END QUICK SIDEBAR -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
        
      
        
        <!-- END FOOTER -->
	<!--[if lt IE 9]>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/respond.min.js"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/excanvas.min.js"></script> 
        <![endif]-->
	<!-- BEGIN CORE PLUGINS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/js/bootstrap.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/js.cookie.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.blockui.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/jquery.uniform.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js"	type="text/javascript"></script>
	<!-- END CORE PLUGINS -->
	<!-- BEGIN THEME GLOBAL SCRIPTS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/scripts/app.min.js" type="text/javascript"></script>
	<!-- END THEME GLOBAL SCRIPTS -->
	<!-- BEGIN THEME LAYOUT SCRIPTS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/layout.min.js" type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/demo.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/global/scripts/quick-sidebar.min.js"	type="text/javascript"></script>
	<!-- END THEME LAYOUT SCRIPTS -->
	
	<script type="text/javascript" src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-ui/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-ui/jquery-ui-zhcn.js"></script>
    <script src="<?php echo SOURCE_ROOT;?>/jqupload/jquery.uploadify.min.js" type="text/javascript"></script>    
    

</body>
 <script type="text/javascript"> 
           
           
$(function(){
	
	$("#use_dt").datepicker({
		 changeMonth: true,
	      changeYear: true,
	      dateFormat:'yy-mm-dd'
		});

	$("#use_dt").dblclick(function (){ 
		$('#use_dt').attr('value','');
	}); 
	
});


<?php $timestamp = time();?>
$(function() {

	$('#mappic_file_upload').uploadify({
		
		'formData'     : {
			'timestamp' : '<?php echo $timestamp;?>',
			'token'     : '<?php echo md5('unique_salt' . $timestamp);?>'
		},

		'swf'      : '<?php echo SOURCE_ROOT;?>/jqupload/uploadify.swf',
		'uploader' : '<?php echo APP_WEB_INDEX_ROOT;?>/upload/uploadpic?secd=leader&mod=1&id=<?php echo $cmp_leader['id']; ?>',
		'onUploadSuccess' : function(file, data, response) {

            //alert('The file ' + file.name + ' was successfully uploaded with a response of ' + response + ':' + data);
			var myObject = eval('(' + data + ')');  
			var imagehash = myObject.imagehash;
			var filename1 = myObject.imagename;
			
			
			picpath = '<?php echo HTTP_DOCMENT_ROOT;?>/uploads/cmp/'+myObject.imagename;
			
			//picpath = '<?php echo HTTP_DOCMENT_ROOT;?>/uploads/leader/'+data;
			//alert(picpath);

            $('#mappic_file_upload_pic').attr('src',picpath);
            $('#bills').attr('value',filename1);
            $('#bills_abstract').attr('value',imagehash);
            

         }
	});
});




</script>
</html>