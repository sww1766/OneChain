<div class="clearfix navbar-fixed-top">
    <!-- Brand and toggle get grouped for better mobile display -->
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="toggle-icon">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </span>
    </button>
    <!-- End Toggle Button -->
    <!-- BEGIN LOGO -->
    <a id="index" class="page-logo" href="index.html">
        <img src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout5/img/logo.png" alt="Logo"> </a>
    <!-- END LOGO -->
    <!-- BEGIN SEARCH -->
    <form class="search" action="extra_search.html" method="GET">
        <input type="name" class="form-control" name="query" placeholder="Search...">
        <a href="javascript:;" class="btn submit md-skip">
            <i class="fa fa-search"></i>
        </a>
    </form>
    <!-- END SEARCH -->
    <!-- BEGIN TOPBAR ACTIONS -->
    <div class="topbar-actions">
        <!-- BEGIN GROUP NOTIFICATION -->
        <div class="btn-group-notification btn-group" id="header_notification_bar">
            <button type="button" class="btn btn-sm md-skip dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                <i class="icon-bell"></i>
                <span class="badge">7</span>
            </button>
            
        </div>
        <!-- END GROUP NOTIFICATION -->
        <!-- BEGIN GROUP INFORMATION -->
        <div class="btn-group-red btn-group">
            <button type="button" class="btn btn-sm md-skip dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                <i class="fa fa-plus"></i>
            </button>
            
        </div>
        <!-- END GROUP INFORMATION -->
        <!-- BEGIN USER PROFILE -->
        <div class="btn-group-img btn-group">
            <button type="button" class="btn btn-sm md-skip dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                <span>Hi, Marcus</span>
                <img src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout5/img/avatar1.jpg" alt=""> </button>
            
        </div>
        <!-- END USER PROFILE -->
        <!-- BEGIN QUICK SIDEBAR TOGGLER -->
        <button type="button" class="quick-sidebar-toggler md-skip" data-toggle="collapse">
            <span class="sr-only">Toggle Quick Sidebar</span>
            <i class="icon-logout"></i>
        </button>
        <!-- END QUICK SIDEBAR TOGGLER -->
    </div>
    <!-- END TOPBAR ACTIONS -->
</div>