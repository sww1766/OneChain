<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
        <title><?php echo $cself->getLang('指旺科技');?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN LAYOUT FIRST STYLES 
        <link href="//fonts.googleapis.com/css?family=Oswald:400,300,700" rel="stylesheet" type="text/css" />
        -->
        <!-- END LAYOUT FIRST STYLES -->
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout5/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout5/css/custom.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="<?php echo SOURCE_ROOT;?>/img/favicon.ico" /> </head>
    <!-- END HEAD -->

    <body class="page-header-fixed page-sidebar-closed-hide-logo">
        <!-- BEGIN CONTAINER -->
        <div class="wrapper">
            <!-- BEGIN HEADER -->
            <header class="page-header">
                <nav class="navbar mega-menu" role="navigation">
                    <div class="container-fluid">
                        <?php require_once 'nav_head.php';   ?>
                        <!-- BEGIN HEADER MENU -->
                        <?php require_once 'nav_head_menu.php';?>
                        <!-- END HEADER MENU -->
                    </div>
                    <!--/container-->
                </nav>
            </header>
            <!-- END HEADER -->
            <div class="container-fluid">
                <div class="page-content">
                    <!-- BEGIN BREADCRUMBS -->
                    
                    <!-- END BREADCRUMBS -->
                    <!-- BEGIN SIDEBAR CONTENT LAYOUT -->
                    <div class="page-content-container">
                        <div class="page-content-row">
                            <!-- BEGIN PAGE SIDEBAR -->
                            <?php require_once 'nav_left_menu.php'; ?>
                            <!-- END PAGE SIDEBAR -->
                            <div class="page-content-col">
                                <!-- BEGIN PAGE BASE CONTENT -->
                                <div class="row">
                        
                            <!-- BEGIN SAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                    <i class="fa fa-list fa-fw font-dark" aria-hidden="true"></i>
                                    <span class="caption-subject bold uppercase">管理员列表</span>
                                </div>
                                    
                                </div>
    
                                <form role="form"> 
   <div class="row"> 
    <div class="col-xs-6 col-sm-4 col-md-3"> 
     <div class="form-group"> 
      <label for="dateRangePicker" class="control-label">日期范围</label> 
      <div class="input-group input-daterange" id="dateRangePicker"> 
       <input type="text" class="input-sm form-control" id="startDate" name="start" readonly="" placeholder="起始日期" /> 
       <div class="input-group-addon">
        至
       </div> 
       <input type="text" class="input-sm form-control" id="endDate" name="end" readonly="" placeholder="截止日期" /> 
      </div> 
      <!-- /.input group --> 
     </div> 
    </div> 
    <div class="col-xs-6 col-sm-4 col-md-3"> 
     <div class="form-group"> 
      <label for="condition1" class="control-label">查询条件</label> 
      <div class="input-group"> 
       <div class="input-group-addon"> 
        <i class="fa fa-ticket fa-fw"></i> 
       </div> 
       <input type="text" class="input-sm form-control" id="condition1" placeholder="查询条件" /> 
      </div> 
      <!-- /.input group --> 
     </div> 
    </div> 
    <div class="col-xs-6 col-sm-4 col-md-3"> 
     <div class="form-group"> 
      <label for="condition2" class="control-label">查询条件</label> 
      <div class="input-group"> 
       <div class="input-group-addon"> 
        <i class="fa fa-tty fa-fw"></i> 
       </div> 
       <input type="text" class="input-sm form-control" id="condition2" placeholder="查询条件" /> 
      </div> 
      <!-- /.input group --> 
     </div> 
    </div> 
    <div class="col-xs-6 col-sm-4 col-md-3"> 
     <div class="form-group"> 
      <label for="condition3" class="control-label">查询条件</label> 
      <div class="input-group"> 
       <div class="input-group-addon"> 
        <i class="fa fa-cubes fa-fw"></i> 
       </div> 
       <input type="text" class="input-sm form-control" id="condition3" placeholder="查询条件" /> 
      </div> 
      <!-- /.input group --> 
     </div> 
    </div> 
    <div class="col-xs-6 col-sm-4 col-md-3"> 
     <div class="form-group"> 
      <label for="condition4" class="control-label">查询条件</label> 
      <div class="input-group"> 
       <div class="input-group-addon"> 
        <i class="fa fa-briefcase fa-fw"></i> 
       </div> 
       <input type="text" class="input-sm form-control" id="condition4" placeholder="查询条件" /> 
      </div> 
      <!-- /.input group --> 
     </div> 
    </div> 
    
    
    
    <div class="col-xs-12 col-sm-10 col-sm-offset-2 col-md-10 col-md-offset-2"> 
     <div class="pull-right"> 
      <button type="button" class="btn blue-madison" onclick=""><i class="fa fa-search fa-fw" aria-hidden="true"></i>查询</button> 
      <button type="button" class="btn btn-default" onclick=""><i class="fa fa-refresh fa-fw" aria-hidden="true"></i>重置</button> 
     </div> 
    </div> 
   </div> 


                                <div class="portlet-body">
                                     <div class="row">
                                     <div class="col-md-5">
                                    <div class="actions">
                                        <a href="javascript:;" class="btn blue-madison">
                                                    添加
                                        </a>
                                        <a href="javascript:;" class="btn blue-madison">
                                                    添加
                                        </a>
                                        <a href="javascript:;" class="btn blue-madison">
                                                    添加
                                        </a>
                                    </div>
                                     </div>
                                     <div class="col-md-7" >
                                                        <div id='Pagination' style='float:right; clear:none;' class="pull-right pagination-panel">        <script language='Javascript'>
        
        function setSelect(obj) {
            
            var array = document.getElementsByName('_RecPerPage');
            
            for (var i = 0; i < array.length; i++) {
            
                array[i].value = obj.value;
               
            }
        }
        
        function setText(obj)
        
        {
            var array = document.getElementsByName('_PageID');
            for (var i = 0; i < array.length; i++) {
                array[i].value = obj.value;
            }
        }
        
        function submitPage(mode)
        {
            PageTotal     = parseInt(document.getElementById('_PageTotal').value);
            if(mode == 'changePageID')
            {
                PageID        =  document.getElementById('_PageID').value;
                if(PageID > PageTotal)
                {
                    PageID = PageTotal;
                }
                else if(PageID < 1)
                {
                    PageID = 1;
                }
            }
            else if(mode == 'changeRecPerPage')
            {
                PageID = 0;
            }
            RecPerPage    = document.getElementById('_RecPerPage').value;
            //alert(RecPerPage);
            location.href = 'http://mail.china-haiyi.net/p/cmp_product?clm=id&ordertype=DESC&s=eyJzMSI6IiIsInMyIjoiIn0=&RecTotal=68&PageID=' + PageID + '&RecPerPage=' + RecPerPage;
        }
        </script>记录总数:<strong>68</strong>&nbsp;
  <select name='_RecPerPage' id='_RecPerPage' onchange='setSelect(this);submitPage("changeRecPerPage");' class="form-control input-xs input-sm input-inline" >
<option value='10'>10</option>
<option value='20' selected='selected'>20</option>
<option value='35'>35</option>
<option value='50'>50</option>
<option value='100'>100</option>
</select>
项条页&nbsp;页码:<strong>1</strong>/<strong>4</strong>&nbsp;首页上一页<a href='#'>下一页</A><a href='#'>尾页</A><input type='hidden' id='_PageTotal' value='4' />
                        <input type='text'   id='_PageID'    value='1' style='text-align:center;width:30px;' class="pagination-panel-input form-control input-sm input-inline input-mini" />
                        <input type='button' id='goto'       value='打开' onclick='submitPage("changePageID");' /></div>  
                                     </div>

                                     </div>
                                    <div class="table-scrollable">
                                        <table class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th> # </th>
                                                    <th> First Name </th>
                                                    <th> Last Name </th>
                                                    <th> Username </th>
                                                    <th> Status </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td> 1 </td>
                                                    <td> Mark </td>
                                                    <td> Otto </td>
                                                    <td> makr124 </td>
                                                    <td>
                                                        <span class="label label-sm label-success"> Approved </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 2 </td>
                                                    <td> Jacob </td>
                                                    <td> Nilson </td>
                                                    <td> jac123 </td>
                                                    <td>
                                                        <span class="label label-sm label-info"> Pending </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 3 </td>
                                                    <td> Larry </td>
                                                    <td> Cooper </td>
                                                    <td> lar </td>
                                                    <td>
                                                        <span class="label label-sm label-warning"> Suspended </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 4 </td>
                                                    <td> Sandy </td>
                                                    <td> Lim </td>
                                                    <td> sanlim </td>
                                                    <td>
                                                        <span class="label label-sm label-danger"> Blocked </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- END SAMPLE TABLE PORTLET-->
                        
                    </div>
                    
                                
                                
                                
                                
                                <!-- END PAGE BASE CONTENT -->
                            </div>
                        </div>
                    </div>
                    <!-- END SIDEBAR CONTENT LAYOUT -->
                </div>
                <!-- BEGIN FOOTER -->
                <?php require_once 'nav_foot.php';?>
                <!-- END FOOTER -->
            </div>
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN QUICK SIDEBAR -->
        <a href="javascript:;" class="page-quick-sidebar-toggler">
            <i class="icon-login"></i>
        </a>
        
        <!-- END QUICK SIDEBAR -->
        <!--[if lt IE 9]>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/respond.min.js"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/excanvas.min.js"></script> 
        <![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout5/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
    </body>

</html>