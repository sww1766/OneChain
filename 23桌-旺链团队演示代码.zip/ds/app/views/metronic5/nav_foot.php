<p class="copyright">2017 © 赢立方.
    <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" title="Purchase Metronic just for 27$ and get lifetime updates for free" target="_blank">Purchase Metronic!</a>
</p>
<a href="#index" class="go2top">
    <i class="icon-arrow-up"></i>
</a>