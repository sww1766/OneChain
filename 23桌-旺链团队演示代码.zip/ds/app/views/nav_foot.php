<div class="page-footer">
    <div class="page-footer-inner"> 2019 &copy; <?php echo $cself->getLang('上海旺链信息科技有限公司');?>
        <a href="#" title="旺链" target="_blank">旺链</a>
    </div>
    <div class="scroll-to-top">
        <i class="icon-arrow-up"></i>
    </div>
</div>