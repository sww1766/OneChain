<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo $cself->getLang('指旺科技');?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" /> 
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/css/uniform.default.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/clockface/css/clockface.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/components.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <link href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/layout.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/themes/default.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/custom.min.css" rel="stylesheet" type="text/css" />
        
        <link rel="stylesheet" href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-ui/jquery-ui-self.min.css">
       
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> 
        
       
       
        
        </head>
    <!-- END HEAD -->

    <body class="<?php echo PAGE_BODY_CLASS; ?>">
        <!-- BEGIN HEADER -->
       <?php require_once PC_VIEW_SOURCE_BASE.'/nav_head.php';?>
        <!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
        <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
            <!-- BEGIN SIDEBAR -->
            <?php require_once PC_VIEW_SOURCE_BASE.'/nav_left_menu.php';?>
            <!-- END SIDEBAR -->
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEAD-->
                     <!-- BEGIN PAGE HEAD-->
                    <div class="page-head">
                        <!-- BEGIN PAGE TITLE -->
                        <div class="page-title">
                            <h1>系统管理员 </h1>
                        </div>
                        <!-- END PAGE TITLE -->
                        <!-- BEGIN PAGE TOOLBAR -->
                        
                        <!-- END PAGE TOOLBAR -->
                    </div>
                    <!-- END PAGE HEAD-->
                    <!-- BEGIN PAGE BREADCRUMB -->
                    
                    <!-- END PAGE BREADCRUMB -->
                    <!-- BEGIN PAGE BASE CONTENT -->
                    <div class="row">
                        
                            <!-- BEGIN SAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                    <i class="fa fa-list fa-fw font-dark" aria-hidden="true"></i>
                                    <span class="caption-subject bold uppercase">管理员列表</span>
                                    </div>                                    
                                    <div class="actions">
								         <a href="<?php echo APP_WEB_INDEX_ROOT;?>/main/index_add" class="btn blue-madison">添加 </a>                                  
							        </div>     
                                </div>

                                <div class="portlet-body">
                                     <div class="row">
                                     <div class="col-md-3">
                                    <div class="actions">                              
                                    </div>
                                     </div>
                                     <div class="col-md-9" >
                                              <?php echo $PaginationHtml;?>
                                     </div>

                                     </div>
                                    <div class="table-scrollable">
                                        <table class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th width="20%"> # </th>
                                                    <th width="20%"> First Name </th>
                                                    <th width="20%"> Last Name </th>
                                                    <th width="25%"> Username </th>
                                                    <th width="15%"> Status </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td> 1 </td>
                                                    <td> Mark </td>
                                                    <td> Otto </td>
                                                    <td> makr124 </td>
                                                    <td>
                                                         <a href="#" class="btn blue-madison btn-sm" style="margin-right: 2px;"><?php echo $cself->getLang('编辑');?></a>
                                                       <a href="#" class="btn blue-madison btn-sm" style="margin-right: 2px;">><?php echo $cself->getLang('删除');?><</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 2 </td>
                                                    <td> Jacob </td>
                                                    <td> Nilson </td>
                                                    <td> jac123 </td>
                                                    <td>
                                                        <span class="label label-sm label-info"> Pending </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 3 </td>
                                                    <td> Larry </td>
                                                    <td> Cooper </td>
                                                    <td> lar </td>
                                                    <td>
                                                        <span class="label label-sm label-warning"> Suspended </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 4 </td>
                                                    <td> Sandy </td>
                                                    <td> Lim </td>
                                                    <td> sanlim </td>
                                                    <td>
                                                        <span class="label label-sm label-danger"> Blocked </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END SAMPLE TABLE PORTLET-->
                        
                    </div>
                    
                    <div class="row">
                        
                            <!-- BEGIN SAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                    <i class="fa fa-list fa-fw font-dark" aria-hidden="true"></i>
                                    <span class="caption-subject bold uppercase">管理员列表</span>
                                    </div>                                    
                                    <div class="actions">
								         <a href="<?php echo APP_WEB_INDEX_ROOT;?>/main/index_add" class="btn blue-madison">添加 </a>                                  
							        </div>     
                                </div>

                                <div class="portlet-body">
                                     <div class="row">
                                     <div class="col-md-3">
                                    <div class="actions">                              
                                    </div>
                                     </div>
                                     <div class="col-md-9" >
                                              <?php echo $PaginationHtml;?>
                                     </div>

                                     </div>
                                    <div class="table-scrollable">
                                        <table class="table table-striped table-bordered table-hover">
                                            <thead>
                                                <tr>
                                                    <th width="20%"> # </th>
                                                    <th width="20%"> First Name </th>
                                                    <th width="20%"> Last Name </th>
                                                    <th width="25%"> Username </th>
                                                    <th width="15%"> Status </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td> 1 </td>
                                                    <td> Mark </td>
                                                    <td> Otto </td>
                                                    <td> makr124 </td>
                                                    <td>
                                                         <a href="#" class="btn blue-madison btn-sm" style="margin-right: 2px;"><?php echo $cself->getLang('编辑');?></a>
                                                       <a href="#" class="btn blue-madison btn-sm" style="margin-right: 2px;">><?php echo $cself->getLang('删除');?><</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 2 </td>
                                                    <td> Jacob </td>
                                                    <td> Nilson </td>
                                                    <td> jac123 </td>
                                                    <td>
                                                        <span class="label label-sm label-info"> Pending </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 3 </td>
                                                    <td> Larry </td>
                                                    <td> Cooper </td>
                                                    <td> lar </td>
                                                    <td>
                                                        <span class="label label-sm label-warning"> Suspended </span>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td> 4 </td>
                                                    <td> Sandy </td>
                                                    <td> Lim </td>
                                                    <td> sanlim </td>
                                                    <td>
                                                        <span class="label label-sm label-danger"> Blocked </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END SAMPLE TABLE PORTLET-->
                        
                    </div>
                    
                    <!-- END PAGE BASE CONTENT -->
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->
           
            
            <!-- END QUICK SIDEBAR -->
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        
        <?php require_once PC_VIEW_SOURCE_BASE.'/nav_foot.php';?>
        
        <!-- END FOOTER -->
        <!--[if lt IE 9]>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/respond.min.js"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/excanvas.min.js"></script> 
        <![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        
        
        
        <script type="text/javascript" src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-ui/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-ui/jquery-ui-zhcn.js"></script>
        
        <!-- END THEME LAYOUT SCRIPTS -->
           <script type="text/javascript"> 
           
           
$(function(){
	
	$("#startDate").datepicker({
		 changeMonth: true,
	      changeYear: true,
	      dateFormat:'yy-mm-dd'
		});

	$("#startDate").dblclick(function (){ 
		$('#startDate').attr('value','');
	}); 


	$("#endDate").datepicker({
		 changeMonth: true,
	      changeYear: true,
	      dateFormat:'yy-mm-dd'
		});

	$("#endDate").dblclick(function (){ 
		$('#endDate').attr('value','');
	}); 
	

	


	
	
});


</script>
    </body>

</html>