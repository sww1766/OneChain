<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<!--<![endif]-->
<!-- BEGIN HEAD -->
        <head>
            <meta charset="utf-8" />
            <title><?php echo $cself->getLang('筹资方入口--(指旺科技-区块链众筹平台)');?></title>
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1" name="viewport" />
            <meta content="" name="description" />
            <meta content="" name="author" />
            <!-- BEGIN GLOBAL MANDATORY STYLES -->
            <link	href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&subset=all"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/font-awesome/css/font-awesome.min.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/simple-line-icons/simple-line-icons.min.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/css/bootstrap.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/css/uniform.default.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/css/bootstrap-switch.css"	rel="stylesheet" type="text/css" />
            <!-- END GLOBAL MANDATORY STYLES -->
            <!-- BEGIN THEME GLOBAL STYLES -->
            <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/components.css"	rel="stylesheet" id="style_components" type="text/css" />
            <link href="<?php echo SOURCE_ROOT;?>/assets/global/css/plugins.min.css"	rel="stylesheet" type="text/css" />
            <!-- END THEME GLOBAL STYLES -->
            <!-- BEGIN THEME LAYOUT STYLES -->
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/layout.css"	rel="stylesheet" type="text/css" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/themes/default.css"	rel="stylesheet" type="text/css" id="style_color" />
            <link	href="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/css/custom.min.css"	rel="stylesheet" type="text/css" />

            <!-- END THEME LAYOUT STYLES -->
            <link rel="shortcut icon" href="<?php echo SOURCE_ROOT;?>/img/favicon.ico" />
        </head>
<!-- END HEAD -->

<body class="<?php echo PAGE_BODY_CLASS; ?>">
	<!-- BEGIN HEADER -->
      
        <!-- END HEADER -->
	<!-- BEGIN HEADER & CONTENT DIVIDER -->
	<div class="clearfix"></div>
	<!-- END HEADER & CONTENT DIVIDER -->
	<!-- BEGIN CONTAINER -->
	<div class="page-container">
		<!-- BEGIN SIDEBAR -->
            
            <!-- END SIDEBAR -->
		<!-- BEGIN CONTENT -->
		<div class="page-content-wrapper">
			<!-- BEGIN CONTENT BODY -->
			<div class="page-content">
			
				<!-- BEGIN PAGE HEAD-->             
				
			        <div class="row">
                        <div class="col-md-6">
                            <div class="portlet light portlet-fit bordered">
                                <div class="portlet-title">
                                    <div class="caption">
                                       <i class="fa fa-list fa-fw font-dark" aria-hidden="true"></i>
                                    <span class="caption-subject bold uppercase">资金使用情况</span>
                                        
                                    </div>
                                    <div class="actions">
                                        <a href="<?php echo APP_WEB_INDEX_ROOT;?>/main/financing_project_used_add" class="btn blue-madison"><?php echo $cself->getLang('新增资金使用情况');?></a>
                                    </div>
                                </div>
                                <div class="portlet-body">
                                    <div class="timeline">
                                        <!-- TIMELINE ITEM -->
                                        <div class="timeline-item">
                                            <div class="timeline-badge">
                                                <img class="timeline-badge-userpic" src="<?php echo SOURCE_ROOT;?>/assets/pages/media/users/avatar80_1.jpg"> </div>
                                            <div class="timeline-body">
                                                <div class="timeline-body-arrow"> </div>
                                                <div class="timeline-body-head">
                                                    <div class="timeline-body-head-caption">
                                                        <a href="javascript:;" class="timeline-body-title font-blue-madison">小李</a>
                                                        <span class="timeline-body-time font-grey-cascade">2017年3月7日16:16:51</span>
                                                        <span class="timeline-body-time font-purple-studio">8600</span>
                                                    </div>
                                                    
                                                </div>
                                                <div class="timeline-body-content">
                                                    <span class="font-grey-cascade">购买种子和化肥</span>
                                                    <p>
                                                       <img class="timeline-body-img pull-left" src="<?php echo SOURCE_ROOT;?>/img/pj.jpg" alt="">                                                           
                                                   <p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END TIMELINE ITEM -->
                                        <!-- TIMELINE ITEM -->
                                        <div class="timeline-item">
                                            <div class="timeline-badge">
                                                <img class="timeline-badge-userpic" src="<?php echo SOURCE_ROOT;?>/assets/pages/media/users/avatar80_2.jpg"> </div>
                                            <div class="timeline-body">
                                                <div class="timeline-body-arrow"> </div>
                                                <div class="timeline-body-head">
                                                    <div class="timeline-body-head-caption">
                                                        <a href="javascript:;" class="timeline-body-title font-blue-madison">大李</a>
                                                        <span class="timeline-body-time font-grey-cascade">2017年2月9日16:21:09</span>
                                                         <span class="timeline-body-time font-purple-studio">19300</span>
                                                    </div>
                                                    <div class="timeline-body-head-actions"> </div>
                                                </div>
                                                <div class="timeline-body-content">
                                                    <span class="font-grey-cascade">土地出让金</span>
                                                    <p>
                                                       <img class="timeline-body-img pull-left" src="<?php echo SOURCE_ROOT;?>/img/pj.jpg" alt="">                                                           
                                                   <p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END TIMELINE ITEM -->
                                      
                                        <!-- TIMELINE ITEM -->
                                        <div class="timeline-item">
                                            <div class="timeline-badge">
                                                <img class="timeline-badge-userpic" src="<?php echo SOURCE_ROOT;?>/assets/pages/media/users/avatar80_1.jpg"> </div>
                                            <div class="timeline-body">
                                                <div class="timeline-body-arrow"> </div>
                                                <div class="timeline-body-head">
                                                    <div class="timeline-body-head-caption">
                                                        <a href="javascript:;" class="timeline-body-title font-blue-madison">小王</a>
                                                        <span class="timeline-body-time font-grey-cascade">2017年1月7日16:26:21</span>
                                                    </div>
                                                    <div class="timeline-body-head-actions"> </div>
                                                </div>
                                                <div class="timeline-body-content">
                                                    <span class="font-grey-cascade">土地出让金</span>
                                                    <p>
                                                       <img class="timeline-body-img pull-left" src="<?php echo SOURCE_ROOT;?>/img/pj.jpg" alt="">                                                           
                                                   <p>
                                                </div>
                                            </div>
                                        </div>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>




				<!-- END PAGE BASE CONTENT -->
			</div>
			<!-- END CONTENT BODY -->
		</div>
		<!-- END CONTENT -->
		<!-- BEGIN QUICK SIDEBAR -->


		<!-- END QUICK SIDEBAR -->
	</div>
	<!-- END CONTAINER -->
	<!-- BEGIN FOOTER -->
        
      
        
        <!-- END FOOTER -->
	<!--[if lt IE 9]>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/respond.min.js"></script>
        <script src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/excanvas.min.js"></script> 
        <![endif]-->
	<!-- BEGIN CORE PLUGINS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap/js/bootstrap.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/js.cookie.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/jquery.blockui.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/uniform/jquery.uniform.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js"	type="text/javascript"></script>
	<!-- END CORE PLUGINS -->
	<!-- BEGIN THEME GLOBAL SCRIPTS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/global/scripts/app.min.js" type="text/javascript"></script>
	<!-- END THEME GLOBAL SCRIPTS -->
	<!-- BEGIN THEME LAYOUT SCRIPTS -->
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/layout.min.js" type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/layout4/scripts/demo.min.js"	type="text/javascript"></script>
	<script	src="<?php echo SOURCE_ROOT;?>/assets/layouts/global/scripts/quick-sidebar.min.js"	type="text/javascript"></script>
	<!-- END THEME LAYOUT SCRIPTS -->
	
    

</body>

</html>