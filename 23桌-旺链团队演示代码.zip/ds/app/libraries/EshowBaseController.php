<?php

require_once ('system/commonself/BaseController4CI.php');

class EshowBaseController extends BaseController4CI {
	
	public function __construct() {
		parent::__construct ();
	}
	
	function get2MenuFlag($flag){
		
		if( $flag == 'active' )
			return "im-checkbox-checked";
		else
			return  "en-arrow-right7";
	}
	
	
	function getLangCimt($lanfld){
	
	   return "英语";
	
	}
	
	
	
	
	private $langss = array(
	                            
	    
	            '0c5f1ebeb74690c2c64f4be876a77bad'=>array('cn'=>'分红','en'=>''),
	            'e417db6a0b4cde8e7e1c97dd76f32535'=>array('cn'=>'项目列表','en'=>'Project List'),
                
	           
	            'a4aefdee73d59b8a0827b51928d8e0d3'=>array('cn'=>'认筹完成','en'=>'Confessed to Raise'),
                '69e7f9aea24aa7b3f2d24f508401529c'=>array('cn'=>'项目生命周期','en'=>'Project Life Cycle'),
                '690ca805e85b22d9dfe3f404a2f14385'=>array('cn'=>'同意拨款','en'=>'Agree on the Appropriation'),
               //正在翻译中
        	    '95b351c86267f3aedf89520959bce689'=>array('cn'=>'编辑','en'=>'Edit'),
        	    '2f4aaddde33c9b93c36fd2503f3d122b'=>array('cn'=>'删除','en'=>'Delete'),
        	    '7a712b9a4574166830b69a07ce78056e'=>array('cn'=>'批准','en'=>'Approve'),
        	    '20786031c997c8a4fc11ecd42718c9dc'=>array('cn'=>'放款完成','en'=>'Complete the Loan'),
        	    '0c5f1ebeb74690c2c64f4be876a77bad'=>array('cn'=>'分红','en'=>'Bonus'),
        	    '97a81dbd411fdc693cb469849557e2f7'=>array('cn'=>'未审核','en'=>'Unvalidated'),
        	    '9d5b9bd50c3e84f9f6aa0e5279b8e2ef'=>array('cn'=>'已审核','en'=>'Validated'),
        	    '1ea2067eadf7eb03c058d97cf240cf90'=>array('cn'=>'已认筹','en'=>'Confessed to Raise'),
        	    '20786031c997c8a4fc11ecd42718c9dc'=>array('cn'=>'放款完成','en'=>'Complete the Loan'),
        	    '9a497fb064e36b2e4541b94d680e144d'=>array('cn'=>'完成分红','en'=>'Complete the Bonus'),
              'f7064ef263b30c23d53416a66a42d3d5'=>array('cn'=>'已经认筹金额','en'=>'Amount of Confessed to Raise'),
        	    '2432b57515b3627faddccb1dd1df206e'=>array('cn'=>'备注','en'=>' Remark'),
        	    '0bb551673c78c208c55939a11b61aa09'=>array('cn'=>'投资金额','en'=>'Investment Amount'),
        	    '6fefcab5ae8611621c5148ec46ea07a3'=>array('cn'=>'管理方入口--(指旺科技-区块链众筹平台)','en'=>'Manager Entrance--(Zhiwang Technology  Co.,Ltd-BlockChain Crowdfunding Platform)'),
        	    '1bac76d2a5d7f24550233c7a8be76966'=>array('cn'=>'上海旺链信息科技有限公司','en'=>'Shanghai Onechain Information Technology  Co.,Ltd.'),
        	    'b1dae9bc5cabbc13e4bee21af11cdb8d'=>array('cn'=>'管理员','en'=>'Administrator'),
        	    '4beb49cc189b07803a046af72d64c64a'=>array('cn'=>'管理平台','en'=>'Management Platform'),
        	    '436367b06614c1bec6efcd0971a16ef2'=>array('cn'=>'项目管理','en'=>'Project Management'),
        	    '0650ae6564fc24c6269f54a3d96755bc'=>array('cn'=>'项目概况','en'=>'Project Overview'),
        	    'abca93e3383a35c1deeecf4cfe997252'=>array('cn'=>'众筹平台-平台管理方入口','en'=>'Crowdfunding Platform - Platform Manager Entrance'),
        	    '738a41f965541d6f16d2064f82e148f3'=>array('cn'=>'项目名称','en'=>'Project Name'),
        	    'bf6c8450fac2d1ae99e570b8a61cbb41'=>array('cn'=>'项目发起人','en'=>'Project Initiator'),
        	    '1f6728fdf032d969eb6d6c0a8f676cd4'=>array('cn'=>'投资人','en'=>'Backer'),
        	    'e4b619aa7e29f359eba79833c6485d13'=>array('cn'=>'项目资金','en'=>'Project Fund'),
        	    '074be4f3b2b293e2b884fc026b93d926'=>array('cn'=>'项目内容','en'=>'Project Content'),
        	    '3fea7ca76cdece641436d7ab0d02ab1b'=>array('cn'=>'状态','en'=>'State'),
        	    '2b6bc0f293f5ca01b006206c2535ccbc'=>array('cn'=>'操作','en'=>'Operate'),
        	    '267a65ad28a0fe64293f5e9e4a926873'=>array('cn'=>'筹资方入口--(指旺科技-区块链众筹平台)','en'=>'Fund-raising Party Entrance-(Zhiwang Technology  Co.,Ltd-BlockChain Crowdfunding Platform)'),
        	    '2432b57515b3627faddccb1dd1df206e'=>array('cn'=>'备注','en'=>'Remark'),
        	    '1641c2bc45fefdd9c9062f5e103ccff7'=>array('cn'=>'新增资金使用情况','en'=>'the new fund using condition'),
        	    'a4d367f959062ebaeb5a0396bf7c7af1'=>array('cn'=>'筹资人','en'=>'Project Creator'),
        	    'c59b606bb7d3227ab7ab571783cd5560'=>array('cn'=>'众筹平台-筹资方管理入口','en'=>'Crowdfunding Platform - Fund-raising Party Management Entrance'),
        	    '6fd16f9bac9ec1093777532575e376c5'=>array('cn'=>'筹资项目列表','en'=>'Fund-raising Project List'),
        	    '277e8cde882d5256418c29089ce69a00'=>array('cn'=>'已经认筹','en'=>'Confessed to Raise'),
        	    'db39f32e6afbe4c6dcf87a6c1ec52d5f'=>array('cn'=>'费用明细','en'=>'Details of Charges'),
        	    '6674fa89e8c3f74e60d0d748152d9eab'=>array('cn'=>'项目信息','en'=>'Project Information'),
        	    'd2b93f7b94613df6ad9c4a5383af9b27'=>array('cn'=>'项目动态','en'=>'Project State'),
        	    '25b61f867f3bdb1263861ab52ae943bf'=>array('cn'=>'筹资方入口--\(指旺科技-区块链众筹平台','en'=>'Fund-raising Party Entrance-(Zhiwang Technology  Co.,Ltd-BlockChain Crowdfunding Platform)'),
        	    'dde7c5d90a9b1b0ffcbf4a5a69a956ca'=>array('cn'=>'新增/编辑众筹项目','en'=>'Add/Edit Fund-raising Project'),
        	    'be5fbbe34ce9979bfb6576d9eddc5612'=>array('cn'=>'保存','en'=>'Save'),
        	    '5f411223ca5a01a5adf20fe735a433d0'=>array('cn'=>'返回','en'=>'Back'),
        	    '07c765f58cb78d013b863ade6402f7a1'=>array('cn'=>'资金使用人','en'=>'Fund User'),
        	    '4671f90427e169042df3e1688ec2bc57'=>array('cn'=>'资金使用金额','en'=>'Fund-using Amount'),
        	    '7241736d73226a58fb65dba0dfbc4d81'=>array('cn'=>'资金使用时间','en'=>'Fund-using Time'),
        	    'f2a2749e8068237c602919a55d8aca0e'=>array('cn'=>'票据','en'=>'Bill'),
        	    '390a4d9af6ec6b6916abd174419b03fa'=>array('cn'=>'提示：','en'=>'Tips'),
        	    '22cfef12624a54b6c5310caf33149aea'=>array('cn'=>'图片大小不要超过2M','en'=>'ImageSize limited(not over 2M)'),
        	    'fca3923415d248d78847ef229abed0c0'=>array('cn'=>'资金使用说明','en'=>'Fund-using Clarification'),
        	    '7b3ded7369168f5689a45e7bb07a9966'=>array('cn'=>'指旺众筹区块链平台','en'=>'Zhiwang BlockChain Crowdfunding Platform'),
        	    '455110bbcc594bc3265aa59169261407'=>array('cn'=>'众筹平台演示系统','en'=>'Crowdfunding Platform Show System'),
        	    'f90499cf5969879c0543a378083a47c6'=>array('cn'=>'众筹平台','en'=>'Platform'),
        	    'f4ca4236523e0fb17b6f51ea70ec670c'=>array('cn'=>'平台运营者','en'=>'Platform Operate'),
        	    '2f2735856de8c9a048d8c8625916e13a'=>array('cn'=>'负责众筹平台的运营，包括项目审核和资金的清算和结算','en'=>''),
        	    '166c60cc2b72402e1fe09c4df7e71f66'=>array('cn'=>'总项目数','en'=>'Amounts of Project'),
        	    '2a5a7221426f94014017f38cec98083f'=>array('cn'=>'项目发起者，有自己使用需求的人','en'=>'Project Owner'),
        	    '8f04fc1b5e462100ddb440d5f57b1e04'=>array('cn'=>'申请项目 ','en'=>'Apply for the Project'),
        	    '28ff0285cad5f7982fbc02c9d10a1533'=>array('cn'=>'对项目发起投资的人','en'=>'The Project Raiser'),
        	    '088dca9a3a3d37f21f3309a5fdfe61d6'=>array('cn'=>'已经投资项目','en'=>''),
        	    '88022df4c8321361111dabf9cd192527'=>array('cn'=>'监管人','en'=>'Supervisor'),
        	    '6d3bc5f03d426a3ed9bf5df9d9d0af5e'=>array('cn'=>'对项目和资金使用情况进行监管的人','en'=>'the Superintendent of Project and fund-using'),
        	    '4d8c539e35137c3a88c519ee675cb1c2'=>array('cn'=>'监管项目','en'=>'supervise the project'),
        	    'd870b641a13e5a255fd6106d4910f17d'=>array('cn'=>'投资方入口--(指旺科技-区块链众筹平台)','en'=>''),
        	    '7afabf7f4c42db379356e6aa17a484e6'=>array('cn'=>'待投资项目','en'=>'project of being raising'),
        	    '25d7c9cb187e8564129d8774c7d3e51e'=>array('cn'=>'我投资的项目','en'=>'My raising project'),
        	    '0a00ec22a014be18c5b8bd8146d37f6c'=>array('cn'=>'众筹平台-投资方管理入口','en'=>''),
        	    'aa61b4864526468308498979c7126c77'=>array('cn'=>'参与投资的项目列表','en'=>' participating raised project list'),
        	    'fbc6e50f8909c30d68408da594aed1d1'=>array('cn'=>'监管人员','en'=>'supervisor'),
        	    '2e78b09f4694703efd286e27490797c0'=>array('cn'=>'监管方入口--(指旺科技-区块链众筹平台)','en'=>''),
        	    'e692ed594a1f9b78453b655196a040b3'=>array('cn'=>'监管人平台','en'=>'supervisor platform'),
        	    '0bf4be25c6fc0c833a0e4127846d0433'=>array('cn'=>'众筹平台-监管方入口','en'=>'Crowdfunding Platform-Superintendent Entrance'),
        	    'b22a6cdf244682076c61d580abf7304d'=>array('cn'=>'监管项目列表','en'=>'supervise the project list '),
        	    '69e7f9aea24aa7b3f2d24f508401529c'=>array('cn'=>'项目生命周期','en'=>'project life cycle'),
        	    'b7579706a363e5f23b1040fecfbcb677'=>array('cn'=>'校验','en'=>'Checkout'),
        	    'f50bf418323ee425eca7208c09a4577e'=>array('cn'=>'请求失败','en'=>'Request failed'),
        	    'b3c053b0bcf99def7ce638c88cfb1700'=>array('cn'=>'数据没有被篡改','en'=>'Data is not been tampered'),
        	    'b11cdfe8f78f9cf5cc4b87c2fadafb83'=>array('cn'=>'数据被篡改了！！！！！！！！！！','en'=>'Data has been tampered')
	                           
	    
    	                       );
	
	
	
	
	
	function getLang($chinaess){
	    
	   /*  $map = $_SESSION['langmap'];
	    if( empty($map) )
	        $map = array();
	    
	    $map[$chinaess] = "1";
	    
	    $_SESSION['langmap'] = $map; */
	    
	    return $this->langss[md5($chinaess)]['en'];
	    
	}
	
	
	/**
	 * 页面合成
	 *
	 */
	function  regView($view , $data)
	{
		//$_REQUEST['cleinttype'] = 'phone';  $this->load->view('phone/'.$view,$data);
		//$string = $this->load->view('myfile', '', true);
		$data['cself'] = $this;
		$this->load->view( $view,$data);
	}
	
	/**
	 * 页面合成
	 *
	 */
	function  regView1($view , $data)
	{
		//$_REQUEST['cleinttype'] = 'phone';  $this->load->view('phone/'.$view,$data);
		//$string = $this->load->view('myfile', '', true);
		$data['title_seo'] = '鼎用科技-企业级移互数字互动营销专家—APP/微信定制公司|APP制作|微信开发|Android开发|IOS开发|WP开发|Google Glass程序开发|二维码营销|APP/微信联合运营';
		$data['alt'] = '微信定制公司|APP制作|微信开发|Android开发|IOS开发|WP开发|Google Glass程序开发|二维码营销|APP/微信联合运营';
		$data['cself'] = $this;
		$this->load->view( 'pcnew/'.$view,$data);
	}
	
	
		/**
	 * 
	 * 根据文件名获取文件的路径
	 *
	 * @param unknown_type $imagename
	 * @param unknown_type $fix
	 * @return unknown
	 * 
	 * 
	 */
	function getImage($imagename,$fix){		
		
		global $_CFG;
		$imagrog = $_CFG['SOURCE_ROOT'];
		$imagename = getMutilFileName($imagename);
		$imagename_dfs   = substr ( $imagename, 0 ,strrpos ( $imagename, '.' ) );
		//echo $dfdf;
		$imageurls =  base64_decode($imagename_dfs);
		
		$imageurls_rel = $imagrog.$imageurls.$fix;
		
		return $imageurls_rel;
		
		
	}
	
	 
	function formevaluechage($company , $htmlitem){
		
		$langarr = $_REQUEST['langeager'];					   
		$company_save = array();
		foreach ( $langarr as $lan ){
			
			foreach ( $company as $key => $value){
				
				$key_a = $key.$lan;
				
				if( in_array( $key,$htmlitem )  )
					//$company_save[$key_a] = stripslashes( $_POST[$key_a]);
					$company_save[$key_a] =  $_POST[$key_a];
				else 
					$company_save[$key_a] = $_POST[$key_a];
			}
			
			
		}
		
		return $company_save;
	}
	
	
	
	function getProUrl($proid){
		$cmp_id =  $_SESSION['usermember']['cmp_id'];
		$cmp_id_de = base64_encode(encrypt($cmp_id,'eshwap'));
		$pro_id_de =  base64_encode(encrypt($proid,'eshow'));
		global $_CFG;
		$wapurl =  $_CFG['WAP_ROOT_PRO']."c=$cmp_id_de".'&'."p=$pro_id_de";
		return $wapurl;
	}
	
	
}

?>