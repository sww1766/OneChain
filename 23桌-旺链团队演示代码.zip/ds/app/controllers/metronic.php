<?php

require_once ('app/libraries/EshowBaseController.php');

class metronic extends EshowBaseController{

    
    public function __construct(){
        parent::__construct();
    }
    
    
    /**
     * 登录
     * */
    function login(){
       
        $this->regView('metronic/login',$data);
    
    }
    
    
    /**
     * 首页 
     */
    function index(){
        
            $Pagination = new Page('hg_purchaser', 200 , '' , '', " $where ", APP_WEB_INDEX_ROOT."/main/index?id=$id&s=$searchparmsss", '');
            $data['PaginationHtml'] = $Pagination->show('right');
            $data['pagesearchUrl'] = $Pagination->getSearchUrl();
            $this->regView('manager/nav',$data);
        
    }
    
   
    
    /**
     * 首页 
     * 
     */
    function index_main(){
    
        $Pagination = new Page('hg_purchaser', 200000000 , '' , '', " $where ", APP_WEB_INDEX_ROOT."/main/index_main?id=$id&s=$searchparmsss", '');
        
        $data['PaginationHtml'] = $Pagination->show('right');
        $data['pagesearchUrl'] = $Pagination->getSearchUrl();
        
        $data['nav_base_action_open'] = " start active open";
        $data['nav_base_cmp_action_open'] = " start active open";
        
        $this->regView('metronic/index',$data);
         
    
    }
    
    
    /**
     * 首页
     *
     */
    function index_main1(){
    
        $Pagination = new Page('hg_purchaser', 200000000 , '' , '', " $where ", APP_WEB_INDEX_ROOT."/main/index_main?id=$id&s=$searchparmsss", '');
        $data['PaginationHtml'] = $Pagination->show('right');
        $data['pagesearchUrl'] = $Pagination->getSearchUrl();
        $this->regView('metronic/index_1',$data);
         
    
    }
    
    
    /**
     * 首页
     *
     */
    function index_1(){
    
        $Pagination = new Page('hg_purchaser', 200000000 , '' , '', " $where ", APP_WEB_INDEX_ROOT."/main/index_main?id=$id&s=$searchparmsss", '');
        $data['PaginationHtml'] = $Pagination->show('right');
        $data['pagesearchUrl'] = $Pagination->getSearchUrl();
        $this->regView('metronic/index_bak1',$data);
         
    
    }
    
    
    /**
     * 首页
     *
     */
    function index_sample(){
    
        $Pagination = new Page('hg_purchaser', 200000000 , '' , '', " $where ", APP_WEB_INDEX_ROOT."/main/index_main?id=$id&s=$searchparmsss", '');
        $data['PaginationHtml'] = $Pagination->show('right');
        $data['pagesearchUrl'] = $Pagination->getSearchUrl();
        $this->regView('metronic/index_sample',$data);
         
    
    }
 
    
    
    /**
     * 
     */
    function index_add(){
    
        $this->regView('metronic/index_add',$data);
    
    }
    
    
    /**
     *
     */
    function index_add_sample(){
    
        $this->regView('metronic/index_add_sample',$data);
    
    }
    
    /**
     *  首页 
     **/
    function index1(){
    
    
        $this->regView('metronic/index1',$data);
         
    
    }
    
    
    
}

?>