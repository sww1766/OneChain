<?php

require_once ('app/libraries/EshowBaseController.php');
require_once 'include/YlfCommon.php';


class main extends EshowBaseController{
    
    private $http_post = "http://192.168.23.69:8080/write_get";
    private $http_get = "http://192.168.23.69:8080/queryFund";
    
    public function __construct(){
        
        parent::__construct();
        
    }
    
    

    
    
    function md5(){
    
         $chinaess = "分红";
         $chinaess_md5 = md5($chinaess);
         echo "'$chinaess_md5'=>array('cn'=>'$chinaess','en'=>''),";
         
    }
    
    
    function printmap(){
        
         
        foreach ( $_SESSION['langmap'] as $key=>$value ){
            
             $key1 = md5($key);
            echo " '$key1'=>array('cn'=>'$key','en'=>''),"."<br/>";
            
        }
        
         
        
    }
    
    /**
     * 
     */
    function index(){
        $this->regView( 'index' , $data );
    }
 
    
    //====================================== 管理平台 ==================================
    
    function manager_index(){
        
        
        $_SESSION['userid'] = '1';
        $_SESSION['usertype'] = '0';
        $_SESSION['username'] = '平台管理员'; 
        
        $sql = "select * from cf_project ";
        $dao = new CommonDao4sSelf('','','','');
        
        $Pagination = new Page('cf_project', '', '' , '', " ", APP_WEB_INDEX_ROOT."/main/financing_index", $dao->getMyDB());
        $cmp_news = $dao->getRowsBySQl($sql,'',$Pagination->LimitNum(),'');
        
        $data['cf_projects'] = $cmp_news;
        $data['PaginationHtml'] = $Pagination->show('right');
       
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView( 'manager_index' , $data );
    }
    
    
    
    function manager_project_detail(){
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView( 'manager_project_detail' , $data );
        
    }
    
    
    
    function manager_project_money(){
        
        
        $sql = " select * from cf_project_funddetails order by id desc ";
        $dao = new CommonDao4sSelf('','','','');
        
       
        $cmp_news = $dao->getRowsBySQl($sql,'','','');
        
        
        $data['cf_project_funddetails'] = $cmp_news;
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView( 'manager_project_money' , $data );
        
        
    }
    
    
    /**
     * 验证
     */
    function manager_project_succes(){
        
        $id = $_GET['id'];
        $dao = new CommonDao4sSelf('','','','');
        $sql = " update cf_project set statss = 1 where id = $id ";
        $dao->updateBySql($sql,'');
         
        $this->save_funddetails_opt($id, '管理员', "管理平台<?php echo $this->getLang('已经审核');?>项目");
        
        
        $this->manager_index();
        
        
    }
    
    /**
     * 放款
     */
    function manager_project_pay(){
    
        $id = $_GET['id'];
        $dao = new CommonDao4sSelf('','','','');
        $sql = " update cf_project set statss = 3 where id = $id ";
        $dao->updateBySql($sql,'');
         
        $this->save_funddetails_opt($id, '管理员', "项目已经完成放款");    
        $this->manager_index();    
    
    }
    
    
    /**
     * 分红
     */
    function manager_project_profit(){
    
        $id = $_GET['id'];
        $dao = new CommonDao4sSelf('','','','');
        $sql = " update cf_project set statss = 4 where id = $id ";
        $dao->updateBySql($sql,'');
         
        $this->save_funddetails_money( $id , '管理员', 1 , 1000 , '投资平台已经完成分红' );
    
        $this->manager_index();
    
    }
    
    
    /**
     * 
     */
    function manager_project_agree(){
    
        $id = $_GET['id'];
        $dao = new CommonDao4sSelf('','','','');
        $sql = " update cf_project_funddetails set checkflag = 1 where id = $id ";
        $dao->updateBySql($sql,'');
         
        $this->save_funddetails_money( $id , '管理员', 1 , 1000 , '同意用款申请',array('orgid'=>$id) );
    
        $this->manager_project_money();
    
    }
    
    
    //======================================= <?php echo $this->getLang('筹资人') ======================================
    
    function financing_index(){        
        
        
        $_SESSION['userid'] = '2';
        $_SESSION['usertype'] = '1';
        $_SESSION['username'] = $this->getLang('筹资人');
        
        
        $sql = "select * from cf_project ";
        $dao = new CommonDao4sSelf('','','','');
        
        $Pagination = new Page('cf_project', '', '' , '', " ", APP_WEB_INDEX_ROOT."/main/financing_index", $dao->getMyDB());
        $cmp_news = $dao->getRowsBySQl($sql,'',$Pagination->LimitNum(),'');
        
        $data['cf_projects'] = $cmp_news;
        $data['PaginationHtml'] = $Pagination->show('right');
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        
        $this->regView('financing_index',$data);
        
    }
    
    

    function financing_cf_project_add(){
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView('financing_add',$data);
    }
    
    
    function financing_cf_project_edit(){
    
        $id = $_GET['id'];
        $dao = new CommonDao4sSelf('','','','');
    
        $cmp_id =  $_SESSION['usermember']['cmp_id'];
        $sql = " select * from cf_project where id = $id ";
        $cmp_news = $dao->getRowByPkOne($sql,'');
    
      
    
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        
        $data['cf_project'] = $cmp_news;
       
        $this->regView('financing_add',$data);
        
        
    }
    
    
    
    /**
     * 
     * 新增项目
     * 
     */
    function financing_cf_project_save(){
    
        $cf_project = array(
                             
                            'financing_id'=>$_SESSION['userid'],
                            'investor_id'=>$_POST['investor_id'],
                            'name'=>$_POST['name'],
                            'pics'=>$_POST['pics'],
                            'contents'=>$_POST['contents'],
                            'remark'=>$_POST['remark']
    
                           );
    
       
    
        $id = $_POST['id'];
        $dao = new CommonDao4sSelf('','','','');
    
        if( $id == '' ){
            	
            $cf_project['createdt'] = 'now()';
            $cf_project['modifydt']='now()';
            $dao->saveRow('cf_project' , $cf_project,'');
            	
            	
        }else{
            $cf_project['modifydt']='now()';
            $dao->updateRowByPk('cf_project',$cf_project,'id',$id,'');
            	
        }
        	
        $this->financing_index();
    }
    
    
    function financing_cf_project_del(){
    
        $id = $_GET['id'];
        $cmp_id =  $_SESSION['usermember']['cmp_id'];
    
        $sql  = 'delete from cf_project where id =  '.$id  ;
        $dao = new CommonDao4sSelf('','','','');
        $dao->updateBySql($sql,'');
    
        $this->financing_index();
    
    
    }
    
    
    
    function financing_from(){
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView('financing_from',$data);
    }
    
    
    function financing_money_used(){
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView('financing_money_used',$data);
        
    }
    
    
    
    /**
     * 认筹
     */
    function investor_add(){
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView('investor_add',$data);
        
    }
    
    
    
    function  investor_save(){
        
        $cf_project_financing = array(
                                       
                                        'project_id'=>$_POST['project_id'],
                                        'fundraiser_id'=>$_POST['fundraiser_id'],
                                        'investor_id'=>$_SESSION['userid'],
                                        'moneys'=>$_POST['moneys'],
                                        'remark'=>$_POST['remark']
                                      );
        
         
        
        $id = $_POST['id'];
        $dao = new CommonDao4sSelf('','','','');
        
        if( $id == '' ){
             
            $cf_project['createdt'] = 'now()';
            $cf_project['modifydt']='now()';
            $dao->saveRow('cf_project_financing' , $cf_project_financing,'');
             
             
        }else{
            $cf_project['modifydt']='now()';
            $dao->updateRowByPk('cf_project_financing',$cf_project_financing,'id',$id,'');
             
        }
        
        
        
        //提交日志
        $this->save_funddetails_money($_POST['project_id'], '投资人'.":".$_SESSION['username'], 1, $_POST['moneys'] , $this->getLang('投资人投资:').$_POST['moneys']);
        
        
        
        //判断状态
        
        $projectid = $_POST['project_id'];
        $project = $dao->getRowByPk('cf_project', '', 'id', $projectid,'');
        $pics = $project['pics'];
        
        $sql = " select sum(moneys) as moneys from cf_project_financing  where project_id = $projectid ";
        $sql_arr = $dao->getRowsBySQl($sql,'','','');
        $money = $sql_arr[0]['moneys'];
        
        $tz = $_POST['moneys'];
        if( empty($tz) )
               $tz = 0;
        
        if( $pics ==  $money ){
            
            $sql_up = " update cf_project set  statss = 2  where id = $projectid ";
            $dao->updateBySql($sql_up);
        }
        
        $sql_up1 = " update cf_project set rcje = rcje+$tz where id = $projectid ";
        echo $sql_up1;
        $dao->updateBySql($sql_up1);
        
         
        $this->investor_nav();
        
    }
    
    
    
    
    
    
    /**
     * 
     * <?php echo $this->getLang('新增资金使用情况');?>
     * 
     */
    function financing_project_used_add(){
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView('financing_project_used_add',$data);
    }
    
    

    /**
     * <?php echo $this->getLang('新增资金使用情况');?>
     */
    function financing_project_used_save(){
    
    
       $cf_project_funddetails = array(                                        
                                        'project_id'=>$_POST['project_id'],
                                        'fundraiser_id'=>$_POST['fundraiser_id'],
                                        'opt_type'=>0,
                                        'use_pople'=>$_POST['use_pople'],
                                        'use_type'=>2,
                                        'use_action'=>"申请资金：".$_POST['use_nums'],
                                        'use_nums'=>$_POST['use_nums'],
                                        'use_desc'=>$_POST['use_desc'],
                                        'use_dt'=>$_POST['use_dt'],
                                        'bills'=>$_POST['bills'],
                                        'bills_abstract'=>$_POST['bills_abstract'],                                       
                                        'remark'=>$_POST['remark']    
                                     );
        
    
        $id = $_POST['id'];
        $dao = new CommonDao4sSelf('','','','');
    
        if( $id == '' ){
            	
            $cf_project_funddetails['createdt'] = 'now()';
            $cf_project_funddetails['modifydt']='now()';
            $id = $dao->saveRow('cf_project_funddetails' , $cf_project_funddetails,'');
            
            
            $cf_project_funddetails_bc = array(
                'id'=>$id,
                'project_id'=>$_POST['project_id'],
                'use_pople'=>base64_encode($_POST['use_pople']),
                'use_type'=>'0',
                'use_action'=>base64_encode("申请资金：".$_POST['use_nums']),
                'use_nums'=>'0',
                'use_dt'=>date('Y-m-d H:i:s'),
                'fundraiser_id'=>'1',
                'use_desc'=>base64_encode($_POST['use_desc']),
                'bills'=>$_POST['bills'],
                'bills_abstract'=>$_POST['bills_abstract'],
                'createdt'=>'1',
                'modifydt'=>'1',
                'orgid'=>$id
            );
            
            
            /*          $ylf = new YlfCommon();
                        //$content = $ylf->curl_post("$this->http_post", $cf_project_funddetails_bc,'');
                        $content = $ylf->curl_get( $this->http_post."?str=".base64_encode(json_encode($cf_project_funddetails_bc)));
             */           
            
            $ylf = new YlfCommon();
            $parms = array('senddata'=>base64_encode(json_encode($cf_project_funddetails_bc)),'id'=>$id);
            $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_post", $parms);
            
            
            //echo $content;
            	
        }else{
            
            $cf_project_funddetails['modifydt']='now()';
            $dao->updateRowByPk('cf_project_funddetails',$cf_project_funddetails,'id',$id,'');
            	
        }
        	
        
        $this->manager_project_money();
        
    }
    
    
    
    //======================================= <?php echo $this->getLang('投资人'); ======================================
    
    function investor_index(){
        
        if( !empty($_GET['userid']) )
            $_SESSION['userid'] = $_GET['userid'];
        
        $_SESSION['usertype'] = '2';
        $_SESSION['username'] = '投资人'.$_SESSION['userid'];
        
        
        $sql = "select * from cf_project where statss = 1 ";
        $dao = new CommonDao4sSelf('','','','');
        
        $Pagination = new Page('cf_project', '', '' , '', " ", APP_WEB_INDEX_ROOT."/main/financing_index", $dao->getMyDB());
        $cmp_news = $dao->getRowsBySQl($sql,'',$Pagination->LimitNum(),'');
        
        $data['cf_projects'] = $cmp_news;
        $data['PaginationHtml'] = $Pagination->show('right');
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        
        $this->regView('investor_index',$data);
    
    }
    
    
    /**
     * 
     * 已经投资的项目
     * 
     */
    function investor_tz(){
     
        
        
        $dao = new CommonDao4sSelf('','','','');
        
        $sql_pros = "select project_id from cf_project_financing where investor_id = ".$_SESSION['userid'] ;
        $sql_pros_arr = $dao->getRowsBySQl($sql_pros);
        
        if(  empty($sql_pros_arr) || count($sql_pros_arr)==0 ){
            $sql = "select * from cf_project where statss = 200 ";
        }else{
            
            $arr = array();
            foreach (  $sql_pros_arr as $item ){
            
                array_push( $arr , $item['project_id'] );
            
            }
            
            $arr_str = implode(',', $arr);
            
            $sql = "select * from cf_project where id in ($arr_str) ";
            
            
            
        }
     
        
        
      
        
        
        
    
        $Pagination = new Page('cf_project', '', '' , '', " ", APP_WEB_INDEX_ROOT."/main/financing_index", $dao->getMyDB());
        $cmp_news = $dao->getRowsBySQl($sql,'',$Pagination->LimitNum(),'');
    
        $data['cf_projects'] = $cmp_news;
        $data['PaginationHtml'] = $Pagination->show('right');
    
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open1'] = " start active open";
    
        $this->regView('investor_index',$data);
        
    }
    
    
    
    /**
     * 
     * 认筹
     * 
     */
    function investor_project_claim(){
       
        
        $id = $_GET['id'];
        $dao = new CommonDao4sSelf('','','','');
        $sql = " update cf_project set investor_id = 1324 , statss = 2  where id = $id ";
        $dao->updateBySql($sql,'');
        
        
        $this->save_funddetails_money($id, $this->getLang('投资用户'), 1, 100000,$this->getLang('投资人投资').'1000元');
        
        
        $this->investor_index();
        
    }
    
    
    
    function investor_nav(){
        
        
         $this->regView('investor_nav',$data);
        
    }
    
    //========================================== <?php echo $this->getLang('监管人'); ==========================================

    function regulator_index(){
     
        
        $_SESSION['userid'] = '6';
        $_SESSION['usertype'] = '3';
        $_SESSION['username'] = $this->getLang('监管人');
        
        //$userid = $_GET['userid'];
        
        $sql = "select * from cf_project ";
        $dao = new CommonDao4sSelf('','','','');
        
        $Pagination = new Page('cf_project', '', '' , '', " ", APP_WEB_INDEX_ROOT."/main/financing_index", $dao->getMyDB());
        $cmp_news = $dao->getRowsBySQl($sql,'',$Pagination->LimitNum(),'');
        
        $data['cf_projects'] = $cmp_news;
        $data['PaginationHtml'] = $Pagination->show('right');
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        
        $this->regView('regulator_index',$data);
    
    }
    
    
    /**
     * 
     * 项目信息
     * 
     */
    function regulator_project_money(){
    
        $pro_id = $_GET['proid'];
        
        $sql = " select id from cf_project_funddetails where project_id = $pro_id ";
        $dao = new CommonDao4sSelf('','','','');
         
        $funddetailss = $dao->getRowsBySQl($sql,'','','');
    
        $id_arr = array();
        
        
        foreach ( $funddetailss as $item ){
            
            $id = $item['id'];
            array_push($id_arr, $id);
            
        }
        
        $id_strs = implode("##", $id_arr);
        
        $ylf = new YlfCommon();
        $parms = array('id'=>$id_strs);
        $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_gets", $parms);
        $content = base64_decode($content);
        
        $content = htmlspecialchars_decode($content);
        
        $content = str_replace("}{","},{",$content);
        
        
        $content_arr = json_decode($content,true);
       
        $message =  $content_arr['result']['message'] ;
        //$message = str_replace("\"","//\"",$message);
        
        //echo $message;
        
      /*   $message_arr = array(array('id'=>1,"name"=>"你好你好"),array('id'=>1,"name"=>"你好你好"));
        echo json_encode($message_arr); */
        //print_r( json_decode(json_encode($message_arr),true) );
        
        
        $cf_project_funddetails = json_decode( $message , true );
        
        //print_r($cf_project_funddetails);
        
        $data['cf_project_funddetails'] = $cf_project_funddetails;
        
        $data['nav_project_action_open'] = " start active open";
        $data['nav_project_base_action_open'] = " start active open";
        $this->regView( 'regulator_project_money' , $data );
    
    
    }
    
    ////*********************************通用方法********************************************
    
    function ajax_checkimage(){
        
        
        $id = $_GET['itemid'];
        
        $sql = " select * from cf_project_funddetails where id = $id ";
        
        $dao = new CommonDao4sSelf('','','','');
         
        $funddetails = $dao->getRowsBySQl($sql,'','','');
        //print_r($funddetails);
        $bills = $funddetails[0]['bills'];
        
        
        $image_path = "D:/server/xampp/htdocs/zw_cf_demo/uploads/cmp/".$bills;
        $image_base64 =  $this->base64EncodeImage( $image_path );
        $hashvalue1 = hash("sha256", $image_base64);
        
        $result = array('image'=>$bills,'imagehash'=>$hashvalue1);

        
        
        
        echo json_encode($result);
        
    }
    
    
    
    public function base64EncodeImage ($image_file) {
        $base64_image = '';
        $image_info = getimagesize($image_file);
        $image_data = fread(fopen($image_file, 'r'), filesize($image_file));
        $base64_image =  chunk_split(base64_encode($image_data));
        return $base64_image;
    }
    
    /**
     * 项目操作情况
     * 
     * @param unknown $proejct
     * @param unknown $use_poper
     * @param unknown $usertype
     * @param unknown $use_desc
     * 
     * 
     */
    function save_funddetails_opt($proejctid,$use_poper,$use_desc){
        
        $cf_project_funddetails = array(
            
                                            'project_id'=>$proejctid,
                                            'opt_type'=>1,
                                            'use_pople'=>$use_poper,
                                            'use_action'=>$use_desc,
                                            'use_dt'=>'now()'
                                        );
         
        
        $cf_project_funddetails['createdt'] = 'now()';
        $cf_project_funddetails['modifydt']='now()';
        
        $dao = new CommonDao4sSelf('','','','');
        $id = $dao->saveRow('cf_project_funddetails' , $cf_project_funddetails,'');
    
        //提交数据到区块链
        $cf_project_funddetails_bc = array(
                                                'id'=>$id,
                                                'project_id'=>$proejctid,
                                                'use_pople'=>base64_encode($use_poper),
                                                'use_type'=>'0',
                                                'use_action'=>base64_encode($use_desc),
                                                'use_nums'=>'0',
                                                'use_dt'=>date('Y-m-d H:i:s'),
                                                'fundraiser_id'=>'1',
                                                'use_desc'=>'1',
                                                'bills'=>'1',
                                                'bills_abstract'=>'1',
                                                'createdt'=>date('Y-m-d H:i:s'),
                                                'modifydt'=>date('Y-m-d H:i:s'),
                                                'orgid'=>$id
                                            );
        
        
        $ylf = new YlfCommon();
        $parms = array('senddata'=>base64_encode(json_encode($cf_project_funddetails_bc)),'id'=>$id);
        $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_post", $parms);
        
/*         
        $ylf = new YlfCommon();
        $content = $ylf->curl_get( $this->http_post."?str=".base64_encode(json_encode($cf_project_funddetails_bc)));
        
*/        
        
        //echo $content;
        
    }
    
    
    
    /*******************************************************************************************************
     * 
     * 资金使用情况
     *
     * @param unknown $proejct
     * @param unknown $use_poper
     * @param unknown $usertype
     * @param unknown $use_desc
     * 
     ******************************************************************************************************
     */
    function save_funddetails_money($proejctid,$use_poper,$usertype,$use_nums,$use_desc,$ext=''){
    
        $cf_project_funddetails = array(
    
            'project_id'=>$proejctid,
            'opt_type'=>1,
            'use_pople'=>$use_poper,
            'use_type'=>$usertype,
            'use_action'=>$use_desc,
            'use_nums'=>$use_nums,
            'use_dt'=>'now()'
            
            /* ,
            'use_dt'=>$_POST['use_dt'],
            'bills'=>$_POST['bills'],
            'bills_abstract'=>$_POST['bills_abstract'],
            'remark'=>$_POST['remark'] */
    
        );
        
        if( !empty($ext) ){
            foreach ( $ext as $key=>$value ){                
                $cf_project_funddetails[ $key ] = $value;
            }
        }
        
        $id = $_POST['id'];
        $dao = new CommonDao4sSelf('','','','');
    
        $cf_project_funddetails['createdt'] = 'now()';
        $cf_project_funddetails['modifydt']='now()';
        $id=$dao->saveRow('cf_project_funddetails' , $cf_project_funddetails,'');

        //需要记录的区块链中的数据
        $cf_project_funddetails_bc = array(    
                                                'id'=>$id,
                                                'project_id'=>$proejctid,
                                                'use_pople'=>base64_encode($use_poper),
                                                'use_type'=>$usertype,
                                                'use_action'=>base64_encode($use_desc),
                                                'use_nums'=>$use_nums,
                                                'use_dt'=>date('Y-m-d H:i:s'),
                                                'fundraiser_id'=>'1',
                                                'use_desc'=>'1',
                                                'bills'=>'1',
                                                'bills_abstract'=>'1',
                                                'createdt'=>date('Y-m-d H:i:s'),
                                                'modifydt'=>date('Y-m-d H:i:s'),
                                                'orgid'=>$id
                                             );
        
        
        /* 
        $ylf = new YlfCommon();
        $content = $ylf->curl_get( $this->http_post."?str=".base64_encode(json_encode($cf_project_funddetails_bc) ) );
         */
        
        $ylf = new YlfCommon();
        $parms = array('senddata'=>base64_encode(json_encode($cf_project_funddetails_bc)),'id'=>$id);
        $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_post", $parms);
        
        
        //echo $content;
    
    }
    
  
    
    
    
    function testget(){
        
        $ylf = new YlfCommon();
        $content = $ylf->curl_get( $this->http_get."?id=28" );
        $arr = json_decode($contents,true);
        print_r($contents);
        
    }
    
    
  
    
    
    function testpost(){
        
        $cf_project_funddetails_bc = array(
                                            'id'=>'1234',
                                            'project_id'=>'13123424',
                                            'use_pople'=>'11234324',
                                            'use_type'=>'1212334',
                                            'use_action'=>'11234234',
                                            'use_nums'=>'13241234',
                                            'use_dt'=>date('Y-m-d H:i:s'),
                                            'fundraiser_id'=>'1',
                                            'use_desc'=>'1',
                                            'bills'=>'1',
                                            'bills_abstract'=>'1',
                                            'createdt'=>date('Y-m-d H:i:s'),
                                            'modifydt'=>date('Y-m-d H:i:s'),
                                            'orgid'=>$id
                                          );
        
      
        $ylf = new YlfCommon();
        
        $content = $ylf->curl_get("http://192.168.23.69:8080/write_get?str=".base64_encode(json_encode($cf_project_funddetails_bc)));
        
        //echo base64_encode(json_encode($cf_project_funddetails_bc));
        
        echo $content;
        
    }
    
    
    ///////////////////====================== 有用的测试用例 ========================
    
    
    /**
     *    
     *  多字段获取数据
     *    
     */
    function testgetmutils(){
    
        $ylf = new YlfCommon();
        $parms = array('id'=>'33##34##35##36');
        $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_gets", $parms);
        
        $content_arr = json_decode($content,true);
        
        print_r( $content_arr['result']['message'] );
        
    }
    
    
    
    
    function testget1(){
    
        $ylf = new YlfCommon();
        $parms = array('id'=>'29');
        $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_get", $parms);
         
        print_r($content);
    
    }
    
    
    function testpost1(){
    
        $id = "cid1324";
        
        $cf_project_funddetails_bc = array(
            
            'id'=>$id,
            'project_id'=>'13123424',
            'use_pople'=>'11234324',
            'use_type'=>'1212334',
            'use_action'=>'11234234',
            'use_nums'=>'13241234',
            'use_dt'=>date('Y-m-d H:i:s'),
            'fundraiser_id'=>'1',
            'use_desc'=>'1',
            'bills'=>'1',
            'bills_abstract'=>'1',
            'createdt'=>date('Y-m-d H:i:s'),
            'modifydt'=>date('Y-m-d H:i:s'),
        );
    
    
        $ylf = new YlfCommon();
        $parms = array('senddata'=>base64_encode(json_encode($cf_project_funddetails_bc)),'id'=>$id);
        $content = $ylf->curl_post("http://jiaxingmail.china-haiyi.net/m/fb_post", $parms);
        
        
        print_r($content);
        
        //echo base64_encode(json_encode($cf_project_funddetails_bc));
        
    }
    
    
    
}

?>
