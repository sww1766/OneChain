<?php

require_once ( REALPATH.'/config/Init.inc.php' );
require_once ( 'app/libraries/EshowBaseController.php' );
require_once ( REALPATH.'/include/Class/HttpClient.class.php' );
require_once ( REALPATH.'/include/openpf/sianwb/saetv2.ex.class.php' );


class mnew extends EshowBaseController {
	
	public function __construct() {
		parent::__construct ();
	
	}
	
	function testweibo(){
		$c = new SaeTClientV2( '1847725599' , '6426313eb369d46b5072e222a74f405e' , '2.00tIruKBnprCBCb579bdafdd6lEmJB' );
		//$c->search_users_keywords()
		$ret = $c->upload('LINK16——中小企业移动工作台：随时随地掌控你的企业 http://c.eshowpro.com/wn1/pt?id=5015&cmp=20&type=&lang= ','http://pic.eshowpro.com/M00/02/36/wKgKo1KxrUKAfs5qAAc0uyoYHTE563.jpg');
		print_r($ret);
	}
	
	function sinaweibo(){
		
		$idcm =  decrypt(base64_decode($_GET['did']),'sinawb');
		$idcm_arr = explode(':',$idcm);
		$shearid = $idcm_arr[0];
		$cmp_id = $idcm_arr[1];
		
		//echo " id : $id  cmp : $cmp ";
	 	
		$o = new SaeTOAuthV2( '1847725599' , '6426313eb369d46b5072e222a74f405e' );
		
		if (isset($_REQUEST['code'])) {
			
			$keys = array();
			$keys['code'] = $_REQUEST['code'];
			$keys['redirect_uri'] = "http://www.eshowpro.com/mnew/sinaweibo?cmpid=13132";
			
			try {
				
				$token = $o->getAccessToken( 'code', $keys ) ;
				$token_en = json_encode($token);
				//$tokenacc  = $token['access_token'];
				$dao = new CommonDao4sSelf('','','','');
				
				$sql_up = " update cmp_share set isbound = 1 , boundcallback = '$token_en' where id = $shearid and cmp_id = $cmp_id ";
				$dao->updateBySql($sql_up,'');
				
				
				header("Location:"."http://cm.eshowpro.com/share/cmp_share_list");
				
				//print_r($token);
				
			} catch (OAuthException $e) {
				
				print_r($e);
				
			}
			
		}
	}
	
	
	
	function site(){
		$data = array();
		$this->regView1('sitemap',$data);
	}
	
	
	function index(){
		
		$data = array();
		$data['nav_index_active'] = "active";
		
		
		//案例
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowsBySQl(" select * from eshowpro_news where types =2 order by orderind desc ",'','','');
		
		$data['eshorpros'] = $eshorpros;
		
		$this->regView1('index',$data);
	}
	
	
	function aboutus(){
		
		$data = array();
		
		
		$data['nav_aboutus_active'] = "active";
		$this->regView1('about',$data);
		
	}
	
	
	function solution(){
		
		$data = array();
		
				//案例
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowsBySQl(" select * from eshowpro_news where types =1 order by orderind desc",'','','');
		
		$data['eshorpros'] = $eshorpros;
		
		$data['nav_solution_active'] = "active";
		$this->regView1('solution',$data);
		
	}

	
	function examples(){		
		$data = array();
		
		//案例
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowsBySQl(" select * from eshowpro_news where types =2 order by orderind desc",'','','');
		
		$data['eshorpros'] = $eshorpros;
		
		$data['nav_examples_active'] = "active";
		$this->regView1('examples',$data);
	}
	

	
		
	function mobilenet(){	
		
		$data = array();
		
		//案例
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowsBySQl(" select * from eshowpro_news where types =3 order by orderind desc",'','','');
		
		$data['eshorpros'] = $eshorpros;
		
		$data['nav_mobilenet_active'] = "active";
		$this->regView1('mobilenet',$data);
	}
	
	
	
	
	function services(){	
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowByPk('eshowpro_news','','id',25,'');
		
		$data = array();
		$data['eshorpros'] = $eshorpros;
		$data['nav_services_active'] = "active";
		$this->regView1('services',$data);
	}
	
	
	/**
	 * 联系我们
	 *
	 */
	function contact(){
		$data = array();
		$data['nav_contact_active'] = "active";
		$this->regView1('contact',$data);
		
	}
	
	
	
	function contentdetial(){	
		
		/*$p=$this->getUrlParam();
		
		$parmarr = explode('&&',$p);*/
		
		$id = $_GET['id'];
		$active = $_GET['act'];
		/*$id = $parmarr[0];
		$active = $parmarr[1];*/
		
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowByPk('eshowpro_news','','id',$id,'');
		
		$data = array();
		$data['eshorpros'] = $eshorpros;
		$data['active'] = $active;
		$data[$active] = "active";
		$this->regView1('contentdeails',$data);
		
	}
	
	
	/**
	 * 解决方案desil
	 *
	 */
	function fzdetail(){
		
		
		$p=$this->getUrlParam();
		
		$parmarr = explode('&&',$p);
		
		/*$id = $_GET['id'];
		$active = $_GET['act'];*/
		$id = $parmarr[0];
		$active = $parmarr[1];
		
		$dao = new CommonDao4sSelf('','','','');
		$eshorpros = $dao->getRowByPk('eshowpro_news','','id',$id,'');
		
		$data = array();
		$data['eshorpros'] = $eshorpros;
		$data['active'] = $active;
		$data[$active] = "active";
		$this->regView1('contentdeails',$data);
		
		
	}
	
	
	function cards(){
		
		//$cmp_id=$_GET['c'];
		//$id = $_GET['s'];
		//$lang = $_GET['l'];
		
		$parm = $this->getUrlParam();
		
		$parm_un = urldecode($parm);
		
		$parm_arr = explode('-',$parm_un);
		
		$cmp_id=$parm_arr[0];
		$id = $parm_arr[1];
		$lang = $parm_arr[2];
		
		
		$dao = new CommonDao4sSelf('','','','');
		
		
		$sql1 = " select * from company where id = $cmp_id";
		$cmp = $dao->getRowByPkOne($sql1,'');
		
		$sql = " select * from cmp_leader where id = $id and cmp_id = $cmp_id ";
		$cmp_leader = $dao->getRowByPkOne($sql,'');
		
		$data = array();
		
		$data['shoptitle'] = $cmp_leader['name'.$lang];
		$data['mobile'] = $cmp_leader['mobile'.$lang];
	    $data['phone'] = $cmp_leader['phone'.$lang];
	    $data['email'] = $cmp_leader['email'];
	    $data['address'] = $cmp['address'.$lang];
	    $data['url'] = "http://c.eshowpro.com/wn1/index?cmp=$cmp_id&lang=$lang";
	    $data['note'] = $cmp['cmp_name'.$lang];
	    
		$vcf = $this->load->view('vcftpl',$data,true);
   	   
   	    $vc_length = mb_strlen($vcf,'UTF-8');
   	    $vc_length = $vc_length*3;

   	    //$userinfo['mobile']='13761604518';
   	   
   	    Header("Content-type: application/octet-stream");	    	
 	    Header("Accept-Ranges: bytes");
	    Header("Accept-Length: ".$vc_length);
	    Header("Content-Disposition: attachment; filename="."mp.vcf");				
	    // 输出文件内容
	    echo $vcf;
	    exit();
	    
	}
	
}



?>