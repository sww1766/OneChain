<?php
require_once ('system/commonself/BaseController4CI.php');
require_once (REALPATH.'/config/Init.inc.php');

class Manager extends BaseController4CI {

	public function __construct() {
		parent::__construct ();
	
	}
	  	
		
	function  codegen(){
		
		$databasename="zw_cf";
		$tablename = "cf_project_financing";		
		
  		//echo base64_decode('L00wMC8wMC8wMC93S2dLVmxGai12NkFiM24wQUF6b2RRQ2JWVmMyMDkuanBn');
		//echo urlencode("/M00/00/00/wKgKKFFj6deAOPVgAAvWFkcZHjA997.jpg");		
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select COLUMN_NAME,COLUMN_COMMENT from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			
			
				if(strpos($col,'_en')>0 || strpos($col,'_x')>0)
					continue;
			
				if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
						continue;	
					
			
			$getvalue = "$"."$tablename"."['$col']";
			$rq1 = "$"."_REQUEST[";
			$req2 = "$"."lan)"."{"."$"."column = '$col'."."$"."lan";
			$req3 = "$"."lan";
			$req4 = "$"."column";
			$req5 = "$".$tablename."["."$"."column]";


$temps2 = <<<EOT
			                      
<label for="$col">$col_comm :</label>
<input type="text" data-mini="true" name="$col" id="$col" value="<?php echo $getvalue;?>">

EOT;

			$codegen = $codegen.$temps2.'';
			$columns_str = $columns_str.','.$col;
			//echo $col_comm." ==> ".$col . "<br/>";
			
		}
		
		echo $codegen.'/r/n';
		
		echo ");<br>";
		echo $columns_str;
		
		echo "<br>";
		echo "**********************************************************<br>";
		
		
	}
	
	}
	
	function  codegen2(){
		
		$databasename="zw_cf";
		$tablename = "cf_project";		
		
  		//echo base64_decode('L00wMC8wMC8wMC93S2dLVmxGai12NkFiM24wQUF6b2RRQ2JWVmMyMDkuanBn');
		//echo urlencode("/M00/00/00/wKgKKFFj6deAOPVgAAvWFkcZHjA997.jpg");		
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select COLUMN_NAME,COLUMN_COMMENT from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			
			
				if(strpos($col,'_en')>0 || strpos($col,'_x')>0)
					continue;
			
				if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
						continue;	
					
			
			$getvalue = "$"."$tablename"."['$col']";
			$rq1 = "$"."_REQUEST[";
			$req2 = "$"."lan)"."{"."$"."column = '$col'."."$"."lan";
			$req3 = "$"."lan";
			$req4 = "$"."column";
			$req5 = "$".$tablename."["."$"."column]";


$temps2 = <<<EOT

<div class="control-group">
    <label class="control-label" for="$col">$col_comm</label>
    <div class="controls">      
        <span class="input-xlarge uneditable-input"><?php echo $getvalue;?></span> 
    </div>
</div>

EOT;

			$codegen = $codegen.$temps2.'';
			
			$columns_str = $columns_str.','.$col;
			//echo $col_comm." ==> ".$col . "<br/>";
			
			
		}
		
		echo $codegen.'/r/n';
		
		echo ");<br>";
		echo $columns_str;
		
		echo "<br>";
		echo "**********************************************************<br>";
		
		
	   }
	
	}	
	
	
	
	
	function  codegen3(){
		
		$databasename="zw_cf";
		$tablename = "cf_project_financing";		
		
  		//echo base64_decode('L00wMC8wMC8wMC93S2dLVmxGai12NkFiM24wQUF6b2RRQ2JWVmMyMDkuanBn');
		//echo urlencode("/M00/00/00/wKgKKFFj6deAOPVgAAvWFkcZHjA997.jpg");		
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select COLUMN_NAME,COLUMN_COMMENT from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			
			
				if(strpos($col,'_en')>0 || strpos($col,'_x')>0)
					continue;
			
				if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
						continue;	
					
			
			$getvalue = "$"."$tablename"."['$col']";
			$rq1 = "$"."_REQUEST[";
			$req2 = "$"."lan)"."{"."$"."column = '$col'."."$"."lan";
			$req3 = "$"."lan";
			$req4 = "$"."column";
			$req5 = "$".$tablename."["."$"."column]";


$temps2 = <<<EOT

<div class="form-group">
	<label class="col-md-3 control-label">$col_comm</label>
	<div class="col-md-6">
		<input type="text" class="form-control" name="$col" id="$col" value="<?php echo $getvalue;?>"> 
	</div>
</div>

EOT;

			$codegen = $codegen.$temps2.'';
			
			$columns_str = $columns_str.','.$col;
			//echo $col_comm." ==> ".$col . "<br/>";
			
			
		}
		
		echo $codegen."
		";
		
		echo ");
		";
		echo $columns_str;
		
		echo "<br>";
		echo "**********************************************************<br>";
		
		
	}
	
	}	
	
	
	
	//辅助方法
	
	function  codegen5(){
		
		$databasename="zw_cf";
		$tablename = "cf_project";
		
  		//echo base64_decode('L00wMC8wMC8wMC93S2dLVmxGai12NkFiM24wQUF6b2RRQ2JWVmMyMDkuanBn');
		//echo urlencode("/M00/00/00/wKgKKFFj6deAOPVgAAvWFkcZHjA997.jpg");
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select COLUMN_NAME,COLUMN_COMMENT from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			
			
				if(strpos($col,'_en')>0 || strpos($col,'_x')>0)
					continue;
			
				if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
						continue;	
					
			
			$getvalue = "$"."$tablename"."['$col']";
			$rq1 = "$"."_REQUEST[";
			$req2 = "$"."lan)"."{"."$"."column = '$col'."."$"."lan";
			$req3 = "$"."lan";
			$req4 = "$"."column";
			$req5 = "$".$tablename."["."$"."column]";
$temps1 = <<<EOT
<div class="control-group">
    <label class="control-label" for="name">$col_comm</label>
    <?php foreach($rq1'langeager'] as $req2;?>
    <div class="controls">
        <input type="text" class="input-xlarge" name="$col<?php echo $req3;?>" id="$col<?php echo $req3;?>" value="<?php echo $req5;?>"/> <?php echo $req3;?>
    </div>
     <?php }?>
</div>
                             
EOT;

$temps2 = <<<EOT
<div class="control-group">
    <label class="control-label" for="name">$col_comm</label>
    <div class="controls">
        <input type="text" class="input-xlarge" name="$col" id="$col" value="<?php echo $getvalue;?>"/> 
    </div>
</div>
                             
EOT;        
        
        
			$temps = <<<EOT
<tr bgcolor="#ffffff"> 
  <td width="19%" height="25" align="right"><span class="STYLE7">$col_comm</span></td>
  <td width="69%" height="25"><input name="$col" id="$col" value="<?php echo $getvalue;?>" size="36" type="text"/></td>
</tr>

EOT;
			$codegen = $codegen.$temps1.'';
			
			$columns_str = $columns_str.','.$col;
			//echo $col_comm." ==> ".$col . "<br/>";
			
			
		}
		
		echo $codegen.'/r/n';
		
		echo ");<br>";
		echo $columns_str;
		
		echo "<br>";
		echo "**********************************************************<br>";
		
		
	}
	
	}
	
	
	
	function  codegen_list(){
		
		
		$databasename="zw_cf";
		$tablename = "cf_project";
		
  		//echo base64_decode('L00wMC8wMC8wMC93S2dLVmxGai12NkFiM24wQUF6b2RRQ2JWVmMyMDkuanBn');
		//echo urlencode("/M00/00/00/wKgKKFFj6deAOPVgAAvWFkcZHjA997.jpg");
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select COLUMN_NAME,COLUMN_COMMENT from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
	    $table_title = "";
	    $table_column = "";
	    
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		//echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			//echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			
			
				if(strpos($col,'_en')>0 || strpos($col,'_x')>0)
					continue;
			
				if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
						continue;	
					
			
			$getvalue = "$"."item"."['$col']";
		
			
			
			
$temps1 = <<<EOT
 <th width="10%">$col_comm</th>                                
EOT;

$temps2 = <<<EOT
  <td><?php echo $getvalue;?></td>                        
EOT;
			$table_title = $table_title.$temps1."
			";
			
			$table_column = $table_column.$temps2."
			";
			//echo $col_comm." ==> ".$col . "<br/>";
			
			
		}
		
		echo "<table class=\"table table-striped table-bordered table-hover\">
<thead>
<tr>  
";
		echo  $table_title.'<th width="15%">操作</th>';
echo "
</tr>
</thead>
<tbody>
<?php foreach (\$cf_projects as \$item){?>
<tr>
";		
		
		echo $table_column;
echo " <td>                                    
    	<a class=\"btn blue-madison btn-xs\" style=\"margin-right: 2px;\" href=\"<?php echo APP_WEB_INDEX_ROOT;?>/main/yw_order_yuejie_ls_edit?id=<?php echo \$item['id'];?>\">编辑</a>
    	<a class=\"btn blue-madison btn-xs\" style=\"margin-right: 2px;\" href=\"<?php echo APP_WEB_INDEX_ROOT;?>/main/yw_order_yuejie_ls_del?id=<?php echo \$item['id'];?>&<?php echo \$pagesearchUrl;?>\">删除</a>                         	
    </td>
</tr>
<?php }?>                            
</tbody>

</table>";		
	
		
		
		
	}
	
	}
	
	
	
	
	//辅助方法
	
	function  codegen1(){
		
		$databasename="zw_cf";
		$tablename = "cf_project";
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select TABLE_NAME, COLUMN_NAME,COLUMN_COMMENT,DATA_TYPE,CHARACTER_MAXIMUM_LENGTH  from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		//echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			//echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			$columntype = $column['DATA_TYPE'];
			$columntypelen = $column['CHARACTER_MAXIMUM_LENGTH'];
			$getvalue = "$"."$tablename"."['$col']";
			
			$col_comm_en = $col."_en";
			$col_comm_x = $col."_x";
			
			if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
			continue;
			
			
if( $column['DATA_TYPE'] == 'varchar' || $column['DATA_TYPE'] == 'char' ) {			
$temps1 = <<<EOT
ALTER TABLE $tablename ADD COLUMN $col_comm_x  $columntype($columntypelen) NULL COMMENT '$col_comm' AFTER $col;  
ALTER TABLE $tablename ADD COLUMN $col_comm_en  $columntype($columntypelen) NULL COMMENT '$col_comm' AFTER $col;
EOT;
}
else{ 
$temps1 = <<<EOT
ALTER TABLE $tablename ADD COLUMN $col_comm_x  $columntype NULL COMMENT '$col_comm' AFTER $col;
ALTER TABLE $tablename ADD COLUMN $col_comm_en  $columntype NULL COMMENT '$col_comm' AFTER $col;                                
EOT;
}			
			$codegen = $codegen.$temps1.'';
			
			$columns_str = $columns_str.','.$col;
			//echo $col_comm." ==> ".$col . "<br/>";
			
			echo $temps1;
		}
		
		//echo $codegen.';';
		
		
	}
	
	}
	
	function  codegen6(){
		
		$databasename="zw_cf";
		$tablename = "cf_project";		
		
  		//echo base64_decode('L00wMC8wMC8wMC93S2dLVmxGai12NkFiM24wQUF6b2RRQ2JWVmMyMDkuanBn');
		//echo urlencode("/M00/00/00/wKgKKFFj6deAOPVgAAvWFkcZHjA997.jpg");		
		
		$dao = new CommonDao4sSelf('','','','');
		/**
		 * ,'nb_product','nb_outdoorproject','nb_brand','nb_accoutertype','nb_accouter','nb_news','nb_knowchannel','nb_adinfo'
		 */
		$sqltable = "select  TABLE_NAME from information_schema.TABLES where TABLE_SCHEMA='$databasename' and TABLE_NAME in('$tablename')";
		
		$tables = $dao->getRowsBySQl($sqltable,'','','');
		
		foreach( $tables as $table   ){
				
		$sqlchareter = "select COLUMN_NAME,COLUMN_COMMENT from information_schema.COLUMNS where TABLE_SCHEMA='$databasename' and TABLE_NAME = "."'".$table['TABLE_NAME']."'";
		
		$tablenamedesc = $table['TABLE_NAME'];
		
	    $codegen = "";
		
		$columns = $dao->getRowsBySQl($sqlchareter,'','','');
		echo "$".$table['TABLE_NAME']." = array(<br>";
		
		$columns_str = '';
		
		foreach( $columns as $column   ){
			$col = $column['COLUMN_NAME'];
			$col_comm = $column['COLUMN_COMMENT'];
			echo "'{$col}'=>"."$"."_POST['{$col}'],"."<br>";
			
			
				if(strpos($col,'_en')>0 || strpos($col,'_x')>0)
					continue;
			
				if( $col == 'id' || $col == 'cmp_name' || $col =='cmp_id' || $col == 'createdt' || $col == 'modifydt'  )
						continue;	
					
			
			$getvalue = "$"."$tablename"."['$col']";
			$rq1 = "$"."_REQUEST[";
			$req2 = "$"."lan)"."{"."$"."column = '$col'."."$"."lan";
			$req3 = "$"."lan";
			$req4 = "$"."column";
			$req5 = "$".$tablename."["."$"."column]";


$temps2 = <<<EOT

<p>$col_comm ：<span class="p_span_detail"><?php echo $getvalue;?></span></p>
EOT;

			$codegen = $codegen.$temps2.'';
			$columns_str = $columns_str.','.$col;
			//echo $col_comm." ==> ".$col . "<br/>";
			
		}
		
		echo $codegen.'/r/n';
		
		echo ");<br>";
		echo $columns_str;
		
		echo "<br>";
		echo "**********************************************************<br>";
		
		
	}
	
	}
	
}
