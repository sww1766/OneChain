<?php


/**
 * 
 * 上传文件
 *
 */
class upload {
	
	
	public function __construct() {}
	
	
	private $screenw=480;
	private	$screenh=10800;

	
	private $screenw1=360;
	private	$screenh1=600;
	
	
	
	private $MODLEARRAY = array('1'=>'leader','2'=>'protype','3'=>'pro','4'=>'glory','5'=>'ckedit','6'=>'jxs','7'=>'cmp');
	
	
	
	/**
	 * 上传文件
	 *
	 */
	function uploadpic(){

	        ini_set("memory_limit","-1");
	        
			$secd = $_GET['secd'];
			$cmpid = $secd;
			$mod = $_GET['mod'];
			$procid = $_GET['id'];			
		
			
			$fileporpery = 'Filedata';
			
			if( $mod == '5' )
			   	$fileporpery = 'imgFile';
			
    			$targetFolderf1 = 	'/uploads/';
    			$targetFolder = $targetFolderf1.'cmp'.'/'; // Relative to the root
    		
    			$verifyToken = md5('unique_salt' . $_POST['timestamp']);
			
			
			if( $mod == '5' ){
				
			}else{
				
    			if (!empty($_FILES) && $_POST['token'] == $verifyToken) {
    				$tempFile = $_FILES[$fileporpery]['tmp_name'];
    				$targetPath = REALPATH. $targetFolder;
    				
    				$filename =  $_FILES[$fileporpery]['name'];
    				$filetype  = substr ( $filename, strrpos ( $filename, '.' ), strlen ( $filename ) );
    				
    				$uuid = uniqid('',true);
    				$uuid = str_replace('.','a',$uuid);
    				
    				//$filename = $cmpid.'_'.$mod.'_'.$uuid.$filetype;
    				
    				$filename = $uuid.$filetype;
    				
    				$targetFile = rtrim($targetPath,'/') . '/' . $filename;
    				
    				// Validate the file type
    				$fileTypes = array('jpg','jpeg','gif','png'); // File extensions
    				$fileParts = pathinfo($_FILES[$fileporpery]['name']);
    				
    				move_uploaded_file($tempFile,$targetFile);		
    				
    				//计算图片的HASH值
    				$hashvalue =  $this->base64EncodeImage( $targetFile );
    				$hashvalue1 = hash("sha256", $hashvalue);
    				
    				$df = array( "imagename"=>$filename , 'imagehash'=>$hashvalue1 );
    				
    				echo json_encode( $df );
    			    
    			
    			}else{
    				
    			    echo '0';
    			    
    			}
				
			}
			
		
		
	}
	
	private $rate = 5;
	
	public function base64EncodeImage ($image_file) {
          $base64_image = '';
          $image_info = getimagesize($image_file);
          $image_data = fread(fopen($image_file, 'r'), filesize($image_file));
          $base64_image =  chunk_split(base64_encode($image_data));
          return $base64_image;
    }
        	
	public function getHashValue1($img1){
	    
	    
	    $total = 1;
	    $i=imagecreatefromjpeg($img1);//测试图片，自己定义一个，注意路径
	    for ($x=0;$x<imagesx($i);$x++) {
	        for ($y=0;$y<imagesy($i);$y++) {
	            $rgb = imagecolorat($i,$x,$y);
	            $r=($rgb >>16) & 0xFF;
	            $g=($rgb >>16) & 0xFF;
	            $b=$rgb & 0xFF;
	            $rTotal += $r;
	            $gTotal += $g;
	            $bTotal += $b;
	            $total++;
	        }
	    }
	    $rAverage = round($rTotal/$total);
	    $gAverage = round($gTotal/$total);
	    $bAverage = round($bTotal/$total);
	    //示例：
	    return  $rAverage;
	}
	
	public function getHashValue( $img1 ){
	
	    ini_set("memory_limit","-1");
	    
	    $img = imagecreatefromjpeg($img1);;
	    
	    $width = imagesx($img);
	    $height = imagesy($img);
	    $total = 0;
	    $array = array();
	
	    //echo $width."   ".$height;
	    
	    for ($y = 0; $y < $height; $y ++) {
	        for ($x = 0; $x < $width; $x ++) {
	            $gray = (imagecolorat($img, $x, $y) >> 8) & 0xFF;
	
	            if (! is_array($array[$y])) {
	                $array[$y] = array();
	            }
	            $array[$y][$x] = $gray;
	            $total += $gray;
	        }
	    }
	
	    $average = intval($total / (64 * $this->rate * $this->rate));
	    $result = '';
	
	    for ($y = 0; $y < $height; $y ++) {
	        for ($x = 0; $x < $width; $x ++) {
	            if ($array[$y][$x] >= $average) {
	                $result .= '1';
	            } else {
	                $result .= '0';
	            }
	        }
	    }
	
	    return $result;
	}
	
	
	
	

		

}

?>