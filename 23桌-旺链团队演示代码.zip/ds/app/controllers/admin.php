<?php

require_once ('app/libraries/EshowBaseController.php');

class admin extends EshowBaseController {
	
	public function __construct() {
		parent::__construct ();
	
	}
	
	
	function loginpro(){
		$data = array();
		$this->regView('login',$data);
	}
	
	function index(){
		
		$data = array('nav_left_active_index'=>'class="active"');
		$this->regView('index',$data);
	}
	
	function charts(){
		
		$data = array('nav_left_active_charts'=>'class="active"');
		$this->regView('charts',$data);
	}
	
	function formstuff(){
		
		
		$data = array('nav_left_active_forms_ul'=>' show');
		$data['nav_left_active_forms']='class="expand active-state"';
		$data['nav_left_active_forms_stuff']='class="active"';
		$data['nav_left_active_forms_stuff_flag']='active';
		
		$this->regView('forms',$data);
		
	}
	
	
	function form_validation(){
		
		$data = array('nav_left_active_forms_ul'=>' show');
		$data['nav_left_active_forms']='class="expand active-state"';
		$data['nav_left_active_forms_validation']='class="active"';
		$data['nav_left_active_forms_validation_flag']='active';
		
		$this->regView('form_validation',$data);
		
	}
	
	function form_wizard(){
		
		$data = array('nav_left_active_forms_ul'=>' show');
		$data['nav_left_active_forms']='class="expand active-state"';
		$data['nav_left_active_forms_wizard']='class="active"';
		$data['nav_left_active_forms_wizard_flag']='active';
		
		$this->regView('form_wizard',$data);
	}
	
	
	function wysiwyg(){
		
		$data = array('nav_left_active_forms_ul'=>' show');
		$data['nav_left_active_forms']='class="expand active-state"';
		$data['nav_left_active_wysiwyg']='class="active"';
		$data['nav_left_active_wysiwyg_flag']='active';
		
		$this->regView('wysiwyg',$data);
		
	}
	
	
	function tables(){
		
		$data = array('nav_left_active_tables_ul'=>' show');
		$data['nav_left_active_tables']='class="expand active-state"';
		$data['nav_left_active_tables_tables']='class="active"';
		$data['nav_left_active_tables_tables_flag']='active';
		
		
		$this->regView('tables',$data);
	}
	
	
	function data_tables(){
		
		$data = array('nav_left_active_tables_ul'=>' show');
		$data['nav_left_active_tables']='class="expand active-state"';
		$data['nav_left_active_tables_data_tables']='class="active"';
		$data['nav_left_active_tables_data_tables_flag']='active';
		
		$this->regView('data_tables',$data);
		
	}
	
	
	function notifications(){
		
		$data = array('nav_left_active_ui_ul'=>' show');
		$data['nav_left_active_ui']='class="expand active-state"';
		$data['nav_left_active_ui_notifications']='class="active"';
		$data['nav_left_active_ui_notifications_flag']='active';
		
		$this->regView('notifications',$data);
		
	}
	
	
	function panels(){
		
		$data = array('nav_left_active_ui_ul'=>' show');
		$data['nav_left_active_ui']='class="expand active-state"';
		$data['nav_left_active_ui_panels']='class="active"';
		$data['nav_left_active_ui_panels_flag']='active';
		
		$this->regView('panels',$data);
		
	}
	
	
	
	
}

?>