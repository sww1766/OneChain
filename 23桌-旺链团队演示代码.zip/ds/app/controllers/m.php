<?php

require_once ( REALPATH.'/config/Init.inc.php' );
require_once ( 'app/libraries/EshowBaseController.php' );
require_once ( REALPATH.'/include/Class/HttpClient.class.php' );

class m extends EshowBaseController {
	
	public function __construct() {
		parent::__construct ();
	
	}
	
	
    function company(){
        
        $data['nav_base_action_open'] = "  active open";
        $data['nav_base_cmp_action_open'] = "  active open";
        $this->regView('metronic/company',$data);
        
    }
	
    
    
    
    
    
}

?>