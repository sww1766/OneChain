<?php

require_once ('app/libraries/EshowBaseController.php');


class inspinia extends EshowBaseController
{

    public function __construct()
    {
        parent::__construct();
    }
    
    
    /**
     * 首页 */
    function index(){
    
    
        $this->regView('inspinia/index',$data);
         
    
    }
    
    
}

?>