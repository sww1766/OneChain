<?php
/**
 */
/* Get the Application real root path. */
$_CFG['RealRootPath'] = dirname(dirname(__FILE__));
define('REAL_ROOT_PATH', $_CFG['RealRootPath']);

if(!file_exists($_CFG['RealRootPath'] . '/config/Config.inc.php'))
{
    die(" <h1>File 'config/Config.inc.php' cannot be found. </h1>");
}

@ini_set("include_path", "." . PATH_SEPARATOR . $_CFG['RealRootPath'] . PATH_SEPARATOR . $_CFG["RealRootPath"] . "/include/" . PATH_SEPARATOR . $_CFG["RealRootPath"] . "/include/Class/" . PATH_SEPARATOR . $_CFG["RealRootPath"] . "/include/Class/PhpMailer");


require(REAL_ROOT_PATH . '/config/Config.inc.php');                   // Config file.
//require(REAL_ROOT_PATH . '/include/Session.inc.php');                  // Session file.

/* Start session. */
//session_cache_limiter('private, must-revalidate');
session_start();
header('Cache-control: private');

/* Create the BaseURL of Application system.
 * If the url of Application is wrong, you can specify it by hand, for example: http://www.test.com/Application.
 * Note: No "/" at the end of the url.
 */
if(strtolower($_SERVER["HTTPS"]) == "on")
{
    $ServerProtocol = "https";
    $ServerPort = "";
}
else
{
    $ServerProtocol = "http";
    $ServerPort = $_SERVER["SERVER_PORT"] == "80" ? "":":" . $_SERVER["SERVER_PORT"];
}
//$_CFG["BasePath"] = eregi_replace("[/\\]{1}$" , "", dirname($_SERVER["SCRIPT_NAME"]));
//$_CFG["BasePath"] = eregi_replace("Admin[/\\]{0,1}$" , "", $_CFG["BasePath"]);
$_CFG["BaseURL"] = $ServerProtocol . "://" . $_SERVER["SERVER_NAME"] . $ServerPort . $_CFG["BasePath"];
//define(BF_COOKIE_PATH, $_CFG['BasePath'] . '/');

/* Require config, functions and class files. */
require(REAL_ROOT_PATH . '/include/Class/Page.class.php');                  // Page class.
require(REAL_ROOT_PATH . '/include/Class/ADOLite/adodb.inc.php');           // ADO class.
require(REAL_ROOT_PATH . '/include/Class/TemplateLite/class.template.php'); // Smarty class.
//wingfeng add it on 2008-09-16
require(REAL_ROOT_PATH . '/include/CommanDao.php');                        // common DAO 
require(REAL_ROOT_PATH . '/include/CommonDao4sSelf.php');                        // common DAO 
require(REAL_ROOT_PATH . '/include/CommonService.php');                    // common Servcie                  // project common Servcie
require(REAL_ROOT_PATH . '/include/Class/imagesample.php');   



if(empty($_CFG['UserLang']))       $_CFG['UserLang']  = $_CFG['DefaultLang'];
if(empty($_CFG['UserStyle']))      $_CFG['UserStyle'] = $_CFG['DefaultStyle'];
if(empty($_CFG['UserLang']))       $_CFG['UserLang']  = $_CFG['DefaultLang'];

/* include the Language file, send heard info. */
if($_CFG['UserLang'] == '')$_CFG['UserLang'] = $_CFG['DefaultLang'];
$LangCommon = $_CFG['RealRootPath'] . '/source/Lang/' . $_CFG['UserLang'] . '/_COMMON.php';
if(file_exists($LangCommon)) require($LangCommon);
$LangPinYin = $_CFG['RealRootPath'] . '/source/Lang/' . $_CFG['UserLang'] . '/PinYin.php';
if(file_exists($LangPinYin)) require($LangPinYin);

@header("Content-Type: text/html; charset=".$_LANG["Charset"]);

/* Connect to Application database server and return the global DB handler -- $MyDB which is used anywhere and set the FETCH_MODE to ASSOC. */

/*
 * 
 * This file private some database acess method
 * 
 * Created on 2008-7-16
 *
 */
 
/**
 * close the db
 */ 
function sysCloseDB()
{
    global $MyDB, $MyUserDB, $_CFG;
    if( !empty($MyDB)){
	    $MyDB->Close();
	    if(!empty($_CFG['UserDB']))
	    {
	        $MyUserDB->Close();
	    }
    }
    

    global  $mydbpools;
    if( !empty($mydbpools)){
    
    	foreach ( $mydbpools as $key =>$value){
    		if( !empty($key) && !empty($value)){
    			$value->Close();
    		}
    	}
    
    }
    
}

$mydbpools = array();
//$MyDB = &ADONewConnection('mysql', 'pear');
$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;

/*$MyDB = &ADONewConnection('mysql', 'pear');
$DBResult = $MyDB->Connect($_CFG['DB']['Host'], $_CFG['DB']['User'], $_CFG['DB']['Password'], $_CFG['DB']['Database']);


$ADODB_FETCH_MODE = ADODB_FETCH_ASSOC;
$MyDB->debug_console = true;
if(version_compare(@mysql_get_server_info(), '4.1.0', '>=')){$_CFG['Mysql4.1.0Plus'] = true;}
if($_CFG['DBCharset'] != '' && $_CFG['Mysql4.1.0Plus'])
{
    $MyDB->Query("SET NAMES {$_CFG['DBCharset']}");
}*/

/* Connect to validating database if it's different from Application database and return the global DB handler --$MyUserDB. */
//if(!empty($_CFG['UserDB']))
//{
//    $MyUserDB = &ADONewConnection('mysql', 'pear');
//    $MyUserDB->NConnect($_CFG['UserDB']['Host'], $_CFG['UserDB']['User'], $_CFG['UserDB']['Password'], $_CFG['UserDB']['Database']);
//    if($_CFG['DBCharset'] == 'UTF8')
//    {
//        $MyUserDB->Query("SET NAMES UTF8");
//    }
//}
register_shutdown_function('sysCloseDB');

/* Turn off the runtime magic_quotes feature. */
//ini_set('magic_quotes_runtime', 0);

/* Init template class. */
/*$TPL = new Template_Lite;
$TPL->template_dir = $_CFG['TemplateDir'];
$TPL->compile_dir  = $_CFG['TPLCompileDir'];*/
//$TPL->debugging = true;

/* Add slashes to REQUEST, GET, POST, COOKIE, FILES vars. */
if(!get_magic_quotes_gpc())
{
    $_REQUEST = sysAddSlash($_REQUEST);
    $_GET     = sysAddSlash($_GET);
    $_POST    = sysAddSlash($_POST);
    //$_COOKIE  = sysAddSlash($_COOKIE);
    //$_FILES   = sysAddSlash($_FILES);
}

if($_SERVER["SERVER_NAME"] != '')
{
    $_CFG['BrowserMode'] = true;

}


/* 
 * 当系统为CI框架的时候需要加入以下一些配置，使CI系统的使用更加灵活
 * wingfeng add it on 2010-03-18
 */
$_CFG["ProjectName"] = 'zw_cf_demo'; 
define('PROJECT_NAME',$_CFG["ProjectName"]);
$str_temp = substr($_SERVER["PHP_SELF"],1,strlen($_SERVER["PHP_SELF"]));
$project_path_split =  substr($str_temp,0,strpos($str_temp,'/'));



if( $_CFG["ProjectName"] == $project_path_split ){
	$_CFG['DEPLOY'] = '0';	
	define('HTTP_DOCMENT_ROOT',$ServerProtocol."://".$_SERVER['HTTP_HOST'].'/'.$_CFG["ProjectName"]);
	define('APP_WEB_INDEX_ROOT',HTTP_DOCMENT_ROOT.'/index.php');
}else{
	$_CFG['DEPLOY'] = '1';
	define('HTTP_DOCMENT_ROOT',$ServerProtocol."://".$_SERVER['HTTP_HOST'].'');
	define('APP_WEB_INDEX_ROOT',HTTP_DOCMENT_ROOT);
}


define('TPL_ROOT',HTTP_DOCMENT_ROOT.'/source/assets');
define('IMAGE_ROOT',TPL_ROOT.'/img');
define('JS_ROOT',TPL_ROOT.'/js');
define('CSS_ROOT',TPL_ROOT.'/css');
define('SOURCE_ROOT','http://cm.eshowpro.com'.'/source');

define('PAGE_BODY_CLASS','page-container-bg-solid page-header-fixed page-sidebar-closed-hide-logo page-sidebar-fixed page-footer-fixed');


parse_str($_SERVER['QUERY_STRING'],$_GET); 

//当使用CI系统时定位，定义http到index之间的url
define('APP_WEB_INDEX_ROOT',HTTP_DOCMENT_ROOT.'/index.php');


/* */
//$OrderTypeReverseArray = array('ASC'=>'DESC', 'DESC'=>'ASC');
/* Assign $Config defined in the Lang file to the template. */
/*$TPL->assign('OrderTypeReverseArray', $OrderTypeReverseArray);
$TPL->assign('OrderTypeArrowArray',array('ASC'=>'&uarr;', 'DESC'=>'&darr;'));
$TPL->assign('CFG',  $_CFG);
$TPL->assign('Lang', $_LANG);
$TPL->assign('TestMode', $_SESSION['TestMode']);
$TPL->assign('currentrealname', $_SESSION['TestRealName']);
$TPL->assign('SESSION',$_SESSION);
$TPL->assign('POST',$_POST);*/


//是否打开系统日志文件
ini_set('error_log',REAL_ROOT_PATH.'/log/phperror.txt');
ini_set('display_errors',1);
ini_set('log_errors',1);


?>
